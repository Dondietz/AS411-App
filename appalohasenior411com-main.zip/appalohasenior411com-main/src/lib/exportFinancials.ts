import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';

interface PropertyFinancials {
  id: string;
  address: string;
  city: string;
  status: string;
  sale_price: number | null;
  estimated: number;
  paid: number;
  deferred: number;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export function exportToCSV(properties: PropertyFinancials[], filename: string = 'financial-report') {
  const headers = ['Property', 'City', 'Status', 'Estimated', 'Paid', 'Deferred', 'Total Costs', 'Sale Price', 'Est. Net'];
  
  const rows = properties.map(p => {
    const totalCosts = p.paid + p.deferred;
    const netProfit = (p.sale_price || 0) - totalCosts;
    return [
      p.address,
      p.city,
      p.status.replace('_', ' '),
      p.estimated,
      p.paid,
      p.deferred,
      totalCosts,
      p.sale_price || '',
      p.sale_price ? netProfit : ''
    ];
  });

  // Add totals row
  const totals = properties.reduce(
    (acc, p) => ({
      estimated: acc.estimated + p.estimated,
      paid: acc.paid + p.paid,
      deferred: acc.deferred + p.deferred,
      salePrice: acc.salePrice + (p.sale_price || 0),
    }),
    { estimated: 0, paid: 0, deferred: 0, salePrice: 0 }
  );
  const totalCosts = totals.paid + totals.deferred;
  rows.push([
    'TOTAL',
    '',
    '',
    totals.estimated,
    totals.paid,
    totals.deferred,
    totalCosts,
    totals.salePrice,
    totals.salePrice - totalCosts
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => 
      typeof cell === 'string' && cell.includes(',') ? `"${cell}"` : cell
    ).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}-${format(new Date(), 'yyyy-MM-dd')}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportToPDF(properties: PropertyFinancials[], filename: string = 'financial-report') {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('Financial Report', pageWidth / 2, 20, { align: 'center' });
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${format(new Date(), 'MMMM d, yyyy h:mm a')}`, pageWidth / 2, 28, { align: 'center' });

  // Calculate totals
  const totals = properties.reduce(
    (acc, p) => ({
      estimated: acc.estimated + p.estimated,
      paid: acc.paid + p.paid,
      deferred: acc.deferred + p.deferred,
      salePrice: acc.salePrice + (p.sale_price || 0),
    }),
    { estimated: 0, paid: 0, deferred: 0, salePrice: 0 }
  );
  const totalCosts = totals.paid + totals.deferred;
  const netProfit = totals.salePrice - totalCosts;

  // Summary section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Summary', 14, 42);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const summaryData = [
    ['Total Estimated Costs:', formatCurrency(totals.estimated)],
    ['Total Paid:', formatCurrency(totals.paid)],
    ['Total Deferred:', formatCurrency(totals.deferred)],
    ['Total Sale Prices:', formatCurrency(totals.salePrice)],
    ['Estimated Net Profit:', formatCurrency(netProfit)],
  ];

  autoTable(doc, {
    startY: 46,
    head: [],
    body: summaryData,
    theme: 'plain',
    styles: { fontSize: 10 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 50 },
      1: { halign: 'right', cellWidth: 40 }
    },
    margin: { left: 14 }
  });

  // Properties table
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  const tableStartY = (doc as any).lastAutoTable.finalY + 15;
  doc.text('Property Details', 14, tableStartY);

  const tableData = properties.map(p => {
    const propTotalCosts = p.paid + p.deferred;
    const propNet = (p.sale_price || 0) - propTotalCosts;
    return [
      `${p.address}\n${p.city}`,
      p.status.replace('_', ' '),
      formatCurrency(p.estimated),
      formatCurrency(p.paid),
      formatCurrency(p.deferred),
      p.sale_price ? formatCurrency(p.sale_price) : '—',
      p.sale_price ? formatCurrency(propNet) : '—'
    ];
  });

  // Add totals row
  tableData.push([
    'TOTAL',
    '',
    formatCurrency(totals.estimated),
    formatCurrency(totals.paid),
    formatCurrency(totals.deferred),
    formatCurrency(totals.salePrice),
    formatCurrency(netProfit)
  ]);

  autoTable(doc, {
    startY: tableStartY + 4,
    head: [['Property', 'Status', 'Estimated', 'Paid', 'Deferred', 'Sale Price', 'Est. Net']],
    body: tableData,
    theme: 'striped',
    headStyles: { fillColor: [59, 130, 246], fontSize: 9 },
    styles: { fontSize: 8, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 45 },
      1: { cellWidth: 22 },
      2: { halign: 'right', cellWidth: 22 },
      3: { halign: 'right', cellWidth: 22 },
      4: { halign: 'right', cellWidth: 22 },
      5: { halign: 'right', cellWidth: 25 },
      6: { halign: 'right', cellWidth: 22 }
    },
    foot: [],
    didParseCell: (data) => {
      // Style the totals row
      if (data.row.index === tableData.length - 1) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [229, 231, 235];
      }
    }
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(
      `Page ${i} of ${pageCount} | Aloha Senior 411 - Confidential`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 10,
      { align: 'center' }
    );
  }

  doc.save(`${filename}-${format(new Date(), 'yyyy-MM-dd')}.pdf`);
}
