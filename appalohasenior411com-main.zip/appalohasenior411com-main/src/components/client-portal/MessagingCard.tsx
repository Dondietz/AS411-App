import { Link } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

interface MessagingCardProps {
  propertyId: string;
}

export function MessagingCard({ propertyId }: MessagingCardProps) {
  return (
    <section className="px-4 py-2">
      <Card className="border-border/50 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <MessageCircle className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm">Messaging</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                You're connected with your AS411 coordinator
              </p>
              <Link to={`/messages?property=${propertyId}`}>
                <Input
                  placeholder="Message"
                  className="mt-2 h-9 text-sm bg-muted/50 cursor-pointer"
                  readOnly
                />
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
