interface MobileHeaderProps {
  title?: string;
}

export function MobileHeader({ title = 'AS411' }: MobileHeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-card border-b border-border safe-area-top">
      <div className="flex items-center justify-center h-14 px-4">
        <h1 className="text-xl font-bold text-primary tracking-tight">{title}</h1>
      </div>
    </header>
  );
}
