// Type definitions for the AS411 database

export type PropertyStatus = 'intake' | 'cleanout' | 'repair' | 'listing' | 'escrow' | 'closed';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'blocked';
export type TaskPhase = 'cleanout' | 'repair' | 'listing' | 'escrow' | 'closing';
export type CostType = 'deferred' | 'paid' | 'estimated';
export type AppRole = 'coordinator' | 'contractor' | 'client' | 'admin' | 'investor' | 'accounting';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  full_name: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Contractor {
  id: string;
  company_name: string;
  contact_name?: string;
  email?: string;
  phone?: string;
  specialty?: string;
  hourly_rate?: number;
  notes?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Property {
  id: string;
  address: string;
  city: string;
  state: string;
  zip_code?: string;
  status: PropertyStatus;
  client_id?: string;
  coordinator_id?: string;
  estimated_value?: number;
  listing_price?: number;
  sale_price?: number;
  notes?: string;
  intake_date?: string;
  target_close_date?: string;
  actual_close_date?: string;
  created_at: string;
  updated_at: string;
  // Joined data
  client?: Client;
  coordinator?: Profile;
}

export interface Task {
  id: string;
  property_id: string;
  title: string;
  description?: string;
  phase: TaskPhase;
  status: TaskStatus;
  assigned_to?: string;
  contractor_id?: string;
  due_date?: string;
  completed_at?: string;
  priority: number;
  created_at: string;
  updated_at: string;
  // Joined data
  property?: Property;
  assignee?: Profile;
  contractor?: Contractor;
}

export interface Cost {
  id: string;
  property_id: string;
  description: string;
  amount: number;
  cost_type: CostType;
  category?: string;
  contractor_id?: string;
  invoice_number?: string;
  paid_date?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  // Joined data
  property?: Property;
  contractor?: Contractor;
}

export interface Message {
  id: string;
  property_id: string;
  sender_id?: string;
  content: string;
  message_type: string;
  is_internal: boolean;
  created_at: string;
  // Joined data
  property?: Property;
  sender?: Profile;
}

export interface FileRecord {
  id: string;
  property_id: string;
  file_name: string;
  file_url: string;
  file_type?: string;
  file_size?: number;
  category?: string;
  uploaded_by?: string;
  created_at: string;
  // Joined data
  property?: Property;
  uploader?: Profile;
}

export interface Appointment {
  id: string;
  property_id: string;
  title: string;
  description?: string;
  start_time: string;
  end_time: string;
  attendees?: string[];
  location?: string;
  cal_event_id?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
  // Joined data
  property?: Property;
  creator?: Profile;
}

// Dashboard summary types
export interface DashboardStats {
  activeProperties: number;
  pendingTasks: number;
  upcomingAppointments: number;
  totalDeferredCosts: number;
}

export interface PropertyWithDetails extends Property {
  tasks_count?: number;
  pending_tasks_count?: number;
  total_costs?: number;
  deferred_costs?: number;
}
