import { useEffect, useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatCard } from '@/components/ui/stat-card';
import { PropertyCard } from '@/components/dashboard/PropertyCard';
import { AlertItem } from '@/components/dashboard/AlertItem';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, ListTodo, Calendar, DollarSign, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import type { PropertyWithDetails } from '@/types/database';
import { formatDistanceToNow, differenceInDays, isPast, parseISO } from 'date-fns';

type AlertType = 'warning' | 'urgent' | 'success' | 'info';

interface Alert {
  id: string;
  type: AlertType;
  title: string;
  description: string;
  timestamp: string;
  sortDate: Date;
}

export default function Dashboard() {
  const [properties, setProperties] = useState<PropertyWithDetails[]>([]);
  const [stats, setStats] = useState({ activeProperties: 0, pendingTasks: 0, upcomingAppointments: 0, deferredCosts: 0 });
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      const [propsResult, taskCountResult, costsResult, overdueTasksResult, upcomingClosingsResult, notificationsResult] = await Promise.all([
        supabase.from('properties').select('*, client:clients(*), coordinator:profiles(*)').neq('status', 'closed').order('created_at', { ascending: false }).limit(6),
        supabase.from('tasks').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('costs').select('amount').eq('cost_type', 'deferred'),
        supabase.from('tasks').select('id, title, due_date, property_id, properties(address)').eq('status', 'pending').not('due_date', 'is', null).lt('due_date', new Date().toISOString().split('T')[0]),
        supabase.from('properties').select('id, address, target_close_date').neq('status', 'closed').not('target_close_date', 'is', null).gte('target_close_date', new Date().toISOString().split('T')[0]).order('target_close_date', { ascending: true }).limit(5),
        supabase.from('notifications').select('*').eq('is_read', false).order('created_at', { ascending: false }).limit(10),
      ]);

      setProperties((propsResult.data as PropertyWithDetails[]) || []);
      setStats({
        activeProperties: propsResult.data?.length || 0,
        pendingTasks: taskCountResult.count || 0,
        upcomingAppointments: 3,
        deferredCosts: costsResult.data?.reduce((sum, c) => sum + Number(c.amount), 0) || 0,
      });

      // Build alerts from real data
      const generatedAlerts: Alert[] = [];

      // Overdue tasks
      overdueTasksResult.data?.forEach((task: any) => {
        const dueDate = parseISO(task.due_date);
        const daysOverdue = differenceInDays(new Date(), dueDate);
        generatedAlerts.push({
          id: `task-${task.id}`,
          type: daysOverdue > 7 ? 'urgent' : 'warning',
          title: 'Task overdue',
          description: `${task.title}${task.properties?.address ? ` - ${task.properties.address}` : ''}`,
          timestamp: `${daysOverdue} day${daysOverdue > 1 ? 's' : ''} overdue`,
          sortDate: dueDate,
        });
      });

      // Upcoming closings (within 7 days)
      upcomingClosingsResult.data?.forEach((prop: any) => {
        const closeDate = parseISO(prop.target_close_date);
        const daysUntil = differenceInDays(closeDate, new Date());
        if (daysUntil <= 7) {
          generatedAlerts.push({
            id: `closing-${prop.id}`,
            type: daysUntil <= 3 ? 'urgent' : 'warning',
            title: 'Closing deadline',
            description: `${prop.address} closing in ${daysUntil} day${daysUntil !== 1 ? 's' : ''}`,
            timestamp: formatDistanceToNow(closeDate, { addSuffix: true }),
            sortDate: closeDate,
          });
        }
      });

      // Custom notifications
      notificationsResult.data?.forEach((notif: any) => {
        generatedAlerts.push({
          id: `notif-${notif.id}`,
          type: notif.notification_type as AlertType,
          title: notif.title,
          description: notif.description,
          timestamp: formatDistanceToNow(parseISO(notif.created_at), { addSuffix: true }),
          sortDate: parseISO(notif.created_at),
        });
      });

      // Sort by date (most recent/urgent first)
      generatedAlerts.sort((a, b) => {
        // Urgent items first
        if (a.type === 'urgent' && b.type !== 'urgent') return -1;
        if (b.type === 'urgent' && a.type !== 'urgent') return 1;
        return b.sortDate.getTime() - a.sortDate.getTime();
      });

      setAlerts(generatedAlerts.slice(0, 5));
      setLoading(false);
    }
    fetchData();
  }, []);

  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(amount);

  return (
    <AppLayout title="Aloha Senior 411 Coordinator Dashboard" breadcrumbs={[{ label: 'Dashboard' }]}>
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Active Properties" value={stats.activeProperties} icon={Building2} variant="primary" href="/properties" />
          <StatCard title="Pending Tasks" value={stats.pendingTasks} icon={ListTodo} variant="warning" href="/tasks" />
          <StatCard title="This Week" value={stats.upcomingAppointments} subtitle="Appointments" icon={Calendar} href="/schedule" />
          <StatCard title="Deferred Costs" value={formatCurrency(stats.deferredCosts)} icon={DollarSign} variant="accent" href="/financials" />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold font-display">Active Properties</h2>
              <Button asChild><Link to="/properties"><Plus className="h-4 w-4 mr-1" /> Add Property</Link></Button>
            </div>
            {loading ? (
              <div className="grid gap-4 md:grid-cols-2">{[1,2].map(i => <Card key={i} className="h-48 animate-pulse bg-muted" />)}</div>
            ) : properties.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">{properties.slice(0, 4).map(p => <PropertyCard key={p.id} property={p} />)}</div>
            ) : (
              <Card><CardContent className="py-12 text-center text-muted-foreground">No active properties. Add one to get started.</CardContent></Card>
            )}
          </div>

          <Card>
            <CardHeader><CardTitle className="text-lg">Alerts & Updates</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-16 animate-pulse bg-muted rounded-lg" />)}</div>
              ) : alerts.length > 0 ? (
                alerts.map(alert => (
                  <AlertItem key={alert.id} type={alert.type} title={alert.title} description={alert.description} timestamp={alert.timestamp} />
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No alerts at this time</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
