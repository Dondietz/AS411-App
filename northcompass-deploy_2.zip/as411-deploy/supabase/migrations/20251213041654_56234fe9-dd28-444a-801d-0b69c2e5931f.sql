-- Create communications table for logging all property-related communications
CREATE TABLE public.communications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  communication_type TEXT NOT NULL CHECK (communication_type IN ('phone_call', 'in_person', 'text_message', 'email', 'video_call', 'other')),
  direction TEXT CHECK (direction IN ('inbound', 'outbound')),
  parties_involved TEXT,
  notes TEXT NOT NULL,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.communications ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for coordinators
CREATE POLICY "Coordinators can view communications"
ON public.communications
FOR SELECT
USING (is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage communications"
ON public.communications
FOR ALL
USING (is_coordinator_or_admin(auth.uid()));

-- Create trigger for updated_at
CREATE TRIGGER update_communications_updated_at
BEFORE UPDATE ON public.communications
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for communications
ALTER PUBLICATION supabase_realtime ADD TABLE public.communications;

-- Create index for faster property lookups
CREATE INDEX idx_communications_property_id ON public.communications(property_id);
CREATE INDEX idx_communications_date ON public.communications(date DESC);