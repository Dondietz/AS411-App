-- Create notifications table for custom announcements
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  notification_type TEXT NOT NULL DEFAULT 'info' CHECK (notification_type IN ('info', 'warning', 'urgent', 'success')),
  property_id UUID REFERENCES public.properties(id) ON DELETE CASCADE,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Coordinators and admins can manage notifications
CREATE POLICY "Coordinators can manage notifications"
ON public.notifications
FOR ALL
USING (is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can view notifications"
ON public.notifications
FOR SELECT
USING (is_coordinator_or_admin(auth.uid()));