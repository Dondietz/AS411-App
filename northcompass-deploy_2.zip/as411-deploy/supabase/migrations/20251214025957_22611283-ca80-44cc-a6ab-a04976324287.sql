-- Drop existing policies on clients table
DROP POLICY IF EXISTS "Coordinators can delete clients" ON public.clients;
DROP POLICY IF EXISTS "Coordinators can insert clients" ON public.clients;
DROP POLICY IF EXISTS "Coordinators can update clients" ON public.clients;
DROP POLICY IF EXISTS "Coordinators can view clients" ON public.clients;

-- Recreate policies with explicit auth.uid() IS NOT NULL check
CREATE POLICY "Coordinators can view clients"
ON public.clients FOR SELECT
USING (auth.uid() IS NOT NULL AND is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can insert clients"
ON public.clients FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can update clients"
ON public.clients FOR UPDATE
USING (auth.uid() IS NOT NULL AND is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can delete clients"
ON public.clients FOR DELETE
USING (auth.uid() IS NOT NULL AND is_coordinator_or_admin(auth.uid()));