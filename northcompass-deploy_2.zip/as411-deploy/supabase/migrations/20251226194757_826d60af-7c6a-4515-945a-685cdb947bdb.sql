-- Drop the existing restrictive INSERT policy and recreate as permissive
DROP POLICY IF EXISTS "Coordinators can create threads" ON public.threads;

CREATE POLICY "Coordinators can create threads" 
ON public.threads 
FOR INSERT 
TO authenticated
WITH CHECK (is_coordinator_or_admin(auth.uid()));