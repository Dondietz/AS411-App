DROP POLICY IF EXISTS "Coordinators can create threads" ON public.threads;

CREATE POLICY "Coordinators can create threads"
ON public.threads
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() IS NOT NULL
  AND (
    public.has_role(auth.uid(), 'coordinator'::public.app_role)
    OR public.has_role(auth.uid(), 'admin'::public.app_role)
  )
  AND created_by_user_id = auth.uid()
);