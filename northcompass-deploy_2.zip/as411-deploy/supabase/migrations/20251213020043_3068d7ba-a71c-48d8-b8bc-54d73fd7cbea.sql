-- Create role enum for future multi-role support
CREATE TYPE public.app_role AS ENUM ('coordinator', 'contractor', 'client', 'admin', 'investor', 'accounting');

-- Create property status enum
CREATE TYPE public.property_status AS ENUM ('intake', 'cleanout', 'repair', 'listing', 'escrow', 'closed');

-- Create task status enum  
CREATE TYPE public.task_status AS ENUM ('pending', 'in_progress', 'completed', 'blocked');

-- Create task phase enum
CREATE TYPE public.task_phase AS ENUM ('cleanout', 'repair', 'listing', 'escrow', 'closing');

-- Create cost type enum
CREATE TYPE public.cost_type AS ENUM ('deferred', 'paid', 'estimated');

-- User roles table (separate from profiles for security)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL DEFAULT 'coordinator',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Profiles table for user info
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Clients table
CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  address TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Contractors table
CREATE TABLE public.contractors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL,
  contact_name TEXT,
  email TEXT,
  phone TEXT,
  specialty TEXT,
  hourly_rate DECIMAL(10,2),
  notes TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Properties table
CREATE TABLE public.properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'HI',
  zip_code TEXT,
  status property_status NOT NULL DEFAULT 'intake',
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  coordinator_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  estimated_value DECIMAL(12,2),
  listing_price DECIMAL(12,2),
  sale_price DECIMAL(12,2),
  notes TEXT,
  intake_date DATE DEFAULT CURRENT_DATE,
  target_close_date DATE,
  actual_close_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tasks table
CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  phase task_phase NOT NULL,
  status task_status NOT NULL DEFAULT 'pending',
  assigned_to UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  contractor_id UUID REFERENCES public.contractors(id) ON DELETE SET NULL,
  due_date DATE,
  completed_at TIMESTAMPTZ,
  priority INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Costs table
CREATE TABLE public.costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  cost_type cost_type NOT NULL DEFAULT 'estimated',
  category TEXT,
  contractor_id UUID REFERENCES public.contractors(id) ON DELETE SET NULL,
  invoice_number TEXT,
  paid_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Messages/Communications table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'note',
  is_internal BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Files/Documents table
CREATE TABLE public.files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  category TEXT,
  uploaded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Appointments table for scheduling
CREATE TABLE public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  attendees TEXT[],
  location TEXT,
  cal_event_id TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contractors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Function to check if user is coordinator or admin
CREATE OR REPLACE FUNCTION public.is_coordinator_or_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('coordinator', 'admin')
  )
$$;

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for clients (coordinators/admins only)
CREATE POLICY "Coordinators can view clients" ON public.clients
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can insert clients" ON public.clients
  FOR INSERT TO authenticated WITH CHECK (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can update clients" ON public.clients
  FOR UPDATE TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can delete clients" ON public.clients
  FOR DELETE TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for contractors
CREATE POLICY "Coordinators can view contractors" ON public.contractors
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage contractors" ON public.contractors
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for properties
CREATE POLICY "Coordinators can view properties" ON public.properties
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage properties" ON public.properties
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for tasks
CREATE POLICY "Coordinators can view tasks" ON public.tasks
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage tasks" ON public.tasks
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for costs
CREATE POLICY "Coordinators can view costs" ON public.costs
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage costs" ON public.costs
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for messages
CREATE POLICY "Coordinators can view messages" ON public.messages
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage messages" ON public.messages
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for files
CREATE POLICY "Coordinators can view files" ON public.files
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage files" ON public.files
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- RLS Policies for appointments
CREATE POLICY "Coordinators can view appointments" ON public.appointments
  FOR SELECT TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can manage appointments" ON public.appointments
  FOR ALL TO authenticated USING (public.is_coordinator_or_admin(auth.uid()));

-- Trigger to create profile and role on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.email
  );
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'coordinator');
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contractors_updated_at BEFORE UPDATE ON public.contractors
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON public.properties
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON public.tasks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_costs_updated_at BEFORE UPDATE ON public.costs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;