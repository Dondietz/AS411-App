-- Add caption column to files table
ALTER TABLE public.files ADD COLUMN caption text;