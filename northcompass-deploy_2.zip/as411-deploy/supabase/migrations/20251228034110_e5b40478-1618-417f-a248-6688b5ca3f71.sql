-- Drop overly permissive policies that expose data to all authenticated users
-- The existing role-based policies will properly restrict access

-- Drop from profiles table
DROP POLICY IF EXISTS "Authenticated users only" ON public.profiles;

-- Drop from properties table  
DROP POLICY IF EXISTS "Authenticated users only" ON public.properties;