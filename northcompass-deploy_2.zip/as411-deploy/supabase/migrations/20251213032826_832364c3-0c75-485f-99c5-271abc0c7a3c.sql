-- Add island column to properties
ALTER TABLE public.properties 
ADD COLUMN island TEXT;

-- Add property_type column to properties
ALTER TABLE public.properties 
ADD COLUMN property_type TEXT;