-- Make the property-files bucket public so photos can be viewed
UPDATE storage.buckets
SET public = true
WHERE id = 'property-files';