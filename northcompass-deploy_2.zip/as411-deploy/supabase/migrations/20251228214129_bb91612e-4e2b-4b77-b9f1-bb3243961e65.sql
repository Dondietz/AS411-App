
-- Create trigger function to sync client info to profiles
CREATE OR REPLACE FUNCTION public.sync_client_to_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Only sync if client has a user_id (linked to a profile)
  IF NEW.user_id IS NOT NULL THEN
    UPDATE profiles
    SET 
      phone = COALESCE(NEW.phone, phone),
      full_name = COALESCE(NEW.full_name, full_name)
    WHERE id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger on clients table for INSERT and UPDATE
DROP TRIGGER IF EXISTS sync_client_to_profile_trigger ON clients;

CREATE TRIGGER sync_client_to_profile_trigger
AFTER INSERT OR UPDATE ON clients
FOR EACH ROW
EXECUTE FUNCTION sync_client_to_profile();
