-- Add RLS policy for clients to view appointments on their properties
CREATE POLICY "Clients can view appointments for their properties"
ON public.appointments
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.properties p
    JOIN public.clients c ON c.id = p.client_id
    WHERE p.id = appointments.property_id
      AND c.user_id = auth.uid()
  )
);