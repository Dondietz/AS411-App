-- Create a private storage bucket for property files
INSERT INTO storage.buckets (id, name, public)
VALUES ('property-files', 'property-files', false);

-- Policy: Coordinators/admins can upload files
CREATE POLICY "Coordinators can upload files"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'property-files' AND
  auth.uid() IS NOT NULL AND
  is_coordinator_or_admin(auth.uid())
);

-- Policy: Coordinators/admins can view files
CREATE POLICY "Coordinators can view files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'property-files' AND
  auth.uid() IS NOT NULL AND
  is_coordinator_or_admin(auth.uid())
);

-- Policy: Coordinators/admins can update files
CREATE POLICY "Coordinators can update files"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'property-files' AND
  auth.uid() IS NOT NULL AND
  is_coordinator_or_admin(auth.uid())
);

-- Policy: Coordinators/admins can delete files
CREATE POLICY "Coordinators can delete files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'property-files' AND
  auth.uid() IS NOT NULL AND
  is_coordinator_or_admin(auth.uid())
);