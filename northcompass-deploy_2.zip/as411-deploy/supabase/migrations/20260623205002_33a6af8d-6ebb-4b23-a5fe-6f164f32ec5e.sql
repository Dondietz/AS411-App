
-- 1) Create private schema for SECURITY DEFINER internals
CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;

-- 2) Move SECURITY DEFINER functions out of public (preserves OIDs so RLS policies/triggers still bind)
ALTER FUNCTION public.has_role(uuid, public.app_role) SET SCHEMA private;
ALTER FUNCTION public.is_admin(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_coordinator_or_admin(uuid) SET SCHEMA private;
ALTER FUNCTION public.is_thread_participant(uuid, uuid) SET SCHEMA private;
ALTER FUNCTION public.handle_new_user() SET SCHEMA private;
ALTER FUNCTION public.set_thread_last_message_at() SET SCHEMA private;
ALTER FUNCTION public.sync_client_to_profile() SET SCHEMA private;
ALTER FUNCTION public.create_default_client_thread() SET SCHEMA private;
ALTER FUNCTION public.create_client_thread_on_property() SET SCHEMA private;
ALTER FUNCTION public.get_invitation_by_token(uuid) SET SCHEMA private;
ALTER FUNCTION public.create_thread(uuid, public.thread_type, text) SET SCHEMA private;

-- 3) Lock down execute on private functions (PUBLIC carries over from the public schema grants)
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA private FROM PUBLIC;

-- RLS helpers: needed by policies evaluated for anon/authenticated/service_role
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION private.is_admin(uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION private.is_coordinator_or_admin(uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION private.is_thread_participant(uuid, uuid) TO anon, authenticated, service_role;

-- Trigger functions: triggers do not require EXECUTE from the firing role, but allow service_role for admin paths
GRANT EXECUTE ON FUNCTION private.handle_new_user() TO service_role;
GRANT EXECUTE ON FUNCTION private.set_thread_last_message_at() TO service_role;
GRANT EXECUTE ON FUNCTION private.sync_client_to_profile() TO service_role;
GRANT EXECUTE ON FUNCTION private.create_default_client_thread() TO service_role;
GRANT EXECUTE ON FUNCTION private.create_client_thread_on_property() TO service_role;

-- RPC-callable functions: keep callable by intended roles via private (wrappers will delegate)
GRANT EXECUTE ON FUNCTION private.create_thread(uuid, public.thread_type, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION private.get_invitation_by_token(uuid) TO anon, authenticated, service_role;

-- 4) Public SECURITY INVOKER wrappers so existing supabase.rpc(...) calls keep working
CREATE OR REPLACE FUNCTION public.create_thread(thread_property_id uuid, thread_type_in public.thread_type, thread_title text)
RETURNS uuid
LANGUAGE sql
SECURITY INVOKER
SET search_path = public, private
AS $$ SELECT private.create_thread(thread_property_id, thread_type_in, thread_title) $$;

CREATE OR REPLACE FUNCTION public.get_invitation_by_token(invitation_token uuid)
RETURNS TABLE(id uuid, client_id uuid, property_id uuid, expires_at timestamptz, accepted_at timestamptz)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public, private
AS $$ SELECT * FROM private.get_invitation_by_token(invitation_token) $$;

REVOKE EXECUTE ON FUNCTION public.create_thread(uuid, public.thread_type, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_invitation_by_token(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_thread(uuid, public.thread_type, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_invitation_by_token(uuid) TO anon, authenticated, service_role;

-- 5) Drop overly broad property-files storage policies (scoped coordinator/client policies remain)
DROP POLICY IF EXISTS "Authenticated users can upload property files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can view property files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete property files" ON storage.objects;
