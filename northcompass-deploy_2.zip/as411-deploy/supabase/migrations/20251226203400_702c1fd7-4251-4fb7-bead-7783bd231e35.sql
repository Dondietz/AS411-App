-- Create a SECURITY DEFINER function to create threads (avoids RLS insert issues)
CREATE OR REPLACE FUNCTION public.create_thread(
  thread_property_id uuid,
  thread_type_in public.thread_type,
  thread_title text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_thread_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF NOT (public.has_role(auth.uid(), 'coordinator'::public.app_role) OR public.has_role(auth.uid(), 'admin'::public.app_role)) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  INSERT INTO public.threads (property_id, thread_type, title, created_by_user_id)
  VALUES (thread_property_id, thread_type_in, thread_title, auth.uid())
  RETURNING id INTO new_thread_id;

  RETURN new_thread_id;
END;
$$;

-- Ensure authenticated users can call it
GRANT EXECUTE ON FUNCTION public.create_thread(uuid, public.thread_type, text) TO authenticated;