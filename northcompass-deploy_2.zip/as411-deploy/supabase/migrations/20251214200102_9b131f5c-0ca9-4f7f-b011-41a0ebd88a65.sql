-- Create a trigger function to auto-create client thread when a property gets a client assigned
CREATE OR REPLACE FUNCTION public.create_client_thread_on_property()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_client_name text;
  v_thread_id uuid;
  v_coordinator_id uuid;
BEGIN
  -- Only proceed if client_id is being set (not null) and either:
  -- 1. It's an INSERT with a client_id, or
  -- 2. It's an UPDATE where client_id changed from null or a different value
  IF NEW.client_id IS NOT NULL AND (
    TG_OP = 'INSERT' OR 
    (TG_OP = 'UPDATE' AND (OLD.client_id IS NULL OR OLD.client_id != NEW.client_id))
  ) THEN
    -- Get client name
    SELECT full_name INTO v_client_name
    FROM public.clients
    WHERE id = NEW.client_id;
    
    -- Determine coordinator (use property's coordinator or the current user)
    v_coordinator_id := COALESCE(NEW.coordinator_id, auth.uid());
    
    -- Check if a client_coord thread already exists for this property
    SELECT id INTO v_thread_id
    FROM public.threads
    WHERE property_id = NEW.id AND thread_type = 'client_coord'
    LIMIT 1;
    
    -- Only create if no client thread exists
    IF v_thread_id IS NULL AND v_coordinator_id IS NOT NULL THEN
      -- Create the thread
      INSERT INTO public.threads (
        property_id,
        thread_type,
        title,
        created_by_user_id
      ) VALUES (
        NEW.id,
        'client_coord',
        COALESCE(v_client_name, 'Client') || ' ↔ Coordinator',
        v_coordinator_id
      )
      RETURNING id INTO v_thread_id;
      
      -- Add coordinator as participant
      INSERT INTO public.thread_participants (
        thread_id,
        user_id,
        role
      ) VALUES (
        v_thread_id,
        v_coordinator_id,
        'coordinator'
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS create_client_thread_trigger ON public.properties;
CREATE TRIGGER create_client_thread_trigger
  AFTER INSERT OR UPDATE OF client_id ON public.properties
  FOR EACH ROW
  EXECUTE FUNCTION public.create_client_thread_on_property();