-- Add base authentication requirement for clients table
-- Using TO authenticated ensures only logged-in users can access
CREATE POLICY "Authenticated users only" 
ON public.clients 
FOR SELECT 
TO authenticated 
USING (true);