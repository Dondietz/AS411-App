-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Anyone can view invitation by token" ON public.client_invitations;

-- Create a secure function to validate invitation by token (doesn't expose email)
CREATE OR REPLACE FUNCTION public.get_invitation_by_token(invitation_token uuid)
RETURNS TABLE (
  id uuid,
  client_id uuid,
  property_id uuid,
  expires_at timestamptz,
  accepted_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, client_id, property_id, expires_at, accepted_at
  FROM public.client_invitations
  WHERE token = invitation_token
    AND expires_at > now()
    AND accepted_at IS NULL;
$$;