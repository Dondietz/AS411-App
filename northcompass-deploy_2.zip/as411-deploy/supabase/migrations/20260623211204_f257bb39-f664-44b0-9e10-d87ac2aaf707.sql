
-- 1. client_invitations: allow reading invitation by token (non-expired, non-accepted)
CREATE POLICY "Anyone can read valid invitation by token"
ON public.client_invitations
FOR SELECT
TO anon, authenticated
USING (accepted_at IS NULL AND expires_at > now());

GRANT SELECT ON public.client_invitations TO anon;

-- 2. thread_messages: coordinators can delete, senders can delete own messages
CREATE POLICY "Coordinators can delete thread messages"
ON public.thread_messages
FOR DELETE
TO authenticated
USING (private.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Users can delete own messages"
ON public.thread_messages
FOR DELETE
TO authenticated
USING (sender_user_id = auth.uid());

-- 3. contractor-documents storage: contractors can SELECT/UPDATE/DELETE own folder
CREATE POLICY "Contractors can view own documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'contractor-documents'
  AND EXISTS (
    SELECT 1 FROM public.contractors c
    WHERE c.user_id = auth.uid()
      AND (storage.foldername(name))[1] = c.id::text
  )
);

CREATE POLICY "Contractors can update own documents"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'contractor-documents'
  AND EXISTS (
    SELECT 1 FROM public.contractors c
    WHERE c.user_id = auth.uid()
      AND (storage.foldername(name))[1] = c.id::text
  )
);

CREATE POLICY "Contractors can delete own documents"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'contractor-documents'
  AND EXISTS (
    SELECT 1 FROM public.contractors c
    WHERE c.user_id = auth.uid()
      AND (storage.foldername(name))[1] = c.id::text
  )
);
