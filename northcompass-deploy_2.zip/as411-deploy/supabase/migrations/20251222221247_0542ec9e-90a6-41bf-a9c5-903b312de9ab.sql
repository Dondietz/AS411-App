-- Add user_id to clients table to link with auth users
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Create unique constraint on user_id
ALTER TABLE public.clients 
ADD CONSTRAINT clients_user_id_unique UNIQUE (user_id);

-- Add is_milestone column to tasks for client-visible tasks
ALTER TABLE public.tasks 
ADD COLUMN IF NOT EXISTS is_milestone boolean DEFAULT false;

-- Create client invitations table
CREATE TABLE IF NOT EXISTS public.client_invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  property_id uuid REFERENCES public.properties(id) ON DELETE CASCADE NOT NULL,
  email text NOT NULL,
  token uuid DEFAULT gen_random_uuid() NOT NULL UNIQUE,
  invited_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  expires_at timestamp with time zone DEFAULT (now() + interval '7 days') NOT NULL,
  accepted_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Enable RLS on client_invitations
ALTER TABLE public.client_invitations ENABLE ROW LEVEL SECURITY;

-- RLS: Coordinators can manage invitations
CREATE POLICY "Coordinators can manage invitations"
ON public.client_invitations
FOR ALL
USING (is_coordinator_or_admin(auth.uid()));

-- RLS: Anyone can view invitation by token (for accepting)
CREATE POLICY "Anyone can view invitation by token"
ON public.client_invitations
FOR SELECT
USING (true);

-- Update clients RLS to allow clients to view their own record
CREATE POLICY "Clients can view own client record"
ON public.clients
FOR SELECT
USING (user_id = auth.uid());

-- Update properties RLS to allow clients to view their assigned properties
CREATE POLICY "Clients can view their properties"
ON public.properties
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.clients c 
    WHERE c.id = properties.client_id 
    AND c.user_id = auth.uid()
  )
);

-- Update tasks RLS to allow clients to view milestone tasks for their properties
CREATE POLICY "Clients can view milestone tasks for their properties"
ON public.tasks
FOR SELECT
USING (
  is_milestone = true AND
  EXISTS (
    SELECT 1 FROM public.properties p
    JOIN public.clients c ON c.id = p.client_id
    WHERE p.id = tasks.property_id
    AND c.user_id = auth.uid()
  )
);

-- Update files RLS to allow clients to view files for their properties
CREATE POLICY "Clients can view files for their properties"
ON public.files
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.properties p
    JOIN public.clients c ON c.id = p.client_id
    WHERE p.id = files.property_id
    AND c.user_id = auth.uid()
  )
);

-- Update threads RLS to allow clients to view their threads
CREATE POLICY "Clients can view their threads"
ON public.threads
FOR SELECT
USING (
  thread_type = 'client_coord' AND
  EXISTS (
    SELECT 1 FROM public.thread_participants tp
    WHERE tp.thread_id = threads.id
    AND tp.user_id = auth.uid()
  )
);