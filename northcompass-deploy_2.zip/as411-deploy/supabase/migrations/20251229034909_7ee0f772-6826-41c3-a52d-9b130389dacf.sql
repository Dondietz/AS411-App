-- Create notification_history table to track all sent invitations, emails, and SMS
CREATE TABLE public.notification_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  property_id uuid REFERENCES public.properties(id) ON DELETE SET NULL,
  notification_type text NOT NULL, -- 'email', 'sms', 'invitation'
  channel text NOT NULL, -- 'email', 'sms'
  recipient text NOT NULL, -- email address or phone number
  subject text,
  message_preview text,
  status text NOT NULL DEFAULT 'sent', -- 'sent', 'failed', 'pending'
  error_message text,
  sent_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notification_history ENABLE ROW LEVEL SECURITY;

-- Coordinators can view and manage notification history
CREATE POLICY "Coordinators can view notification history"
ON public.notification_history
FOR SELECT
USING (is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can insert notification history"
ON public.notification_history
FOR INSERT
WITH CHECK (is_coordinator_or_admin(auth.uid()));

-- Create index for faster queries
CREATE INDEX idx_notification_history_client_id ON public.notification_history(client_id);
CREATE INDEX idx_notification_history_created_at ON public.notification_history(created_at DESC);