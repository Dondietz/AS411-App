-- Create enum for bid status
CREATE TYPE public.bid_status AS ENUM ('pending', 'accepted', 'rejected', 'expired');

-- Create contractor bids table
CREATE TABLE public.contractor_bids (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  contractor_id UUID NOT NULL REFERENCES public.contractors(id) ON DELETE CASCADE,
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  
  -- Bid details
  amount NUMERIC NOT NULL,
  description TEXT NOT NULL,
  scope_of_work TEXT,
  
  -- Timeline
  estimated_start_date DATE,
  estimated_duration_days INTEGER,
  
  -- Attachments
  attachment_url TEXT,
  attachment_name TEXT,
  
  -- Status tracking
  status public.bid_status NOT NULL DEFAULT 'pending',
  status_changed_at TIMESTAMP WITH TIME ZONE,
  status_changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for faster lookups
CREATE INDEX idx_contractor_bids_contractor ON public.contractor_bids(contractor_id);
CREATE INDEX idx_contractor_bids_property ON public.contractor_bids(property_id);
CREATE INDEX idx_contractor_bids_status ON public.contractor_bids(status);
CREATE INDEX idx_contractor_bids_created ON public.contractor_bids(created_at DESC);

-- Enable RLS
ALTER TABLE public.contractor_bids ENABLE ROW LEVEL SECURITY;

-- RLS policies: Only coordinators/admins can manage bids
CREATE POLICY "Coordinators can manage contractor bids"
  ON public.contractor_bids
  FOR ALL
  USING (is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can view contractor bids"
  ON public.contractor_bids
  FOR SELECT
  USING (is_coordinator_or_admin(auth.uid()));

-- Add trigger for updated_at
CREATE TRIGGER update_contractor_bids_updated_at
  BEFORE UPDATE ON public.contractor_bids
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();