-- Add user_id to contractors table to link contractor companies to user accounts
ALTER TABLE public.contractors
ADD COLUMN user_id uuid REFERENCES auth.users(id);

-- Create index for faster lookups
CREATE INDEX idx_contractors_user_id ON public.contractors(user_id);

-- RLS policy: Contractors can view their own contractor record
CREATE POLICY "Contractors can view own record"
ON public.contractors
FOR SELECT
USING (user_id = auth.uid());

-- RLS policy: Contractors can view their own bids
CREATE POLICY "Contractors can view own bids"
ON public.contractor_bids
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM contractors c
    WHERE c.id = contractor_bids.contractor_id
    AND c.user_id = auth.uid()
  )
);

-- RLS policy: Contractors can view their own communications
CREATE POLICY "Contractors can view own communications"
ON public.contractor_communications
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM contractors c
    WHERE c.id = contractor_communications.contractor_id
    AND c.user_id = auth.uid()
  )
);

-- RLS policy: Contractors can view properties they have bids on
CREATE POLICY "Contractors can view properties with their bids"
ON public.properties
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM contractor_bids cb
    JOIN contractors c ON c.id = cb.contractor_id
    WHERE cb.property_id = properties.id
    AND c.user_id = auth.uid()
  )
);

-- RLS policy: Contractors can view files for properties they work on
CREATE POLICY "Contractors can view files for their properties"
ON public.files
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM contractor_bids cb
    JOIN contractors c ON c.id = cb.contractor_id
    WHERE cb.property_id = files.property_id
    AND c.user_id = auth.uid()
  )
);