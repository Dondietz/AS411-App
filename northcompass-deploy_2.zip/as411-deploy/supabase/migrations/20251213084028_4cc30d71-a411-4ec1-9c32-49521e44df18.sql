-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;

-- Users can only view their own profile
CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

-- Coordinators and admins can view all profiles
CREATE POLICY "Coordinators can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (is_coordinator_or_admin(auth.uid()));