-- Create contractor communications table for tracking SMS and document sends
CREATE TABLE public.contractor_communications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  contractor_id UUID NOT NULL REFERENCES public.contractors(id) ON DELETE CASCADE,
  property_id UUID REFERENCES public.properties(id) ON DELETE SET NULL,
  sent_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  communication_type TEXT NOT NULL CHECK (communication_type IN ('sms', 'email', 'document')),
  subject TEXT,
  message TEXT NOT NULL,
  document_url TEXT,
  document_name TEXT,
  recipient_phone TEXT,
  recipient_email TEXT,
  status TEXT NOT NULL DEFAULT 'sent',
  error_message TEXT,
  twilio_sid TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX idx_contractor_communications_contractor ON public.contractor_communications(contractor_id);
CREATE INDEX idx_contractor_communications_property ON public.contractor_communications(property_id);
CREATE INDEX idx_contractor_communications_created ON public.contractor_communications(created_at DESC);

-- Enable RLS
ALTER TABLE public.contractor_communications ENABLE ROW LEVEL SECURITY;

-- RLS policies: Only coordinators/admins can manage
CREATE POLICY "Coordinators can manage contractor communications"
  ON public.contractor_communications
  FOR ALL
  USING (is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can view contractor communications"
  ON public.contractor_communications
  FOR SELECT
  USING (is_coordinator_or_admin(auth.uid()));

-- Create storage bucket for contractor documents (RFPs, etc.)
INSERT INTO storage.buckets (id, name, public)
VALUES ('contractor-documents', 'contractor-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for contractor documents
CREATE POLICY "Coordinators can upload contractor documents"
  ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'contractor-documents' 
    AND is_coordinator_or_admin(auth.uid())
  );

CREATE POLICY "Coordinators can view contractor documents"
  ON storage.objects
  FOR SELECT
  USING (
    bucket_id = 'contractor-documents' 
    AND is_coordinator_or_admin(auth.uid())
  );

CREATE POLICY "Coordinators can delete contractor documents"
  ON storage.objects
  FOR DELETE
  USING (
    bucket_id = 'contractor-documents' 
    AND is_coordinator_or_admin(auth.uid())
  );