
-- Update the trigger function to also add client as participant
CREATE OR REPLACE FUNCTION public.create_client_thread_on_property()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_client_name text;
  v_client_user_id uuid;
  v_thread_id uuid;
  v_coordinator_id uuid;
BEGIN
  -- Only proceed if client_id is being set (not null) and either:
  -- 1. It's an INSERT with a client_id, or
  -- 2. It's an UPDATE where client_id changed from null or a different value
  IF NEW.client_id IS NOT NULL AND (
    TG_OP = 'INSERT' OR 
    (TG_OP = 'UPDATE' AND (OLD.client_id IS NULL OR OLD.client_id != NEW.client_id))
  ) THEN
    -- Get client name and user_id
    SELECT full_name, user_id INTO v_client_name, v_client_user_id
    FROM public.clients
    WHERE id = NEW.client_id;
    
    -- Determine coordinator (use property's coordinator or the current user)
    v_coordinator_id := COALESCE(NEW.coordinator_id, auth.uid());
    
    -- Check if a client_coord thread already exists for this property
    SELECT id INTO v_thread_id
    FROM public.threads
    WHERE property_id = NEW.id AND thread_type = 'client_coord'
    LIMIT 1;
    
    -- Only create if no client thread exists
    IF v_thread_id IS NULL AND v_coordinator_id IS NOT NULL THEN
      -- Create the thread
      INSERT INTO public.threads (
        property_id,
        thread_type,
        title,
        created_by_user_id
      ) VALUES (
        NEW.id,
        'client_coord',
        COALESCE(v_client_name, 'Client') || ' ↔ Coordinator',
        v_coordinator_id
      )
      RETURNING id INTO v_thread_id;
      
      -- Add coordinator as participant
      INSERT INTO public.thread_participants (
        thread_id,
        user_id,
        role
      ) VALUES (
        v_thread_id,
        v_coordinator_id,
        'coordinator'
      );
      
      -- Add client as participant if they have a user account
      IF v_client_user_id IS NOT NULL THEN
        INSERT INTO public.thread_participants (
          thread_id,
          user_id,
          role
        ) VALUES (
          v_thread_id,
          v_client_user_id,
          'client'
        );
      END IF;
    ELSE
      -- Thread exists, check if client needs to be added as participant
      IF v_client_user_id IS NOT NULL AND v_thread_id IS NOT NULL THEN
        -- Only add if not already a participant
        INSERT INTO public.thread_participants (thread_id, user_id, role)
        VALUES (v_thread_id, v_client_user_id, 'client')
        ON CONFLICT DO NOTHING;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Add unique constraint to prevent duplicate participants
ALTER TABLE public.thread_participants 
ADD CONSTRAINT thread_participants_thread_user_unique 
UNIQUE (thread_id, user_id);

-- Backfill: Add existing clients to their property threads
INSERT INTO public.thread_participants (thread_id, user_id, role)
SELECT t.id, c.user_id, 'client'::app_role
FROM public.threads t
JOIN public.properties p ON p.id = t.property_id
JOIN public.clients c ON c.id = p.client_id
WHERE t.thread_type = 'client_coord'
  AND c.user_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM public.thread_participants tp
    WHERE tp.thread_id = t.id AND tp.user_id = c.user_id
  );
