-- Create a helper function to check if user is admin only (more restrictive)
CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = 'admin'
  )
$$;

-- Drop existing policy on user_roles
DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;

-- Recreate SELECT policy with explicit auth check
CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() IS NOT NULL AND auth.uid() = user_id);

-- Add policy for admins to view all roles (needed for admin management)
CREATE POLICY "Admins can view all roles"
ON public.user_roles FOR SELECT
USING (auth.uid() IS NOT NULL AND is_admin(auth.uid()));

-- Add INSERT policy - only admins can assign roles (except trigger-based auto-assignment)
CREATE POLICY "Only admins can insert roles"
ON public.user_roles FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND is_admin(auth.uid()));

-- Add UPDATE policy - only admins can modify roles
CREATE POLICY "Only admins can update roles"
ON public.user_roles FOR UPDATE
USING (auth.uid() IS NOT NULL AND is_admin(auth.uid()));

-- Add DELETE policy - only admins can remove roles
CREATE POLICY "Only admins can delete roles"
ON public.user_roles FOR DELETE
USING (auth.uid() IS NOT NULL AND is_admin(auth.uid()));