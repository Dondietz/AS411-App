-- Create thread type enum
CREATE TYPE public.thread_type AS ENUM ('client_coord', 'contractor_coord', 'internal');

-- Create message type enum  
CREATE TYPE public.message_type AS ENUM ('text', 'image', 'file', 'system');

-- Create threads table
CREATE TABLE public.threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  thread_type thread_type NOT NULL,
  title TEXT NOT NULL,
  created_by_user_id UUID REFERENCES public.profiles(id),
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  is_archived BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create thread participants table
CREATE TABLE public.thread_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  last_read_at TIMESTAMP WITH TIME ZONE,
  muted BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(thread_id, user_id)
);

-- Create thread messages table (separate from existing messages table for internal notes)
CREATE TABLE public.thread_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  sender_user_id UUID REFERENCES public.profiles(id),
  sender_role app_role NOT NULL,
  message_type message_type NOT NULL DEFAULT 'text',
  body TEXT NOT NULL,
  attachment_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  edited_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on all tables
ALTER TABLE public.threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.thread_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.thread_messages ENABLE ROW LEVEL SECURITY;

-- Create helper function to check if user is thread participant
CREATE OR REPLACE FUNCTION public.is_thread_participant(_user_id UUID, _thread_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.thread_participants
    WHERE user_id = _user_id AND thread_id = _thread_id
  )
$$;

-- Threads RLS policies
CREATE POLICY "Users can view threads they participate in"
ON public.threads FOR SELECT
USING (public.is_thread_participant(auth.uid(), id));

CREATE POLICY "Coordinators can create threads"
ON public.threads FOR INSERT
WITH CHECK (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can update their threads"
ON public.threads FOR UPDATE
USING (public.is_coordinator_or_admin(auth.uid()));

CREATE POLICY "Coordinators can delete threads"
ON public.threads FOR DELETE
USING (public.is_coordinator_or_admin(auth.uid()));

-- Thread participants RLS policies
CREATE POLICY "Users can view participants of threads they're in"
ON public.thread_participants FOR SELECT
USING (public.is_thread_participant(auth.uid(), thread_id));

CREATE POLICY "Coordinators can manage participants"
ON public.thread_participants FOR ALL
USING (public.is_coordinator_or_admin(auth.uid()));

-- Thread messages RLS policies  
CREATE POLICY "Users can view messages in their threads"
ON public.thread_messages FOR SELECT
USING (public.is_thread_participant(auth.uid(), thread_id));

CREATE POLICY "Users can send messages in their threads"
ON public.thread_messages FOR INSERT
WITH CHECK (public.is_thread_participant(auth.uid(), thread_id));

CREATE POLICY "Users can update own messages"
ON public.thread_messages FOR UPDATE
USING (sender_user_id = auth.uid());

-- Create indexes for performance
CREATE INDEX idx_threads_property_id ON public.threads(property_id);
CREATE INDEX idx_threads_last_message_at ON public.threads(last_message_at DESC);
CREATE INDEX idx_thread_participants_user_id ON public.thread_participants(user_id);
CREATE INDEX idx_thread_participants_thread_id ON public.thread_participants(thread_id);
CREATE INDEX idx_thread_messages_thread_id ON public.thread_messages(thread_id);
CREATE INDEX idx_thread_messages_created_at ON public.thread_messages(created_at DESC);

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.thread_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.threads;

-- Create trigger for updated_at
CREATE TRIGGER update_threads_updated_at
  BEFORE UPDATE ON public.threads
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();