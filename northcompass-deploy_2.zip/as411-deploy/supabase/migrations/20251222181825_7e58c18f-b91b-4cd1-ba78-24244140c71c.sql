-- Add storage policies for property-files bucket to allow authenticated users to upload/view

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload property files"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'property-files' 
  AND auth.uid() IS NOT NULL
);

-- Allow authenticated users to view files
CREATE POLICY "Authenticated users can view property files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'property-files' 
  AND auth.uid() IS NOT NULL
);

-- Allow authenticated users to delete their own files
CREATE POLICY "Authenticated users can delete property files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'property-files' 
  AND auth.uid() IS NOT NULL
);