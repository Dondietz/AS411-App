-- 1. Make the property-files storage bucket private
UPDATE storage.buckets SET public = false WHERE id = 'property-files';

-- 2. Drop the overly permissive "Authenticated users only" policy on clients table
DROP POLICY IF EXISTS "Authenticated users only" ON public.clients;

-- 3. Add storage RLS policies for property-files bucket
-- Allow coordinators/admins to manage all files
CREATE POLICY "Coordinators can manage property files"
ON storage.objects
FOR ALL
USING (
  bucket_id = 'property-files' 
  AND public.is_coordinator_or_admin(auth.uid())
);

-- Allow clients to view files for their own properties
CREATE POLICY "Clients can view their property files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'property-files'
  AND EXISTS (
    SELECT 1 FROM properties p
    JOIN clients c ON c.id = p.client_id
    WHERE c.user_id = auth.uid()
    AND (storage.foldername(name))[1] = p.id::text
  )
);