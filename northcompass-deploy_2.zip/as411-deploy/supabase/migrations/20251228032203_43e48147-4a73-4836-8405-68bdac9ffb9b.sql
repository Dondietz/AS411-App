-- Add a permissive policy that requires authentication as a base requirement
-- This ensures no unauthenticated access is possible
CREATE POLICY "Authenticated users only" 
ON public.properties 
FOR SELECT 
TO authenticated 
USING (true);

-- Also add base auth requirement for profiles table to fix both issues
CREATE POLICY "Authenticated users only" 
ON public.profiles 
FOR SELECT 
TO authenticated 
USING (true);