import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface InviteClientRequest {
  clientId: string;
  propertyId: string;
  email: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    // Create client with user's token to verify they are coordinator
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    // Verify the requesting user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      throw new Error("Unauthorized - could not verify user");
    }

    // Check if user is coordinator or admin
    const { data: roles } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["coordinator", "admin"]);

    if (!roles || roles.length === 0) {
      throw new Error("Unauthorized - coordinator access required");
    }

    // Parse request body
    const { clientId, propertyId, email }: InviteClientRequest = await req.json();

    if (!clientId || !propertyId || !email) {
      throw new Error("Missing required fields: clientId, propertyId, email");
    }

    console.log(`Creating invitation for client ${clientId} to property ${propertyId}`);

    // Create admin client for creating user
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Get client details
    const { data: client, error: clientError } = await supabaseAdmin
      .from("clients")
      .select("*")
      .eq("id", clientId)
      .single();

    if (clientError || !client) {
      throw new Error("Client not found");
    }

    // Get property details for context
    const { data: property } = await supabaseAdmin
      .from("properties")
      .select("address, city, state")
      .eq("id", propertyId)
      .single();

    const propertyAddress = property 
      ? `${property.address}, ${property.city}, ${property.state}` 
      : "your property";

    // Check if client already has a user account
    if (client.user_id) {
      throw new Error("Client already has an account");
    }

    // Generate a secure random password (user will reset via email)
    const tempPassword = crypto.randomUUID() + crypto.randomUUID().slice(0, 8) + "Aa1!";

    // Create the user account
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name: client.full_name },
    });

    let userId: string | undefined;
    let isNewUser = false;

    if (createError) {
      // Check if user already exists
      if (createError.message?.includes('already been registered')) {
        console.log("User already exists, looking up existing user");
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers?.users?.find(u => u.email === email);
        if (existingUser) {
          userId = existingUser.id;
          console.log("Found existing user:", userId);
        } else {
          throw new Error("User exists but could not be found");
        }
      } else {
        console.error("Error creating user:", createError);
        throw new Error(createError.message);
      }
    } else {
      userId = newUser.user?.id;
      isNewUser = true;
      console.log("User created successfully:", userId);
    }

    // Generate password reset link
    const siteUrl = Deno.env.get("SITE_URL") || "https://wqbaemfokhekosacmekj.lovable.app";
    let resetLink: string | null = null;

    if (isNewUser) {
      const { data: linkData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
        type: "recovery",
        email,
        options: {
          redirectTo: `${siteUrl}/auth?reset=true`,
        },
      });

      if (resetError) {
        console.error("Error generating reset link:", resetError);
      } else {
        resetLink = linkData?.properties?.action_link || null;
        console.log("Password reset link generated");
      }
    }

    // Update client with user_id
    const { error: updateClientError } = await supabaseAdmin
      .from("clients")
      .update({ user_id: userId })
      .eq("id", clientId);

    if (updateClientError) {
      console.error("Error updating client:", updateClientError);
    }

    // Update the user's role to 'client' (upsert in case it doesn't exist)
    const { error: updateRoleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId, role: "client" }, { onConflict: "user_id" });

    if (updateRoleError) {
      console.error("Error updating role:", updateRoleError);
    }

    // Create invitation record
    const { data: invitation, error: inviteError } = await supabaseAdmin
      .from("client_invitations")
      .insert({
        client_id: clientId,
        property_id: propertyId,
        email,
        invited_by: user.id,
      })
      .select()
      .single();

    if (inviteError) {
      console.error("Error creating invitation:", inviteError);
    }

    // Add client as participant to existing client_coord thread if exists
    const { data: existingThread } = await supabaseAdmin
      .from("threads")
      .select("id")
      .eq("property_id", propertyId)
      .eq("thread_type", "client_coord")
      .single();

    if (existingThread && userId) {
      await supabaseAdmin
        .from("thread_participants")
        .insert({
          thread_id: existingThread.id,
          user_id: userId,
          role: "client",
        });
      console.log("Added client to existing thread");
    }

    // Send email and SMS notifications
    let emailSent = false;
    let smsSent = false;
    const notificationErrors: string[] = [];

    const emailSubject = `Welcome to Aloha Senior 411 - ${propertyAddress}`;
    const emailPreview = `Welcome invitation for ${propertyAddress}`;
    const smsBody = `Aloha Senior 411: You've been invited to access the client portal for ${propertyAddress}. Check your email at ${email} to set your password and get started.`;

    // Send email via Resend
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (resendApiKey && isNewUser) {
      try {
        const resend = new Resend(resendApiKey);
        
        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Welcome to Aloha Senior 411!</h2>
            <p>Hi ${client.full_name},</p>
            <p>You've been invited to access the client portal for <strong>${propertyAddress}</strong>.</p>
            <p>Your account has been created with this email address. To get started, please set your password by clicking the button below:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink || siteUrl}" style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                Set Your Password
              </a>
            </div>
            <p>Once you've set your password, you can log in to view updates, messages, and documents related to your property.</p>
            <p style="color: #666; font-size: 12px; margin-top: 30px;">
              If you didn't expect this invitation, please contact your coordinator.
            </p>
          </div>
        `;

        const emailResponse = await resend.emails.send({
          from: "Aloha Senior 411 <noreply@alohasenior411.com>",
          to: [email],
          subject: emailSubject,
          html: emailHtml,
        });

        console.log("Email sent successfully:", emailResponse);
        emailSent = true;

        // Log email notification
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "invitation",
          channel: "email",
          recipient: email,
          subject: emailSubject,
          message_preview: emailPreview,
          status: "sent",
          sent_by: user.id,
        });
      } catch (emailError: any) {
        console.error("Error sending email:", emailError);
        notificationErrors.push(`Email: ${emailError.message}`);

        // Log failed email
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "invitation",
          channel: "email",
          recipient: email,
          subject: emailSubject,
          message_preview: emailPreview,
          status: "failed",
          error_message: emailError.message,
          sent_by: user.id,
        });
      }
    } else if (!resendApiKey) {
      console.log("RESEND_API_KEY not configured");
      notificationErrors.push("Email service not configured");
    }

    // Send SMS via Twilio
    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioPhoneNumber = Deno.env.get("TWILIO_PHONE_NUMBER");
    const clientPhone = client.phone;

    // Format phone number to E.164 format (e.g., +18087728222)
    const formatPhoneToE164 = (phone: string): string => {
      // Remove all non-digit characters
      const digits = phone.replace(/\D/g, '');
      // If it's 10 digits, assume US and add +1
      if (digits.length === 10) {
        return `+1${digits}`;
      }
      // If it's 11 digits starting with 1, add +
      if (digits.length === 11 && digits.startsWith('1')) {
        return `+${digits}`;
      }
      // If already has country code or other format, just add + if missing
      return phone.startsWith('+') ? phone : `+${digits}`;
    };

    if (twilioAccountSid && twilioAuthToken && twilioPhoneNumber && clientPhone && isNewUser) {
      const formattedToPhone = formatPhoneToE164(clientPhone);
      const formattedFromPhone = formatPhoneToE164(twilioPhoneNumber);
      console.log(`Formatting To phone: ${clientPhone} -> ${formattedToPhone}`);
      console.log(`Formatting From phone: ${twilioPhoneNumber} -> ${formattedFromPhone}`);
      
      try {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`;
        
        const formData = new URLSearchParams();
        formData.append("To", formattedToPhone);
        formData.append("From", formattedFromPhone);
        formData.append("Body", smsBody);

        const smsResponse = await fetch(twilioUrl, {
          method: "POST",
          headers: {
            "Authorization": `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: formData.toString(),
        });

        const smsResult = await smsResponse.json();
        
        if (smsResponse.ok) {
          console.log("SMS sent successfully to:", clientPhone, "SID:", smsResult.sid);
          smsSent = true;

          // Log SMS notification (include Twilio SID so we can trace delivery)
          await supabaseAdmin.from("notification_history").insert({
            client_id: clientId,
            property_id: propertyId,
            notification_type: "invitation",
            channel: "sms",
            recipient: formattedToPhone,
            message_preview: `SID:${smsResult?.sid ?? ""} | ${smsBody}`.substring(0, 140),
            status: "sent",
            sent_by: user.id,
          });
        } else {
          console.error("Twilio error:", smsResult);
          notificationErrors.push(`SMS: ${smsResult.message || 'Unknown error'}`);

          // Log failed SMS
          await supabaseAdmin.from("notification_history").insert({
            client_id: clientId,
            property_id: propertyId,
            notification_type: "invitation",
            channel: "sms",
            recipient: clientPhone,
            message_preview: smsBody.substring(0, 100) + "...",
            status: "failed",
            error_message: smsResult.message || "Unknown Twilio error",
            sent_by: user.id,
          });
        }
      } catch (smsError: any) {
        console.error("Error sending SMS:", smsError);
        notificationErrors.push(`SMS: ${smsError.message}`);

        // Log failed SMS
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "invitation",
          channel: "sms",
          recipient: clientPhone,
          message_preview: smsBody.substring(0, 100) + "...",
          status: "failed",
          error_message: smsError.message,
          sent_by: user.id,
        });
      }
    } else if (!clientPhone) {
      console.log("No phone number for client");
      notificationErrors.push("No client phone number");
    } else if (!twilioAccountSid || !twilioAuthToken || !twilioPhoneNumber) {
      console.log("Twilio not fully configured");
      notificationErrors.push("SMS service not configured");
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: isNewUser 
          ? "Client account created successfully."
          : "Existing user linked to client successfully.",
        emailSent,
        smsSent,
        notificationErrors: notificationErrors.length > 0 ? notificationErrors : undefined,
        user: {
          id: userId,
          email,
        },
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in invite-client function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: error.message.includes("Unauthorized") ? 403 : 400, 
        headers: { "Content-Type": "application/json", ...corsHeaders } 
      }
    );
  }
});
