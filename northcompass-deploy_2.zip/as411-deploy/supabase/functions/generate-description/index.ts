import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PropertyInput {
  address: string;
  city: string;
  state: string;
  zip_code?: string;
  estimated_value?: number;
  listing_price?: number;
  notes?: string;
}

type StyleType = "professional" | "warm" | "luxury" | "concise";

const stylePrompts: Record<StyleType, string> = {
  professional: "Write in a professional, polished real estate style suitable for MLS listings.",
  warm: "Write in a warm, welcoming tone that emphasizes the home's comfort and livability.",
  luxury: "Write in an elegant, sophisticated tone highlighting premium features and exclusivity.",
  concise: "Write a brief, punchy description focusing on key selling points."
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { property, style = "professional" } = await req.json() as { property: PropertyInput; style?: string };
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Generating description for property:", property.address);

    const validStyle = (Object.keys(stylePrompts).includes(style) ? style : "professional") as StyleType;

    const systemPrompt = `You are an expert real estate copywriter specializing in senior home transitions in Hawaii. 
Generate compelling property descriptions that highlight the home's best features while being honest and accurate.
${stylePrompts[validStyle]}
Focus on: location benefits, home features, lifestyle appeal, and emotional connection.
Keep descriptions between 150-250 words.
Do not use excessive adjectives or clichés like "nestled" or "boasts".`;

    const userPrompt = `Generate a property listing description for:

Address: ${property.address}, ${property.city}, ${property.state} ${property.zip_code || ''}
Estimated Value: ${property.estimated_value ? `$${Number(property.estimated_value).toLocaleString()}` : 'Not specified'}
${property.listing_price ? `Listing Price: $${Number(property.listing_price).toLocaleString()}` : ''}

Additional notes about the property:
${property.notes || 'No additional details provided.'}

Please write a compelling, accurate description for this Hawaii property.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("Failed to generate description");
    }

    const data = await response.json();
    const description = data.choices?.[0]?.message?.content;

    console.log("Description generated successfully");

    return new Response(
      JSON.stringify({ description }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error generating description:", error);
    const errorMessage = error instanceof Error ? error.message : "Failed to generate description";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
