import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ResendInviteRequest {
  clientId: string;
  propertyId: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    // Create client with user's token to verify they are coordinator
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    // Verify the requesting user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      throw new Error("Unauthorized - could not verify user");
    }

    // Check if user is coordinator or admin
    const { data: roles } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["coordinator", "admin"]);

    if (!roles || roles.length === 0) {
      throw new Error("Unauthorized - coordinator access required");
    }

    // Parse request body
    const { clientId, propertyId }: ResendInviteRequest = await req.json();

    if (!clientId || !propertyId) {
      throw new Error("Missing required fields: clientId, propertyId");
    }

    console.log(`Resending invitation for client ${clientId}`);

    // Create admin client
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Get client details
    const { data: client, error: clientError } = await supabaseAdmin
      .from("clients")
      .select("*")
      .eq("id", clientId)
      .single();

    if (clientError || !client) {
      throw new Error("Client not found");
    }

    if (!client.user_id) {
      throw new Error("Client does not have an account yet. Use the invite flow first.");
    }

    // Get client's email from profiles
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("email")
      .eq("id", client.user_id)
      .single();

    const clientEmail = profile?.email || client.email;

    if (!clientEmail) {
      throw new Error("No email address found for client");
    }

    // Get property details for context
    const { data: property } = await supabaseAdmin
      .from("properties")
      .select("address, city, state")
      .eq("id", propertyId)
      .single();

    const propertyAddress = property 
      ? `${property.address}, ${property.city}, ${property.state}` 
      : "your property";

    // Generate password reset link
    const siteUrl = Deno.env.get("SITE_URL") || "https://wqbaemfokhekosacmekj.lovable.app";
    let resetLink: string | null = null;

    const { data: linkData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
      type: "recovery",
      email: clientEmail,
      options: {
        redirectTo: `${siteUrl}/auth?reset=true`,
      },
    });

    if (resetError) {
      console.error("Error generating reset link:", resetError);
    } else {
      resetLink = linkData?.properties?.action_link || null;
      console.log("Password reset link generated");
    }

    let emailSent = false;
    let smsSent = false;
    const notificationErrors: string[] = [];

    const emailSubject = `Reminder: Access Your Client Portal - ${propertyAddress}`;
    const emailPreview = `Reminder invitation for ${propertyAddress}`;
    const smsBody = `Aloha Senior 411: Reminder - You have access to the client portal for ${propertyAddress}. Check your email at ${clientEmail} to set your password and get started.`;

    // Send email via Resend
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (resendApiKey) {
      try {
        const resend = new Resend(resendApiKey);
        
        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Welcome to Aloha Senior 411!</h2>
            <p>Hi ${client.full_name},</p>
            <p>This is a reminder about your access to the client portal for <strong>${propertyAddress}</strong>.</p>
            <p>If you haven't set your password yet, please click the button below:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink || siteUrl}" style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                Set Your Password
              </a>
            </div>
            <p>Once you've set your password, you can log in to view updates, messages, and documents related to your property.</p>
            <p style="color: #666; font-size: 12px; margin-top: 30px;">
              If you didn't expect this invitation, please contact your coordinator.
            </p>
          </div>
        `;

        const emailResponse = await resend.emails.send({
          from: "Aloha Senior 411 <noreply@alohasenior411.com>",
          to: [clientEmail],
          subject: emailSubject,
          html: emailHtml,
        });

        console.log("Email sent successfully:", emailResponse);
        emailSent = true;

        // Log email notification
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "resend_invitation",
          channel: "email",
          recipient: clientEmail,
          subject: emailSubject,
          message_preview: emailPreview,
          status: "sent",
          sent_by: user.id,
        });
      } catch (emailError: any) {
        console.error("Error sending email:", emailError);
        notificationErrors.push(`Email: ${emailError.message}`);

        // Log failed email
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "resend_invitation",
          channel: "email",
          recipient: clientEmail,
          subject: emailSubject,
          message_preview: emailPreview,
          status: "failed",
          error_message: emailError.message,
          sent_by: user.id,
        });
      }
    } else {
      console.log("RESEND_API_KEY not configured");
      notificationErrors.push("Email service not configured");
    }

    // Send SMS via Twilio
    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioPhoneNumber = Deno.env.get("TWILIO_PHONE_NUMBER");
    const clientPhone = client.phone;

    // Format phone number to E.164 format (e.g., +18087728222)
    const formatPhoneToE164 = (phone: string): string => {
      // Remove all non-digit characters
      const digits = phone.replace(/\D/g, '');
      // If it's 10 digits, assume US and add +1
      if (digits.length === 10) {
        return `+1${digits}`;
      }
      // If it's 11 digits starting with 1, add +
      if (digits.length === 11 && digits.startsWith('1')) {
        return `+${digits}`;
      }
      // If already has country code or other format, just add + if missing
      return phone.startsWith('+') ? phone : `+${digits}`;
    };

    if (twilioAccountSid && twilioAuthToken && twilioPhoneNumber && clientPhone) {
      const formattedToPhone = formatPhoneToE164(clientPhone);
      const formattedFromPhone = formatPhoneToE164(twilioPhoneNumber);
      console.log(`Formatting To phone: ${clientPhone} -> ${formattedToPhone}`);
      console.log(`Formatting From phone: ${twilioPhoneNumber} -> ${formattedFromPhone}`);

      try {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`;
        
        const formData = new URLSearchParams();
        formData.append("To", formattedToPhone);
        formData.append("From", formattedFromPhone);
        formData.append("Body", smsBody);

        const smsResponse = await fetch(twilioUrl, {
          method: "POST",
          headers: {
            "Authorization": `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: formData.toString(),
        });

        const smsResult = await smsResponse.json();
        
        if (smsResponse.ok) {
          console.log("SMS sent successfully to:", clientPhone, "SID:", smsResult.sid);
          smsSent = true;

          // Log SMS notification (include Twilio SID so we can trace delivery)
          await supabaseAdmin.from("notification_history").insert({
            client_id: clientId,
            property_id: propertyId,
            notification_type: "resend_invitation",
            channel: "sms",
            recipient: formattedToPhone,
            message_preview: `SID:${smsResult?.sid ?? ""} | ${smsBody}`.substring(0, 140),
            status: "sent",
            sent_by: user.id,
          });
        } else {
          console.error("Twilio error:", smsResult);
          notificationErrors.push(`SMS: ${smsResult.message || 'Unknown error'}`);

          // Log failed SMS
          await supabaseAdmin.from("notification_history").insert({
            client_id: clientId,
            property_id: propertyId,
            notification_type: "resend_invitation",
            channel: "sms",
            recipient: clientPhone,
            message_preview: smsBody.substring(0, 100) + "...",
            status: "failed",
            error_message: smsResult.message || "Unknown Twilio error",
            sent_by: user.id,
          });
        }
      } catch (smsError: any) {
        console.error("Error sending SMS:", smsError);
        notificationErrors.push(`SMS: ${smsError.message}`);

        // Log failed SMS
        await supabaseAdmin.from("notification_history").insert({
          client_id: clientId,
          property_id: propertyId,
          notification_type: "resend_invitation",
          channel: "sms",
          recipient: clientPhone,
          message_preview: smsBody.substring(0, 100) + "...",
          status: "failed",
          error_message: smsError.message,
          sent_by: user.id,
        });
      }
    } else if (!clientPhone) {
      console.log("No phone number for client");
      notificationErrors.push("No client phone number on file");
    } else {
      console.log("Twilio not fully configured");
      notificationErrors.push("SMS service not configured");
    }

    return new Response(
      JSON.stringify({
        success: true,
        emailSent,
        smsSent,
        notificationErrors: notificationErrors.length > 0 ? notificationErrors : undefined,
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in resend-invite function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: error.message.includes("Unauthorized") ? 403 : 400, 
        headers: { "Content-Type": "application/json", ...corsHeaders } 
      }
    );
  }
});
