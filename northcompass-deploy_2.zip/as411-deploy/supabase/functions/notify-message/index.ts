import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface NotifyMessageRequest {
  senderName: string;
  senderEmail: string;
  messageBody: string;
  threadTitle: string;
  propertyAddress?: string;
  recipientEmail?: string;
  recipientName?: string;
  recipientPhone?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify the user is authenticated
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized - No authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      console.error("Authentication failed:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Unauthorized - Invalid token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log("Authenticated user:", user.id, user.email);

    const { senderName, senderEmail, messageBody, threadTitle, propertyAddress, recipientEmail, recipientName, recipientPhone }: NotifyMessageRequest = await req.json();

    console.log("Received notification request:", { senderName, senderEmail, threadTitle, propertyAddress, recipientEmail, recipientPhone });

    // Validate input
    if (!senderName || !messageBody || !threadTitle) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: senderName, messageBody, threadTitle" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Determine target email - use recipientEmail if provided (for client notifications), otherwise use NOTIFICATION_EMAIL
    const targetEmail = recipientEmail || Deno.env.get("NOTIFICATION_EMAIL");
    const notificationPhone = Deno.env.get("NOTIFICATION_PHONE");
    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioPhoneNumber = Deno.env.get("TWILIO_PHONE_NUMBER");

    const results: { email?: boolean; sms?: boolean; errors: string[] } = { errors: [] };

    // Send email notification
    if (targetEmail) {
      try {
        // Different email content for client vs coordinator notifications
        const isClientNotification = !!recipientEmail;
        const greeting = recipientName ? `Hi ${recipientName},` : 'Hello,';
        
        const emailHtml = isClientNotification 
          ? `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #333;">New Message from Your Coordinator</h2>
              <p>${greeting}</p>
              <p>You have a new message regarding your property.</p>
              <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 10px 0;"><strong>From:</strong> ${senderName}</p>
                ${propertyAddress ? `<p style="margin: 0 0 10px 0;"><strong>Property:</strong> ${propertyAddress}</p>` : ''}
                <hr style="border: none; border-top: 1px solid #ddd; margin: 15px 0;" />
                <p style="margin: 0; white-space: pre-wrap;">${messageBody}</p>
              </div>
              <p style="color: #666; font-size: 12px;">
                Log in to your client portal to respond.
              </p>
            </div>
          `
          : `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #333;">New Message Received</h2>
              <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 10px 0;"><strong>From:</strong> ${senderName} (${senderEmail})</p>
                <p style="margin: 0 0 10px 0;"><strong>Thread:</strong> ${threadTitle}</p>
                ${propertyAddress ? `<p style="margin: 0 0 10px 0;"><strong>Property:</strong> ${propertyAddress}</p>` : ''}
                <hr style="border: none; border-top: 1px solid #ddd; margin: 15px 0;" />
                <p style="margin: 0; white-space: pre-wrap;">${messageBody}</p>
              </div>
              <p style="color: #666; font-size: 12px;">
                Log in to your Property Manager app to respond.
              </p>
            </div>
          `;

        const emailResponse = await resend.emails.send({
          from: "Aloha Senior 411 <notifications@alohasenior411.com>",
          to: [targetEmail],
          subject: isClientNotification 
            ? `New Message from Your Coordinator${propertyAddress ? ` - ${propertyAddress}` : ''}`
            : `New Message from ${senderName} - ${threadTitle}`,
          html: emailHtml,
        });

        console.log("Email sent successfully:", emailResponse);
        results.email = true;
      } catch (emailError: any) {
        console.error("Error sending email:", emailError);
        results.errors.push(`Email: ${emailError.message}`);
      }
    } else {
      console.log("No target email configured");
      results.errors.push("No target email configured");
    }

    // Determine target phone - use recipientPhone if provided (for client SMS), otherwise use NOTIFICATION_PHONE
    const targetPhone = recipientPhone || notificationPhone;
    const isClientSms = !!recipientPhone;

    // Format phone number to E.164 format (e.g., +18087728222)
    const formatPhoneToE164 = (phone: string): string => {
      // Remove all non-digit characters
      const digits = phone.replace(/\D/g, '');
      // If it's 10 digits, assume US and add +1
      if (digits.length === 10) {
        return `+1${digits}`;
      }
      // If it's 11 digits starting with 1, add +
      if (digits.length === 11 && digits.startsWith('1')) {
        return `+${digits}`;
      }
      // If already has country code or other format, just add + if missing
      return phone.startsWith('+') ? phone : `+${digits}`;
    };

    // Send SMS notification via Twilio
    if (twilioAccountSid && twilioAuthToken && twilioPhoneNumber && targetPhone) {
      const formattedToPhone = formatPhoneToE164(targetPhone);
      const formattedFromPhone = formatPhoneToE164(twilioPhoneNumber);
      console.log(`Formatting To phone: ${targetPhone} -> ${formattedToPhone}`);
      console.log(`Formatting From phone: ${twilioPhoneNumber} -> ${formattedFromPhone}`);

      try {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`;

        // Different SMS content for client vs coordinator notifications
        const smsBody = isClientSms
          ? `Aloha Senior 411: New message from your coordinator${propertyAddress ? ` regarding ${propertyAddress}` : ''}: ${messageBody.substring(0, 80)}${messageBody.length > 80 ? '...' : ''}`
          : `New message from ${senderName} in "${threadTitle}": ${messageBody.substring(0, 100)}${messageBody.length > 100 ? '...' : ''}`;

        const formData = new URLSearchParams();
        formData.append("To", formattedToPhone);
        formData.append("From", formattedFromPhone);
        formData.append("Body", smsBody);

        const smsResponse = await fetch(twilioUrl, {
          method: "POST",
          headers: {
            "Authorization": `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: formData.toString(),
        });

        const smsResult = await smsResponse.json();
        
        if (smsResponse.ok) {
          console.log("SMS sent successfully to:", targetPhone, "SID:", smsResult.sid);
          results.sms = true;
        } else {
          console.error("Twilio error:", { status: smsResponse.status, statusText: smsResponse.statusText, smsResult });
          const twilioMsg = smsResult?.message || smsResult?.error_message || 'Unknown error';
          const twilioCode = smsResult?.code ? ` (code ${smsResult.code})` : '';
          results.errors.push(`SMS: ${twilioMsg}${twilioCode} [HTTP ${smsResponse.status}]`);
        }
      } catch (smsError: any) {
        console.error("Error sending SMS:", smsError);
        results.errors.push(`SMS: ${smsError.message}`);
      }
    } else {
      console.log("Twilio not fully configured or no target phone");
      if (!targetPhone) {
        results.errors.push("No target phone number");
      } else {
        results.errors.push("Twilio not fully configured");
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in notify-message function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
