import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TwilioMessageStatusRequest {
  messageSid: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } },
    );

    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser();

    if (userError || !user) throw new Error("Unauthorized - could not verify user");

    // Ensure coordinator/admin
    const { data: roles, error: rolesError } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["coordinator", "admin"]);

    if (rolesError) throw rolesError;
    if (!roles || roles.length === 0) throw new Error("Unauthorized - coordinator access required");

    const { messageSid }: TwilioMessageStatusRequest = await req.json();
    if (!messageSid || typeof messageSid !== "string") {
      throw new Error("Missing required field: messageSid");
    }

    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");

    if (!twilioAccountSid || !twilioAuthToken) {
      throw new Error("SMS service not configured");
    }

    const url = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages/${messageSid}.json`;
    console.log(`Fetching Twilio message status for SID: ${messageSid}`);

    const res = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
      },
    });

    const json = await res.json();

    if (!res.ok) {
      console.error("Twilio status lookup failed:", json);
      return new Response(JSON.stringify({ error: json?.message || "Twilio error", twilio: json }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Return a tight, UI-friendly subset
    return new Response(
      JSON.stringify({
        sid: json.sid,
        status: json.status, // queued | sending | sent | delivered | undelivered | failed
        to: json.to,
        from: json.from,
        errorCode: json.error_code,
        errorMessage: json.error_message,
        dateCreated: json.date_created,
        dateSent: json.date_sent,
        price: json.price,
        priceUnit: json.price_unit,
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } },
    );
  } catch (error: any) {
    console.error("Error in twilio-message-status function:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: error.message.includes("Unauthorized") ? 403 : 400,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});
