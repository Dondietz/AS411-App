import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface NotifyContractorRequest {
  contractorId: string;
  contractorName: string;
  contractorPhone?: string;
  contractorEmail?: string;
  propertyId?: string;
  message: string;
  subject?: string;
  senderName: string;
  senderEmail: string;
  communicationType: 'sms' | 'email' | 'document';
  documentUrl?: string;
  documentName?: string;
}

const formatPhoneToE164 = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) {
    return `+1${digits}`;
  }
  if (digits.length === 11 && digits.startsWith('1')) {
    return `+${digits}`;
  }
  return phone.startsWith('+') ? phone : `+${digits}`;
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const body: NotifyContractorRequest = await req.json();
    const {
      contractorId,
      contractorName,
      contractorPhone,
      contractorEmail,
      propertyId,
      message,
      subject,
      senderName,
      senderEmail,
      communicationType,
      documentUrl,
      documentName,
    } = body;

    console.log("Notify contractor request:", { contractorId, communicationType, propertyId });

    if (!contractorId || !message || !communicationType) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get property details if provided
    let propertyAddress: string | null = null;
    if (propertyId) {
      const { data: property } = await supabaseClient
        .from('properties')
        .select('address, city')
        .eq('id', propertyId)
        .single();
      
      if (property) {
        propertyAddress = `${property.address}, ${property.city}`;
      }
    }

    const results: { sms?: boolean; email?: boolean; errors: string[] } = { errors: [] };
    let twilioSid: string | null = null;

    // Send SMS if phone is available
    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioPhoneNumber = Deno.env.get("TWILIO_PHONE_NUMBER");

    if (contractorPhone && twilioAccountSid && twilioAuthToken && twilioPhoneNumber) {
      try {
        const formattedToPhone = formatPhoneToE164(contractorPhone);
        const formattedFromPhone = formatPhoneToE164(twilioPhoneNumber);
        
        let smsBody = '';
        if (communicationType === 'document') {
          smsBody = `${senderName} sent you a document${propertyAddress ? ` for ${propertyAddress}` : ''}: ${subject || documentName}. Check your email for details.`;
        } else {
          smsBody = `Message from ${senderName}${propertyAddress ? ` regarding ${propertyAddress}` : ''}: ${message.substring(0, 120)}${message.length > 120 ? '...' : ''}`;
        }

        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`;
        const formData = new URLSearchParams();
        formData.append("To", formattedToPhone);
        formData.append("From", formattedFromPhone);
        formData.append("Body", smsBody);

        const smsResponse = await fetch(twilioUrl, {
          method: "POST",
          headers: {
            "Authorization": `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: formData.toString(),
        });

        const smsResult = await smsResponse.json();
        
        if (smsResponse.ok) {
          console.log("SMS sent successfully, SID:", smsResult.sid);
          results.sms = true;
          twilioSid = smsResult.sid;
        } else {
          console.error("Twilio error:", smsResult);
          results.errors.push(`SMS: ${smsResult.message || 'Failed to send'}`);
        }
      } catch (smsError: any) {
        console.error("SMS error:", smsError);
        results.errors.push(`SMS: ${smsError.message}`);
      }
    }

    // Send email if email is available
    if (contractorEmail) {
      try {
        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">${communicationType === 'document' ? 'New Document Received' : 'New Message'}</h2>
            <p>Hi ${contractorName},</p>
            <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0 0 10px 0;"><strong>From:</strong> ${senderName}</p>
              ${propertyAddress ? `<p style="margin: 0 0 10px 0;"><strong>Property:</strong> ${propertyAddress}</p>` : ''}
              ${subject ? `<p style="margin: 0 0 10px 0;"><strong>Subject:</strong> ${subject}</p>` : ''}
              <hr style="border: none; border-top: 1px solid #ddd; margin: 15px 0;" />
              <p style="margin: 0; white-space: pre-wrap;">${message}</p>
            </div>
            ${documentUrl ? `
              <div style="margin: 20px 0;">
                <a href="${documentUrl}" style="display: inline-block; background: #0066cc; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none;">
                  📎 View Document: ${documentName || 'Attachment'}
                </a>
              </div>
            ` : ''}
            <p style="color: #666; font-size: 12px;">
              This message was sent via Aloha Senior 411. Please reply directly to ${senderEmail}.
            </p>
          </div>
        `;

        const emailResponse = await resend.emails.send({
          from: "Aloha Senior 411 <notifications@alohasenior411.com>",
          to: [contractorEmail],
          reply_to: senderEmail,
          subject: subject || `New message from ${senderName}${propertyAddress ? ` - ${propertyAddress}` : ''}`,
          html: emailHtml,
        });

        console.log("Email sent successfully:", emailResponse);
        results.email = true;
      } catch (emailError: any) {
        console.error("Email error:", emailError);
        results.errors.push(`Email: ${emailError.message}`);
      }
    }

    // Log the communication to the database
    const communicationStatus = results.sms || results.email ? 'sent' : 'failed';
    const errorMessage = results.errors.length > 0 ? results.errors.join('; ') : null;

    const { error: logError } = await supabaseClient
      .from('contractor_communications')
      .insert({
        contractor_id: contractorId,
        property_id: propertyId || null,
        sent_by: user.id,
        communication_type: communicationType,
        subject: subject || null,
        message: message,
        document_url: documentUrl || null,
        document_name: documentName || null,
        recipient_phone: contractorPhone || null,
        recipient_email: contractorEmail || null,
        status: communicationStatus,
        error_message: errorMessage,
        twilio_sid: twilioSid,
      });

    if (logError) {
      console.error("Failed to log communication:", logError);
    }

    return new Response(
      JSON.stringify({ success: true, results }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error: any) {
    console.error("Error in notify-contractor:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
