import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { 
  FileText, 
  Upload, 
  Search, 
  ChevronDown, 
  ChevronRight,
  Loader2,
  FolderOpen,
  Building2,
} from 'lucide-react';
import { FileCard } from '@/components/files/FileCard';
import { UploadFileDialog } from '@/components/files/UploadFileDialog';

interface Property {
  id: string;
  address: string;
  city: string;
  status: string;
}

interface FileRecord {
  id: string;
  file_name: string;
  file_url: string;
  file_type: string | null;
  file_size: number | null;
  category: string | null;
  created_at: string;
  property_id: string;
}

interface GroupedFiles {
  [propertyId: string]: {
    property: Property;
    files: FileRecord[];
  };
}

const FILE_CATEGORIES = [
  { value: 'all', label: 'All Categories' },
  { value: 'document', label: 'Document' },
  { value: 'photo', label: 'Photo' },
  { value: 'contract', label: 'Contract' },
  { value: 'invoice', label: 'Invoice' },
  { value: 'report', label: 'Report' },
  { value: 'other', label: 'Other' },
];

export default function Files() {
  const { toast } = useToast();
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [expandedProperties, setExpandedProperties] = useState<Set<string>>(new Set());

  const fetchData = useCallback(async () => {
    setLoading(true);
    
    // Fetch properties
    const { data: propertiesData, error: propertiesError } = await supabase
      .from('properties')
      .select('id, address, city, status')
      .order('address');

    if (propertiesError) {
      console.error('Error fetching properties:', propertiesError);
    } else {
      setProperties(propertiesData || []);
    }

    // Fetch files
    const { data: filesData, error: filesError } = await supabase
      .from('files')
      .select('id, file_name, file_url, file_type, file_size, category, created_at, property_id')
      .order('created_at', { ascending: false });

    if (filesError) {
      console.error('Error fetching files:', filesError);
    } else {
      setFiles(filesData || []);
      // Expand all properties that have files by default
      const propsWithFiles = new Set((filesData || []).map(f => f.property_id));
      setExpandedProperties(propsWithFiles);
    }

    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDelete = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const handleCategoryChange = async (fileId: string, category: string) => {
    const { error } = await supabase
      .from('files')
      .update({ category })
      .eq('id', fileId);

    if (error) {
      toast({
        title: 'Error updating category',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      setFiles(prev => prev.map(f => f.id === fileId ? { ...f, category } : f));
      toast({ title: 'Category updated' });
    }
  };

  const toggleProperty = (propertyId: string) => {
    setExpandedProperties(prev => {
      const next = new Set(prev);
      if (next.has(propertyId)) {
        next.delete(propertyId);
      } else {
        next.add(propertyId);
      }
      return next;
    });
  };

  // Filter files based on search and category
  const filteredFiles = files.filter(file => {
    const matchesSearch = !searchQuery || 
      file.file_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || file.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Group files by property
  const groupedFiles: GroupedFiles = {};
  filteredFiles.forEach(file => {
    if (!groupedFiles[file.property_id]) {
      const property = properties.find(p => p.id === file.property_id);
      if (property) {
        groupedFiles[file.property_id] = {
          property,
          files: [],
        };
      }
    }
    if (groupedFiles[file.property_id]) {
      groupedFiles[file.property_id].files.push(file);
    }
  });

  // Get properties without files (for display)
  const propertiesWithoutFiles = properties.filter(
    p => !Object.keys(groupedFiles).includes(p.id)
  );

  const totalFiles = files.length;
  const filteredCount = filteredFiles.length;

  return (
    <AppLayout 
      title="Files & Documents" 
      breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Files' }]}
    >
      <div className="space-y-6">
        {/* Header with stats and actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <FileText className="h-5 w-5" />
              <span className="text-sm">
                {filteredCount} {filteredCount === 1 ? 'file' : 'files'}
                {filteredCount !== totalFiles && ` (of ${totalFiles})`}
              </span>
            </div>
          </div>
          <Button onClick={() => setUploadDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Upload Files
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FILE_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Files grouped by property */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : Object.keys(groupedFiles).length === 0 && propertiesWithoutFiles.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <FolderOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No files yet</p>
              <p className="text-sm mt-1">Upload files to get started</p>
              <Button className="mt-4" onClick={() => setUploadDialogOpen(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Upload Files
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {/* Properties with files */}
            {Object.entries(groupedFiles).map(([propertyId, { property, files: propertyFiles }]) => (
              <Collapsible
                key={propertyId}
                open={expandedProperties.has(propertyId)}
                onOpenChange={() => toggleProperty(propertyId)}
              >
                <Card>
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
                      <CardTitle className="flex items-center justify-between text-base">
                        <div className="flex items-center gap-3">
                          {expandedProperties.has(propertyId) ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          )}
                          <Building2 className="h-5 w-5 text-primary" />
                          <span>{property.address}, {property.city}</span>
                          <Badge variant="outline" className="ml-2">
                            {property.status}
                          </Badge>
                        </div>
                        <Badge variant="secondary">
                          {propertyFiles.length} {propertyFiles.length === 1 ? 'file' : 'files'}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="pt-0">
                      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {propertyFiles.map((file) => (
                          <FileCard
                            key={file.id}
                            file={file}
                            onDelete={handleDelete}
                            onCategoryChange={handleCategoryChange}
                          />
                        ))}
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
            ))}

            {/* Properties without files (collapsed by default) */}
            {!searchQuery && categoryFilter === 'all' && propertiesWithoutFiles.length > 0 && (
              <Card className="border-dashed">
                <CardHeader>
                  <CardTitle className="text-base text-muted-foreground flex items-center gap-2">
                    <FolderOpen className="h-5 w-5" />
                    {propertiesWithoutFiles.length} {propertiesWithoutFiles.length === 1 ? 'property' : 'properties'} without files
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-2">
                    {propertiesWithoutFiles.slice(0, 5).map((property) => (
                      <Badge key={property.id} variant="outline" className="text-muted-foreground">
                        {property.address}
                      </Badge>
                    ))}
                    {propertiesWithoutFiles.length > 5 && (
                      <Badge variant="outline" className="text-muted-foreground">
                        +{propertiesWithoutFiles.length - 5} more
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>

      <UploadFileDialog
        open={uploadDialogOpen}
        onOpenChange={setUploadDialogOpen}
        properties={properties}
        onSuccess={fetchData}
      />
    </AppLayout>
  );
}
