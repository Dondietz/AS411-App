import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { MobileHeader } from '@/components/client-portal/MobileHeader';
import { MobileBottomNav } from '@/components/client-portal/MobileBottomNav';
import { NextStepsSection } from '@/components/client-portal/NextStepsSection';
import { MessagingCard } from '@/components/client-portal/MessagingCard';
import { PhotosRow } from '@/components/client-portal/PhotosRow';
import { QuickLinks } from '@/components/client-portal/QuickLinks';
import { InstallPromptBanner } from '@/components/pwa/InstallPromptBanner';
import { PropertyTimeline } from '@/components/property/PropertyTimeline';
import { ChangePasswordForm } from '@/components/client/ChangePasswordForm';
import { CalendarSettingsCard } from '@/components/settings/CalendarSettingsCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useIsMobile } from '@/hooks/use-mobile';
import { 
  MapPin, ListTodo, Image, MessagesSquare, 
  Loader2, CheckCircle2, Clock, ArrowRight, Settings
} from 'lucide-react';
import { format } from 'date-fns';
import type { Property, Task, Cost } from '@/types/database';

interface FileRecord {
  id: string;
  file_name: string;
  file_url: string;
  file_type: string | null;
  category: string | null;
  created_at: string;
  caption?: string | null;
  signed_url?: string;
}

export default function ClientPortal() {
  const { user, loading: authLoading } = useAuth();
  const isMobile = useIsMobile();
  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [photos, setPhotos] = useState<FileRecord[]>([]);
  const [costs, setCosts] = useState<Cost[]>([]);
  const [loading, setLoading] = useState(true);
  const [mobileTab, setMobileTab] = useState<'dashboard' | 'checklist' | 'settings'>('dashboard');

  useEffect(() => {
    if (!user) return;

    async function fetchClientData() {
      const { data: propsData, error: propsError } = await supabase
        .from('properties')
        .select('*, client:clients(*)')
        .order('created_at', { ascending: false });

      if (propsError) {
        console.error('Error fetching properties:', propsError);
      }

      if (propsData && propsData.length > 0) {
        setProperties(propsData as unknown as Property[]);
        setSelectedProperty(propsData[0] as unknown as Property);
      }
      setLoading(false);
    }

    fetchClientData();
  }, [user]);

  const fetchPropertyPhotos = async (propertyId: string) => {
    const { data: filesData } = await supabase
      .from('files')
      .select('*')
      .eq('property_id', propertyId)
      .order('created_at', { ascending: false });

    if (filesData) {
      const photoFiles = filesData.filter(f => 
        f.file_type?.startsWith('image/') || 
        f.file_name?.match(/\.(jpg|jpeg|png|gif|webp)$/i)
      );
      
      const photosWithSignedUrls = await Promise.all(
        photoFiles.map(async (photo) => {
          const urlParts = photo.file_url.split('/property-files/');
          const filePath = urlParts[1];
          
          if (filePath) {
            const { data: signedData } = await supabase.storage
              .from('property-files')
              .createSignedUrl(filePath, 3600);
            
            return { ...photo, signed_url: signedData?.signedUrl || photo.file_url };
          }
          return { ...photo, signed_url: photo.file_url };
        })
      );
      
      setPhotos(photosWithSignedUrls as FileRecord[]);
    }
  };

  useEffect(() => {
    if (!selectedProperty) return;

    async function fetchPropertyData() {
      // Fetch milestone tasks
      const { data: tasksData } = await supabase
        .from('tasks')
        .select('*')
        .eq('property_id', selectedProperty.id)
        .eq('is_milestone', true)
        .order('due_date', { ascending: true });

      if (tasksData) {
        setTasks(tasksData as unknown as Task[]);
      }

      // Fetch costs for estimate
      const { data: costsData } = await supabase
        .from('costs')
        .select('*')
        .eq('property_id', selectedProperty.id);

      if (costsData) {
        setCosts(costsData as unknown as Cost[]);
      }

      // Fetch photos
      await fetchPropertyPhotos(selectedProperty.id);
    }

    fetchPropertyData();
  }, [selectedProperty]);

  const deferredCosts = costs.filter(c => c.cost_type === 'deferred').reduce((sum, c) => sum + Number(c.amount), 0);

  // Mobile loading state
  if (authLoading || loading) {
    if (isMobile) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  // Mobile empty state
  if (properties.length === 0) {
    if (isMobile) {
      return (
        <div className="min-h-screen bg-background">
          <MobileHeader />
          <div className="flex flex-col items-center justify-center p-6 pt-20">
            <h2 className="text-xl font-semibold mb-2">Welcome to Your Portal</h2>
            <p className="text-muted-foreground text-center">No properties have been assigned to your account yet.</p>
            <p className="text-muted-foreground text-center mt-2">Please contact your coordinator for assistance.</p>
          </div>
          <MobileBottomNav activeTab={mobileTab} onTabChange={(tab) => setMobileTab(tab as any)} />
        </div>
      );
    }
    return (
      <AppLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-2">Welcome to Your Portal</h2>
          <p className="text-muted-foreground">No properties have been assigned to your account yet.</p>
          <p className="text-muted-foreground mt-2">Please contact your coordinator for assistance.</p>
        </div>
      </AppLayout>
    );
  }

  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const totalTasks = tasks.length;

  // Mobile layout
  if (isMobile && selectedProperty) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader />
        <InstallPromptBanner />
        
        {/* Main scrollable content */}
        <div className="overflow-y-auto">
          {mobileTab === 'dashboard' && (
            <>
              <NextStepsSection tasks={tasks} />
              <MessagingCard propertyId={selectedProperty.id} />
              <PhotosRow 
                photos={photos} 
                propertyId={selectedProperty.id}
                onPhotoUploaded={() => fetchPropertyPhotos(selectedProperty.id)}
              />
              <QuickLinks 
                estimatedValue={selectedProperty.estimated_value} 
                deferredCosts={deferredCosts}
              />
            </>
          )}

          {mobileTab === 'checklist' && (
            <div className="px-4 py-4 space-y-4">
              <h2 className="text-lg font-semibold">Project Milestones</h2>
              <p className="text-sm text-muted-foreground">{completedTasks}/{totalTasks} complete</p>
              
              {tasks.length > 0 ? (
                <div className="space-y-3">
                  {tasks.map(task => (
                    <div 
                      key={task.id} 
                      className={`flex items-start gap-3 p-3 rounded-lg border ${
                        task.status === 'completed' 
                          ? 'bg-success/5 border-success/20' 
                          : 'bg-card border-border'
                      }`}
                    >
                      {task.status === 'completed' ? (
                        <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
                      ) : (
                        <Clock className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className={`font-medium text-sm ${task.status === 'completed' ? 'text-success' : ''}`}>
                          {task.title}
                        </p>
                        {task.description && (
                          <p className="text-xs text-muted-foreground mt-1">{task.description}</p>
                        )}
                        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                          <span className="capitalize">{task.phase}</span>
                          {task.due_date && (
                            <span>Due: {format(new Date(task.due_date), 'MMM d')}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <ListTodo className="h-10 w-10 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No milestones set yet.</p>
                </div>
              )}
            </div>
          )}

          {mobileTab === 'settings' && (
            <div className="px-4 py-4 space-y-4">
              <h2 className="text-lg font-semibold">Settings</h2>
              <CalendarSettingsCard />
              <ChangePasswordForm />
            </div>
          )}
        </div>

        <MobileBottomNav 
          activeTab={mobileTab} 
          onTabChange={(tab) => setMobileTab(tab as any)} 
        />
      </div>
    );
  }

  // Desktop layout (existing)
  return (
    <AppLayout
      breadcrumbs={[
        { label: 'My Properties' }
      ]}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="font-display text-2xl">My Property Portal</h1>
            <p className="text-muted-foreground">Track progress on your property</p>
          </div>
          {properties.length > 1 && (
            <div className="flex gap-2 flex-wrap">
              {properties.map(prop => (
                <Button
                  key={prop.id}
                  variant={selectedProperty?.id === prop.id ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedProperty(prop)}
                >
                  {prop.address}
                </Button>
              ))}
            </div>
          )}
        </div>

        {selectedProperty && (
          <>
            {/* Property Header */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-6 w-6 text-primary" />
                    <div>
                      <h2 className="text-xl font-semibold">{selectedProperty.address}</h2>
                      <p className="text-muted-foreground">{selectedProperty.city}, {selectedProperty.state} {selectedProperty.zip_code}</p>
                    </div>
                  </div>
                  <StatusBadge status={selectedProperty.status} type="property" />
                </div>
                <PropertyTimeline currentStatus={selectedProperty.status} />
              </CardContent>
            </Card>

            {/* Tabs */}
            <Tabs defaultValue="progress" className="space-y-6">
              <TabsList>
                <TabsTrigger value="progress" className="flex items-center gap-1">
                  <ListTodo className="h-4 w-4" />
                  Progress
                </TabsTrigger>
                <TabsTrigger value="photos" className="flex items-center gap-1">
                  <Image className="h-4 w-4" />
                  Photos
                </TabsTrigger>
                <TabsTrigger value="messages" className="flex items-center gap-1">
                  <MessagesSquare className="h-4 w-4" />
                  Messages
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-1">
                  <Settings className="h-4 w-4" />
                  Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="progress" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ListTodo className="h-5 w-5" />
                      Project Milestones
                      <span className="text-sm font-normal text-muted-foreground ml-2">
                        {completedTasks}/{totalTasks} complete
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {tasks.length > 0 ? (
                      <div className="space-y-4">
                        {tasks.map(task => (
                          <div 
                            key={task.id} 
                            className={`flex items-start gap-4 p-4 rounded-lg border ${
                              task.status === 'completed' ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900' : 'bg-muted/50'
                            }`}
                          >
                            {task.status === 'completed' ? (
                              <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                            ) : (
                              <Clock className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            )}
                            <div className="flex-1 min-w-0">
                              <p className={`font-medium ${task.status === 'completed' ? 'text-green-900 dark:text-green-100' : ''}`}>
                                {task.title}
                              </p>
                              {task.description && (
                                <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                              )}
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                <span className="capitalize">{task.phase} phase</span>
                                {task.due_date && (
                                  <span>Due: {format(new Date(task.due_date), 'MMM d, yyyy')}</span>
                                )}
                                {task.completed_at && (
                                  <span className="text-green-600">
                                    Completed: {format(new Date(task.completed_at), 'MMM d, yyyy')}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        <ListTodo className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No milestones have been set for this property yet.</p>
                        <p className="text-sm mt-1">Check back soon for updates!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="photos" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Image className="h-5 w-5" />
                      Property Photos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {photos.length > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {photos.map(photo => (
                          <a
                            key={photo.id}
                            href={photo.signed_url || photo.file_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="aspect-square rounded-lg overflow-hidden bg-muted hover:opacity-90 transition-opacity"
                          >
                            <img
                              src={photo.signed_url || photo.file_url}
                              alt={photo.file_name}
                              className="w-full h-full object-cover"
                            />
                          </a>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        <Image className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No photos have been uploaded yet.</p>
                        <p className="text-sm mt-1">Check back soon for updates!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="messages" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessagesSquare className="h-5 w-5" />
                      Messages
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <MessagesSquare className="h-12 w-12 mx-auto mb-4 text-primary opacity-50" />
                      <p className="text-muted-foreground mb-4">
                        Send messages to your coordinator about your property.
                      </p>
                      <Button asChild>
                        <Link to={`/messages?property=${selectedProperty.id}`}>
                          Open Messages
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="mt-0 space-y-6">
                <CalendarSettingsCard />
                <ChangePasswordForm />
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AppLayout>
  );
}
