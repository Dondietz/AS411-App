import { useEffect, useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { PropertyCard } from '@/components/dashboard/PropertyCard';
import { CreatePropertyDialog } from '@/components/property/CreatePropertyDialog';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import type { PropertyWithDetails } from '@/types/database';

export default function Properties() {
  const [properties, setProperties] = useState<PropertyWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProperties = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('properties')
      .select('*, client:clients(*), coordinator:profiles(*)')
      .order('created_at', { ascending: false });
    setProperties((data as PropertyWithDetails[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchProperties();
  }, []);

  return (
    <AppLayout title="Properties" breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Properties' }]}>
      <div className="space-y-6">
        <div className="flex justify-end">
          <CreatePropertyDialog onSuccess={fetchProperties} />
        </div>

        {loading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map(i => <Card key={i} className="h-48 animate-pulse bg-muted" />)}
          </div>
        ) : properties.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {properties.map(p => <PropertyCard key={p.id} property={p} />)}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              No properties yet. Click "Add Property" to create your first one.
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
