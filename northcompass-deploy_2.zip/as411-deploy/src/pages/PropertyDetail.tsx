import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { PropertyTimeline } from '@/components/property/PropertyTimeline';
import { AIDescriptionGenerator } from '@/components/property/AIDescriptionGenerator';
import { KeyDatesCalendar } from '@/components/property/KeyDatesCalendar';
import { PropertyPhotos } from '@/components/property/PropertyPhotos';
import { CostSummary } from '@/components/financials/CostSummary';
import { FinancialsTab } from '@/components/financials/FinancialsTab';
import { InviteClientDialog } from '@/components/client/InviteClientDialog';
import { TaskCard } from '@/components/tasks/TaskCard';
import { CreateTaskDialog } from '@/components/tasks/CreateTaskDialog';
import { MessageItem } from '@/components/messages/MessageItem';
import { CommunicationsTab } from '@/components/communications/CommunicationsTab';
import { MessagingTab } from '@/components/messaging/MessagingTab';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { StatusBadge } from '@/components/ui/status-badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { 
  MapPin, User, Phone, Mail, 
  Send, ListTodo, MessageSquare, ArrowLeft, Loader2, Clock, MessagesSquare,
  Pencil, Check, X, UserPlus
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import type { Property, Task, Message, Cost, PropertyStatus } from '@/types/database';

export default function PropertyDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const [property, setProperty] = useState<Property | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [costs, setCosts] = useState<Cost[]>([]);
  const [lastContacted, setLastContacted] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [clients, setClients] = useState<{ id: string; full_name: string; email: string | null }[]>([]);
  const [clientPopoverOpen, setClientPopoverOpen] = useState(false);
  const [updatingClient, setUpdatingClient] = useState(false);
  const [coordinators, setCoordinators] = useState<{ id: string; full_name: string; email: string }[]>([]);
  const [coordinatorPopoverOpen, setCoordinatorPopoverOpen] = useState(false);
  const [updatingCoordinator, setUpdatingCoordinator] = useState(false);

  const PROPERTY_STATUSES: PropertyStatus[] = ['intake', 'cleanout', 'repair', 'listing', 'escrow', 'closed'];

  const updatePropertyStatus = async (newStatus: PropertyStatus) => {
    if (!id || !property) return;
    setUpdatingStatus(true);
    
    const { error } = await supabase
      .from('properties')
      .update({ status: newStatus })
      .eq('id', id);
    
    if (error) {
      toast({ title: 'Error', description: 'Could not update status', variant: 'destructive' });
    } else {
      setProperty({ ...property, status: newStatus });
      toast({ title: 'Status Updated', description: `Property moved to ${newStatus}` });
    }
    setUpdatingStatus(false);
  };

  const fetchTasks = async () => {
    if (!id) return;
    const { data } = await supabase
      .from('tasks')
      .select('*, assignee:profiles(*), contractor:contractors(*)')
      .eq('property_id', id)
      .order('priority', { ascending: false });
    if (data) setTasks(data as unknown as Task[]);
  };

  const fetchLastContacted = async () => {
    if (!id) return;
    const { data } = await supabase
      .from('communications')
      .select('date')
      .eq('property_id', id)
      .order('date', { ascending: false })
      .limit(1);
    if (data && data.length > 0) {
      setLastContacted(data[0].date);
    }
  };

  const fetchClients = async () => {
    const { data } = await supabase
      .from('clients')
      .select('id, full_name, email')
      .order('full_name');
    if (data) setClients(data);
  };

  const fetchCoordinators = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('id, full_name, email')
      .order('full_name');
    if (data) setCoordinators(data);
  };

  const updatePropertyCoordinator = async (coordinatorId: string | null) => {
    if (!id || !property) return;
    setUpdatingCoordinator(true);
    
    const { data, error } = await supabase
      .from('properties')
      .update({ coordinator_id: coordinatorId })
      .eq('id', id)
      .select('*, client:clients(*, user_id), coordinator:profiles(*)')
      .single();
    
    if (error) {
      toast({ title: 'Error', description: 'Could not update coordinator', variant: 'destructive' });
    } else {
      setProperty(data as unknown as Property);
      toast({ title: 'Coordinator Updated', description: coordinatorId ? 'Coordinator assigned to property' : 'Coordinator removed from property' });
    }
    setUpdatingCoordinator(false);
    setCoordinatorPopoverOpen(false);
  };

  const updatePropertyClient = async (clientId: string | null) => {
    if (!id || !property) return;
    setUpdatingClient(true);
    
    const { data, error } = await supabase
      .from('properties')
      .update({ client_id: clientId })
      .eq('id', id)
      .select('*, client:clients(*, user_id), coordinator:profiles(*)')
      .single();
    
    if (error) {
      toast({ title: 'Error', description: 'Could not update client', variant: 'destructive' });
    } else {
      setProperty(data as unknown as Property);
      toast({ title: 'Client Updated', description: clientId ? 'Client assigned to property' : 'Client removed from property' });
    }
    setUpdatingClient(false);
    setClientPopoverOpen(false);
  };

  useEffect(() => {
    if (!id) return;
    
    async function fetchData() {
      const [propRes, tasksRes, messagesRes, costsRes] = await Promise.all([
        supabase.from('properties').select('*, client:clients(*, user_id), coordinator:profiles(*)').eq('id', id).single(),
        supabase.from('tasks').select('*, assignee:profiles(*), contractor:contractors(*)').eq('property_id', id).order('priority', { ascending: false }),
        supabase.from('messages').select('*, sender:profiles(*)').eq('property_id', id).order('created_at', { ascending: true }),
        supabase.from('costs').select('*, contractor:contractors(*)').eq('property_id', id),
      ]);

      if (propRes.data) setProperty(propRes.data as unknown as Property);
      if (tasksRes.data) setTasks(tasksRes.data as unknown as Task[]);
      if (messagesRes.data) setMessages(messagesRes.data as unknown as Message[]);
      if (costsRes.data) setCosts(costsRes.data as unknown as Cost[]);
      setLoading(false);
    }

    fetchData();
    fetchLastContacted();
    fetchClients();
    fetchCoordinators();

    // Realtime messages
    const channel = supabase
      .channel(`messages-${id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `property_id=eq.${id}` },
        async (payload) => {
          const { data } = await supabase.from('messages').select('*, sender:profiles(*)').eq('id', payload.new.id).single();
          if (data) setMessages(prev => [...prev, data as unknown as Message]);
        }
      )
      .subscribe();

    // Realtime communications for last contacted
    const commChannel = supabase
      .channel(`communications-last-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'communications', filter: `property_id=eq.${id}` },
        () => fetchLastContacted()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(commChannel);
    };
  }, [id]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !id || !user) return;
    setSendingMessage(true);

    const { error } = await supabase.from('messages').insert({
      property_id: id,
      sender_id: user.id,
      content: newMessage.trim(),
      is_internal: true,
    });

    if (error) {
      toast({ title: 'Error', description: 'Could not send message', variant: 'destructive' });
    } else {
      setNewMessage('');
    }
    setSendingMessage(false);
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!property) {
    return (
      <AppLayout>
        <div className="text-center py-12">
          <p className="text-muted-foreground">Property not found</p>
          <Button asChild className="mt-4"><Link to="/properties">Back to Properties</Link></Button>
        </div>
      </AppLayout>
    );
  }

  const estimatedCosts = costs.filter(c => c.cost_type === 'estimated').reduce((sum, c) => sum + Number(c.amount), 0);
  const paidCosts = costs.filter(c => c.cost_type === 'paid').reduce((sum, c) => sum + Number(c.amount), 0);
  const deferredCosts = costs.filter(c => c.cost_type === 'deferred').reduce((sum, c) => sum + Number(c.amount), 0);

  return (
    <AppLayout
      breadcrumbs={[
        { label: 'Dashboard', href: '/dashboard' },
        { label: 'Properties', href: '/properties' },
        { label: property.address }
      ]}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div className="space-y-2">
            <Button variant="ghost" size="sm" asChild className="-ml-2">
              <Link to="/properties"><ArrowLeft className="h-4 w-4 mr-1" /> Back</Link>
            </Button>
            <div className="flex items-center gap-3">
              <MapPin className="h-6 w-6 text-primary" />
              <h1 className="font-display">{property.address}</h1>
            </div>
            <div className="flex items-center gap-4">
              <p className="text-muted-foreground">{property.city}, {property.state} {property.zip_code}</p>
              {lastContacted && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>Last contacted {formatDistanceToNow(new Date(lastContacted), { addSuffix: true })}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Select 
              value={property.status} 
              onValueChange={(value) => updatePropertyStatus(value as PropertyStatus)}
              disabled={updatingStatus}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue>
                  <StatusBadge status={property.status} type="property" />
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {PROPERTY_STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    <span className="capitalize">{status}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <AIDescriptionGenerator property={property} />
          </div>
        </div>

        {/* Timeline */}
        <Card>
          <CardContent className="pt-6">
            <PropertyTimeline currentStatus={property.status} />
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="messaging" className="flex items-center gap-1">
              <MessagesSquare className="h-4 w-4" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="financials">Financials</TabsTrigger>
            <TabsTrigger value="communications">Communications</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-0">
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Main content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Client & Coordinator */}
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <User className="h-4 w-4" /> Client
                        </span>
                        <div className="flex items-center gap-1">
                          {property.client && (
                            <InviteClientDialog
                              clientId={property.client.id}
                              clientEmail={property.client.email}
                              clientName={property.client.full_name}
                              propertyId={id!}
                              hasAccount={!!(property.client as any).user_id}
                            />
                          )}
                          <Popover open={clientPopoverOpen} onOpenChange={setClientPopoverOpen}>
                            <PopoverTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                {property.client ? <Pencil className="h-3.5 w-3.5" /> : <UserPlus className="h-3.5 w-3.5" />}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[280px] p-0" align="end">
                              <Command>
                                <CommandInput placeholder="Search clients..." />
                                <CommandList>
                                  <CommandEmpty>No clients found.</CommandEmpty>
                                  <CommandGroup>
                                    {property.client && (
                                      <CommandItem
                                        onSelect={() => updatePropertyClient(null)}
                                        className="text-destructive"
                                      >
                                        <X className="h-4 w-4 mr-2" />
                                        Remove client
                                      </CommandItem>
                                    )}
                                    {clients.map((client) => (
                                      <CommandItem
                                        key={client.id}
                                        value={client.full_name}
                                        onSelect={() => updatePropertyClient(client.id)}
                                        disabled={updatingClient}
                                      >
                                        <Check className={`h-4 w-4 mr-2 ${property.client?.id === client.id ? 'opacity-100' : 'opacity-0'}`} />
                                        <div className="flex flex-col">
                                          <span>{client.full_name}</span>
                                          {client.email && (
                                            <span className="text-xs text-muted-foreground">{client.email}</span>
                                          )}
                                        </div>
                                      </CommandItem>
                                    ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                      {property.client ? (
                        <>
                          <p className="font-medium">{property.client.full_name}</p>
                          {property.client.email && (
                            <p className="flex items-center gap-2 text-muted-foreground">
                              <Mail className="h-3 w-3" /> {property.client.email}
                            </p>
                          )}
                          {property.client.phone && (
                            <p className="flex items-center gap-2 text-muted-foreground">
                              <Phone className="h-3 w-3" /> {property.client.phone}
                            </p>
                          )}
                        </>
                      ) : (
                        <p className="text-muted-foreground py-2">No client assigned</p>
                      )}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <User className="h-4 w-4" /> Coordinator
                        </span>
                        <Popover open={coordinatorPopoverOpen} onOpenChange={setCoordinatorPopoverOpen}>
                          <PopoverTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              {property.coordinator ? <Pencil className="h-3.5 w-3.5" /> : <UserPlus className="h-3.5 w-3.5" />}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-[280px] p-0" align="end">
                            <Command>
                              <CommandInput placeholder="Search coordinators..." />
                              <CommandList>
                                <CommandEmpty>No coordinators found.</CommandEmpty>
                                <CommandGroup>
                                  {property.coordinator && (
                                    <CommandItem
                                      onSelect={() => updatePropertyCoordinator(null)}
                                      className="text-destructive"
                                    >
                                      <X className="h-4 w-4 mr-2" />
                                      Remove coordinator
                                    </CommandItem>
                                  )}
                                  {coordinators.map((coordinator) => (
                                    <CommandItem
                                      key={coordinator.id}
                                      value={coordinator.full_name}
                                      onSelect={() => updatePropertyCoordinator(coordinator.id)}
                                      disabled={updatingCoordinator}
                                    >
                                      <Check className={`h-4 w-4 mr-2 ${property.coordinator?.id === coordinator.id ? 'opacity-100' : 'opacity-0'}`} />
                                      <div className="flex flex-col">
                                        <span>{coordinator.full_name}</span>
                                        <span className="text-xs text-muted-foreground">{coordinator.email}</span>
                                      </div>
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                      {property.coordinator ? (
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {property.coordinator.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{property.coordinator.full_name}</p>
                            <p className="text-xs text-muted-foreground">{property.coordinator.email}</p>
                          </div>
                        </div>
                      ) : (
                        <p className="text-muted-foreground py-2">No coordinator assigned</p>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Tasks */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ListTodo className="h-5 w-5" /> Tasks
                      <span className="text-sm font-normal text-muted-foreground">
                        {tasks.filter(t => t.status === 'completed').length}/{tasks.length} complete
                      </span>
                      <div className="ml-auto">
                        <CreateTaskDialog propertyId={id!} onTaskCreated={fetchTasks} />
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {tasks.length > 0 ? (
                      <div className="grid gap-3 md:grid-cols-2">
                        {tasks.slice(0, 4).map(task => (
                          <TaskCard key={task.id} task={task} />
                        ))}
                      </div>
                    ) : (
                      <p className="text-center py-8 text-muted-foreground text-sm">No tasks yet</p>
                    )}
                  </CardContent>
                </Card>

                {/* Photos */}
                <PropertyPhotos propertyId={id!} />

                {/* Internal Notes */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5" /> Internal Notes
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="max-h-80 overflow-y-auto space-y-4 pr-2">
                      {messages.length > 0 ? (
                        messages.map(msg => (
                          <MessageItem key={msg.id} message={msg} isOwn={msg.sender_id === user?.id} />
                        ))
                      ) : (
                        <p className="text-center py-8 text-muted-foreground text-sm">No notes yet</p>
                      )}
                    </div>
                    <Separator />
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a note..."
                        value={newMessage}
                        onChange={e => setNewMessage(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                      />
                      <Button onClick={sendMessage} disabled={sendingMessage || !newMessage.trim()}>
                        {sendingMessage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Key Dates & Calendar */}
                <KeyDatesCalendar property={property} tasks={tasks} />

                {/* Financials */}
                <CostSummary
                  estimatedCosts={estimatedCosts}
                  paidCosts={paidCosts}
                  deferredCosts={deferredCosts}
                  salePrice={property.sale_price ? Number(property.sale_price) : undefined}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="messaging" className="mt-0">
            <MessagingTab
              propertyId={id!}
              propertyAddress={property?.address}
              onCreateTask={(messageId, body) => {
                // TODO: Integrate with task creation
                toast({ title: 'Create task', description: `Task from: "${body.slice(0, 50)}..."` });
              }}
            />
          </TabsContent>

          <TabsContent value="financials" className="mt-0">
            <FinancialsTab
              propertyId={id!}
              propertyAddress={property.address}
              propertyCity={property.city}
              propertyState={property.state}
              propertyZipCode={property.zip_code}
              salePrice={property.sale_price ? Number(property.sale_price) : undefined}
              clientName={property.client?.full_name}
              clientEmail={property.client?.email}
              clientPhone={property.client?.phone}
            />
          </TabsContent>

          <TabsContent value="communications" className="mt-0">
            <CommunicationsTab propertyId={id!} />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
