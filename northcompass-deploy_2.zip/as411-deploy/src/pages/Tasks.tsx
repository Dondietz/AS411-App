import { useEffect, useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { KanbanColumn } from '@/components/tasks/KanbanColumn';
import { supabase } from '@/integrations/supabase/client';
import type { Task, TaskStatus } from '@/types/database';
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { TaskCard } from '@/components/tasks/TaskCard';
import { toast } from 'sonner';

export default function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTask, setActiveTask] = useState<Task | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  useEffect(() => {
    supabase.from('tasks').select('*, property:properties(*), assignee:profiles(*), contractor:contractors(*)').then(({ data }) => setTasks((data as Task[]) || []));
  }, []);

  const getTasksByStatus = (status: TaskStatus) => tasks.filter(t => t.status === status);

  const handleDragStart = (event: DragStartEvent) => {
    const task = tasks.find(t => t.id === event.active.id);
    setActiveTask(task || null);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const taskId = active.id as string;
    const newStatus = over.id as TaskStatus;
    const task = tasks.find(t => t.id === taskId);

    if (!task || task.status === newStatus) return;

    // Optimistically update UI
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, status: newStatus } : t
    ));

    // Update in database
    const { error } = await supabase
      .from('tasks')
      .update({ 
        status: newStatus,
        completed_at: newStatus === 'completed' ? new Date().toISOString() : null
      })
      .eq('id', taskId);

    if (error) {
      // Revert on error
      setTasks(prev => prev.map(t => 
        t.id === taskId ? { ...t, status: task.status } : t
      ));
      toast.error('Failed to update task status');
    } else {
      toast.success(`Task moved to ${newStatus.replace('_', ' ')}`);
    }
  };

  return (
    <AppLayout title="Task Board" breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Tasks' }]}>
      <DndContext sensors={sensors} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KanbanColumn title="Pending" status="pending" tasks={getTasksByStatus('pending')} />
          <KanbanColumn title="In Progress" status="in_progress" tasks={getTasksByStatus('in_progress')} />
          <KanbanColumn title="Blocked" status="blocked" tasks={getTasksByStatus('blocked')} />
          <KanbanColumn title="Completed" status="completed" tasks={getTasksByStatus('completed')} />
        </div>
        <DragOverlay>
          {activeTask && <TaskCard task={activeTask} isDragging />}
        </DragOverlay>
      </DndContext>
    </AppLayout>
  );
}
