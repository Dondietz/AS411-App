import { AppLayout } from '@/components/layout/AppLayout';
import { TaskCalendar } from '@/components/schedule/TaskCalendar';

export default function Schedule() {
  return (
    <AppLayout title="Schedule" breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Schedule' }]}>
      <TaskCalendar />
    </AppLayout>
  );
}
