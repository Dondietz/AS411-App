import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Building, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  FileText,
  MessageSquare,
  HardHat,
  Calendar,
  ExternalLink
} from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;
type ContractorBid = Tables<'contractor_bids'>;

interface BidWithProperty extends ContractorBid {
  properties: {
    address: string;
    city: string;
    status: string;
  } | null;
}

interface Communication {
  id: string;
  communication_type: string;
  subject: string | null;
  message: string;
  status: string;
  created_at: string;
  document_url: string | null;
  document_name: string | null;
  properties: {
    address: string;
    city: string;
  } | null;
}

const statusConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  pending: { icon: Clock, color: 'bg-amber-100 text-amber-800', label: 'Pending' },
  accepted: { icon: CheckCircle2, color: 'bg-green-100 text-green-800', label: 'Accepted' },
  rejected: { icon: XCircle, color: 'bg-red-100 text-red-800', label: 'Rejected' },
  expired: { icon: Clock, color: 'bg-gray-100 text-gray-800', label: 'Expired' },
};

export default function ContractorPortal() {
  const { user, profile } = useAuth();

  // Fetch contractor record linked to this user
  const { data: contractor, isLoading: loadingContractor } = useQuery({
    queryKey: ['my-contractor', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .eq('user_id', user.id)
        .single();
      if (error) {
        if (error.code === 'PGRST116') return null; // No record found
        throw error;
      }
      return data as Contractor;
    },
    enabled: !!user?.id,
  });

  // Fetch bids for this contractor
  const { data: bids = [], isLoading: loadingBids } = useQuery({
    queryKey: ['my-bids', contractor?.id],
    queryFn: async () => {
      if (!contractor?.id) return [];
      const { data, error } = await supabase
        .from('contractor_bids')
        .select(`
          *,
          properties:property_id (address, city, status)
        `)
        .eq('contractor_id', contractor.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as BidWithProperty[];
    },
    enabled: !!contractor?.id,
  });

  // Fetch communications for this contractor
  const { data: communications = [], isLoading: loadingComms } = useQuery({
    queryKey: ['my-communications', contractor?.id],
    queryFn: async () => {
      if (!contractor?.id) return [];
      const { data, error } = await supabase
        .from('contractor_communications')
        .select(`
          id,
          communication_type,
          subject,
          message,
          status,
          created_at,
          document_url,
          document_name,
          properties:property_id (address, city)
        `)
        .eq('contractor_id', contractor.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Communication[];
    },
    enabled: !!contractor?.id,
  });

  const pendingBids = bids.filter(b => b.status === 'pending');
  const acceptedBids = bids.filter(b => b.status === 'accepted');
  const totalBidValue = bids.reduce((sum, b) => sum + Number(b.amount), 0);

  if (loadingContractor) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading your portal...</div>
        </div>
      </AppLayout>
    );
  }

  if (!contractor) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <HardHat className="h-16 w-16 text-muted-foreground" />
          <h2 className="text-xl font-semibold text-foreground">Contractor Account Not Linked</h2>
          <p className="text-muted-foreground text-center max-w-md">
            Your user account is not linked to a contractor profile yet. 
            Please contact your coordinator to link your account.
          </p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-2xl font-display font-bold text-foreground">
            Welcome, {contractor.contact_name || contractor.company_name}
          </h1>
          <p className="text-muted-foreground">
            {contractor.company_name} {contractor.specialty && `• ${contractor.specialty}`}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{bids.length}</p>
                  <p className="text-sm text-muted-foreground">Total Bids</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{pendingBids.length}</p>
                  <p className="text-sm text-muted-foreground">Pending</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{acceptedBids.length}</p>
                  <p className="text-sm text-muted-foreground">Accepted</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <DollarSign className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">${totalBidValue.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total Value</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="bids" className="w-full">
          <TabsList>
            <TabsTrigger value="bids">My Bids</TabsTrigger>
            <TabsTrigger value="communications">Messages & Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="bids" className="mt-4">
            {loadingBids ? (
              <div className="text-muted-foreground py-8 text-center">Loading bids...</div>
            ) : bids.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No bids submitted yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {bids.map((bid) => {
                  const config = statusConfig[bid.status] || statusConfig.pending;
                  const StatusIcon = config.icon;
                  
                  return (
                    <Card key={bid.id}>
                      <CardContent className="p-4">
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-start gap-3">
                              <Building className="h-5 w-5 text-muted-foreground mt-0.5" />
                              <div>
                                <p className="font-medium text-foreground">
                                  {bid.properties?.address || 'Unknown Property'}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {bid.properties?.city}
                                </p>
                              </div>
                            </div>
                            <p className="text-sm text-foreground">{bid.description}</p>
                            {bid.scope_of_work && (
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {bid.scope_of_work}
                              </p>
                            )}
                            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                              {bid.estimated_start_date && (
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  Start: {format(new Date(bid.estimated_start_date), 'MMM d, yyyy')}
                                </span>
                              )}
                              {bid.estimated_duration_days && (
                                <span className="flex items-center gap-1">
                                  <Clock className="h-4 w-4" />
                                  {bid.estimated_duration_days} days
                                </span>
                              )}
                            </div>
                            {bid.attachment_url && (
                              <Button
                                variant="link"
                                size="sm"
                                className="h-auto p-0 text-primary"
                                asChild
                              >
                                <a href={bid.attachment_url} target="_blank" rel="noopener noreferrer">
                                  <FileText className="h-4 w-4 mr-1" />
                                  {bid.attachment_name || 'View Attachment'}
                                  <ExternalLink className="h-3 w-3 ml-1" />
                                </a>
                              </Button>
                            )}
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <Badge className={config.color}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {config.label}
                            </Badge>
                            <p className="text-xl font-bold text-foreground">
                              ${Number(bid.amount).toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Submitted {format(new Date(bid.created_at), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="communications" className="mt-4">
            {loadingComms ? (
              <div className="text-muted-foreground py-8 text-center">Loading messages...</div>
            ) : communications.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No messages or documents yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {communications.map((comm) => (
                  <Card key={comm.id}>
                    <CardContent className="p-4">
                      <div className="flex flex-col gap-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {comm.communication_type === 'document' ? (
                              <FileText className="h-5 w-5 text-primary" />
                            ) : (
                              <MessageSquare className="h-5 w-5 text-primary" />
                            )}
                            <div>
                              <p className="font-medium text-foreground">
                                {comm.subject || (comm.communication_type === 'sms' ? 'SMS Message' : 'Document')}
                              </p>
                              {comm.properties && (
                                <p className="text-sm text-muted-foreground">
                                  {comm.properties.address}, {comm.properties.city}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary" className="text-xs">
                              {comm.communication_type.toUpperCase()}
                            </Badge>
                            <p className="text-xs text-muted-foreground mt-1">
                              {format(new Date(comm.created_at), 'MMM d, yyyy h:mm a')}
                            </p>
                          </div>
                        </div>
                        <p className="text-sm text-foreground whitespace-pre-wrap">
                          {comm.message}
                        </p>
                        {comm.document_url && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-fit"
                            asChild
                          >
                            <a href={comm.document_url} target="_blank" rel="noopener noreferrer">
                              <FileText className="h-4 w-4 mr-2" />
                              {comm.document_name || 'Download Document'}
                              <ExternalLink className="h-3 w-3 ml-2" />
                            </a>
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
