import { useEffect, useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { CreateClientDialog } from '@/components/client/CreateClientDialog';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { EditableClientRow } from '@/components/client/EditableClientRow';
import type { Client } from '@/types/database';

export default function Clients() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchClients = async () => {
    setLoading(true);
    const { data } = await supabase.from('clients').select('*').order('full_name');
    setClients((data as Client[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchClients();
  }, []);

  return (
    <AppLayout title="Clients" breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Clients' }]}>
      <div className="space-y-6">
        <div className="flex justify-end">
          <CreateClientDialog onSuccess={fetchClients} />
        </div>

        {loading ? (
          <Card className="animate-pulse bg-muted h-64" />
        ) : clients.length > 0 ? (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map(client => (
                  <EditableClientRow key={client.id} client={client} onUpdate={fetchClients} />
                ))}
              </TableBody>
            </Table>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              No clients yet. Click "Add Client" to create your first one.
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
