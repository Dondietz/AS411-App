import { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { MessagingTab } from '@/components/messaging/MessagingTab';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { MessageSquare, Search, MapPin, Building2, Filter } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Property } from '@/types/database';

interface PropertyWithUnread extends Property {
  unreadCount: number;
}

export default function Messages() {
  const { user, isClient, isCoordinator } = useAuth();
  const [searchParams] = useSearchParams();
  const [properties, setProperties] = useState<PropertyWithUnread[]>([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchUnreadCounts = useCallback(async (propertyIds: string[]) => {
    if (!user || propertyIds.length === 0) return {};

    const unreadCounts: Record<string, number> = {};

    // Get all threads and participants for these properties
    const { data: threads } = await supabase
      .from('threads')
      .select(`
        id,
        property_id,
        participants:thread_participants(user_id, last_read_at)
      `)
      .in('property_id', propertyIds)
      .eq('is_archived', false);

    if (!threads) return unreadCounts;

    // For each thread, calculate unread count for current user
    await Promise.all(
      threads.map(async (thread) => {
        const participant = thread.participants?.find(
          (p: { user_id: string; last_read_at: string | null }) => p.user_id === user.id
        );

        if (participant) {
          let query = supabase
            .from('thread_messages')
            .select('*', { count: 'exact', head: true })
            .eq('thread_id', thread.id)
            .neq('sender_user_id', user.id);

          if (participant.last_read_at) {
            query = query.gt('created_at', participant.last_read_at);
          }

          const { count } = await query;
          
          if (count && count > 0) {
            unreadCounts[thread.property_id] = (unreadCounts[thread.property_id] || 0) + count;
          }
        }
      })
    );

    return unreadCounts;
  }, [user]);

  const fetchProperties = useCallback(async () => {
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .order('updated_at', { ascending: false });

    if (error) {
      console.error('Error fetching properties:', error);
      setLoading(false);
      return;
    }

    const propertyIds = (data || []).map(p => p.id);
    const unreadCounts = await fetchUnreadCounts(propertyIds);

    const propertiesWithUnread: PropertyWithUnread[] = (data || []).map(p => ({
      ...p,
      unreadCount: unreadCounts[p.id] || 0,
    }));

    setProperties(propertiesWithUnread);
    setLoading(false);
  }, [fetchUnreadCounts]);

  useEffect(() => {
    fetchProperties();

    // Subscribe to new messages to update unread counts
    const channel = supabase
      .channel('messages-unread')
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'thread_messages' },
        () => fetchProperties()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchProperties]);

  // Auto-select property for clients (skip property selection step)
  useEffect(() => {
    if (!loading && properties.length > 0 && !selectedPropertyId) {
      // Check if there's a property param in the URL
      const propertyParam = searchParams.get('property');
      if (propertyParam && properties.some(p => p.id === propertyParam)) {
        setSelectedPropertyId(propertyParam);
      } else if (isClient) {
        // For clients, auto-select the first property
        setSelectedPropertyId(properties[0].id);
      }
    }
  }, [loading, properties, selectedPropertyId, isClient, searchParams]);

  const filteredProperties = properties.filter(p => {
    const matchesSearch = p.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesUnread = showUnreadOnly ? p.unreadCount > 0 : true;
    return matchesSearch && matchesUnread;
  });

  const selectedProperty = properties.find(p => p.id === selectedPropertyId);

  const statusColors: Record<string, string> = {
    intake: 'bg-blue-100 text-blue-700',
    cleanout: 'bg-amber-100 text-amber-700',
    repair: 'bg-orange-100 text-orange-700',
    listing: 'bg-purple-100 text-purple-700',
    escrow: 'bg-emerald-100 text-emerald-700',
    closed: 'bg-gray-100 text-gray-700',
  };

  // For clients with a single property, skip the property selection UI entirely
  const showPropertyList = !isClient || properties.length > 1;

  return (
    <AppLayout 
      title="Communication Hub" 
      breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Messages' }]}
    >
      <div className={cn(
        "grid gap-4 h-[calc(100vh-12rem)]",
        showPropertyList ? "lg:grid-cols-4" : ""
      )}>
        {/* Property List - Hidden for clients with single property */}
        {showPropertyList && (
          <Card className="lg:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Properties
              </CardTitle>
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search properties..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8"
                />
              </div>
              {!isClient && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t">
                  <Switch
                    id="unread-filter"
                    checked={showUnreadOnly}
                    onCheckedChange={setShowUnreadOnly}
                    className="scale-90"
                  />
                  <Label 
                    htmlFor="unread-filter" 
                    className="text-xs text-muted-foreground cursor-pointer flex items-center gap-1"
                  >
                    <Filter className="h-3 w-3" />
                    Unread only
                  </Label>
                </div>
              )}
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-20rem)]">
                {loading ? (
                  <div className="p-4 space-y-3">
                    {[1, 2, 3, 4, 5].map(i => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : filteredProperties.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground text-sm">
                    No properties found
                  </div>
                ) : (
                  <div className="divide-y">
                    {filteredProperties.map(property => (
                      <button
                        key={property.id}
                        onClick={() => setSelectedPropertyId(property.id)}
                        className={cn(
                          'w-full p-3 text-left hover:bg-muted/50 transition-colors',
                          selectedPropertyId === property.id && 'bg-muted'
                        )}
                      >
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="font-medium text-sm truncate">
                                {property.address}
                              </p>
                              {property.unreadCount > 0 && (
                                <Badge 
                                  variant="destructive" 
                                  className="h-5 min-w-5 px-1.5 text-[10px] font-bold shrink-0"
                                >
                                  {property.unreadCount > 99 ? '99+' : property.unreadCount}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {property.city}, {property.state}
                            </p>
                            <Badge 
                              variant="secondary" 
                              className={cn('mt-1 text-[10px] capitalize', statusColors[property.status])}
                            >
                              {property.status}
                            </Badge>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        )}

        {/* Messages Area */}
        <div className={showPropertyList ? "lg:col-span-3" : ""}>
          {selectedPropertyId && selectedProperty ? (
            <div className="h-full">
              <div className="mb-4">
                <h2 className="font-semibold text-lg">{selectedProperty.address}</h2>
                <p className="text-sm text-muted-foreground">
                  {selectedProperty.city}, {selectedProperty.state}
                </p>
              </div>
              <MessagingTab 
                propertyId={selectedPropertyId} 
                propertyAddress={selectedProperty.address}
              />
            </div>
          ) : (
            <Card className="h-full flex items-center justify-center">
              <CardContent className="text-center py-12">
                <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
                <p className="text-muted-foreground">
                  {loading ? 'Loading...' : 'Select a property to view its messages'}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </AppLayout>
  );
}