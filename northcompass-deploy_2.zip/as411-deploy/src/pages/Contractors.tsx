import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, HardHat, Phone, Mail, DollarSign, Edit, Trash2, MoreVertical, MessageSquare, UserPlus, UserCheck } from 'lucide-react';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { CreateContractorDialog } from '@/components/contractors/CreateContractorDialog';
import { LinkUserDialog } from '@/components/contractors/LinkUserDialog';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

export default function Contractors() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingContractor, setEditingContractor] = useState<Contractor | null>(null);
  const [deletingContractor, setDeletingContractor] = useState<Contractor | null>(null);
  const [linkingContractor, setLinkingContractor] = useState<Contractor | null>(null);
  const queryClient = useQueryClient();

  const { data: contractors = [], isLoading } = useQuery({
    queryKey: ['contractors'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .order('company_name');
      if (error) throw error;
      return data as Contractor[];
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('contractors').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contractors'] });
      toast.success('Contractor deleted');
      setDeletingContractor(null);
    },
    onError: (error) => {
      toast.error('Failed to delete contractor: ' + error.message);
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from('contractors')
        .update({ is_active })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contractors'] });
      toast.success('Contractor status updated');
    },
    onError: (error) => {
      toast.error('Failed to update status: ' + error.message);
    },
  });

  const filteredContractors = contractors.filter((contractor) => {
    const search = searchQuery.toLowerCase();
    return (
      contractor.company_name.toLowerCase().includes(search) ||
      contractor.contact_name?.toLowerCase().includes(search) ||
      contractor.specialty?.toLowerCase().includes(search)
    );
  });

  const activeContractors = filteredContractors.filter((c) => c.is_active);
  const inactiveContractors = filteredContractors.filter((c) => !c.is_active);

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Contractors</h1>
            <p className="text-muted-foreground mt-1">
              Manage contractors for property work and financial tracking
            </p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Add Contractor
          </Button>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search contractors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-primary/10 p-2">
                  <HardHat className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{contractors.length}</p>
                  <p className="text-sm text-muted-foreground">Total Contractors</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-green-500/10 p-2">
                  <HardHat className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{contractors.filter((c) => c.is_active).length}</p>
                  <p className="text-sm text-muted-foreground">Active</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-muted p-2">
                  <HardHat className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{contractors.filter((c) => !c.is_active).length}</p>
                  <p className="text-sm text-muted-foreground">Inactive</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contractors Grid */}
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">Loading contractors...</div>
        ) : filteredContractors.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <HardHat className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-1">No contractors found</h3>
              <p className="text-muted-foreground">
                {searchQuery ? 'Try a different search term' : 'Add your first contractor to get started'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {activeContractors.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Active Contractors</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {activeContractors.map((contractor) => (
                    <ContractorCard
                      key={contractor.id}
                      contractor={contractor}
                      onEdit={() => setEditingContractor(contractor)}
                      onDelete={() => setDeletingContractor(contractor)}
                      onToggleActive={() =>
                        toggleActiveMutation.mutate({ id: contractor.id, is_active: false })
                      }
                      onMessage={() => navigate(`/contractors/${contractor.id}`)}
                      onLinkUser={() => setLinkingContractor(contractor)}
                    />
                  ))}
                </div>
              </div>
            )}
            {inactiveContractors.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4 text-muted-foreground">Inactive Contractors</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {inactiveContractors.map((contractor) => (
                    <ContractorCard
                      key={contractor.id}
                      contractor={contractor}
                      onEdit={() => setEditingContractor(contractor)}
                      onDelete={() => setDeletingContractor(contractor)}
                      onToggleActive={() =>
                        toggleActiveMutation.mutate({ id: contractor.id, is_active: true })
                      }
                      onMessage={() => navigate(`/contractors/${contractor.id}`)}
                      onLinkUser={() => setLinkingContractor(contractor)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create Dialog */}
      <CreateContractorDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['contractors'] });
          setCreateDialogOpen(false);
        }}
      />

      {/* Edit Dialog */}
      {editingContractor && (
        <CreateContractorDialog
          open={!!editingContractor}
          onOpenChange={(open) => !open && setEditingContractor(null)}
          contractor={editingContractor}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['contractors'] });
            setEditingContractor(null);
          }}
        />
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingContractor} onOpenChange={(open) => !open && setDeletingContractor(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Contractor</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingContractor?.company_name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingContractor && deleteMutation.mutate(deletingContractor.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Link User Dialog */}
      {linkingContractor && (
        <LinkUserDialog
          open={!!linkingContractor}
          onOpenChange={(open) => !open && setLinkingContractor(null)}
          contractor={linkingContractor}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['contractors'] });
            setLinkingContractor(null);
          }}
        />
      )}
    </AppLayout>
  );
}

function ContractorCard({
  contractor,
  onEdit,
  onDelete,
  onToggleActive,
  onMessage,
  onLinkUser,
}: {
  contractor: Contractor;
  onEdit: () => void;
  onDelete: () => void;
  onToggleActive: () => void;
  onMessage: () => void;
  onLinkUser: () => void;
}) {
  return (
    <Card 
      className={`cursor-pointer transition-shadow hover:shadow-md ${!contractor.is_active ? 'opacity-60' : ''}`}
      onClick={onMessage}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">{contractor.company_name}</CardTitle>
              {contractor.user_id && (
                <span title="User account linked">
                  <UserCheck className="h-4 w-4 text-green-600" />
                </span>
              )}
            </div>
            {contractor.contact_name && (
              <p className="text-sm text-muted-foreground">{contractor.contact_name}</p>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onMessage(); }}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Message
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onLinkUser(); }}>
                {contractor.user_id ? (
                  <>
                    <UserCheck className="h-4 w-4 mr-2" />
                    Manage User Link
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Link User Account
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(); }}>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onToggleActive(); }}>
                {contractor.is_active ? 'Mark Inactive' : 'Mark Active'}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(); }} className="text-destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="space-y-3" onClick={(e) => e.stopPropagation()}>
        {contractor.specialty && (
          <Badge variant="secondary" className="font-normal">
            {contractor.specialty}
          </Badge>
        )}
        <div className="space-y-2 text-sm">
          {contractor.phone && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Phone className="h-4 w-4" />
              <a href={`tel:${contractor.phone}`} className="hover:text-foreground">
                {contractor.phone}
              </a>
            </div>
          )}
          {contractor.email && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Mail className="h-4 w-4" />
              <a href={`mailto:${contractor.email}`} className="hover:text-foreground truncate">
                {contractor.email}
              </a>
            </div>
          )}
          {contractor.hourly_rate && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <DollarSign className="h-4 w-4" />
              <span>${contractor.hourly_rate}/hr</span>
            </div>
          )}
        </div>
        {contractor.notes && (
          <p className="text-sm text-muted-foreground border-t pt-3 mt-3">{contractor.notes}</p>
        )}
      </CardContent>
    </Card>
  );
}
