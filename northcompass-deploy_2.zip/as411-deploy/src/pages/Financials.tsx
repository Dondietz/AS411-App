import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/integrations/supabase/client';
import { exportToCSV, exportToPDF } from '@/lib/exportFinancials';
import { DollarSign, TrendingUp, Clock, CheckCircle, Building2, Download, FileText, FileSpreadsheet } from 'lucide-react';

interface PropertyFinancials {
  id: string;
  address: string;
  city: string;
  status: string;
  sale_price: number | null;
  estimated: number;
  paid: number;
  deferred: number;
}

export default function Financials() {
  const [properties, setProperties] = useState<PropertyFinancials[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      const { data: propertiesData } = await supabase
        .from('properties')
        .select('id, address, city, status, sale_price');

      if (!propertiesData) {
        setLoading(false);
        return;
      }

      const { data: costsData } = await supabase.from('costs').select('*');

      const propertyFinancials = propertiesData.map(property => {
        const propertyCosts = costsData?.filter(c => c.property_id === property.id) || [];
        return {
          id: property.id,
          address: property.address,
          city: property.city,
          status: property.status,
          sale_price: property.sale_price ? Number(property.sale_price) : null,
          estimated: propertyCosts.filter(c => c.cost_type === 'estimated').reduce((sum, c) => sum + Number(c.amount), 0),
          paid: propertyCosts.filter(c => c.cost_type === 'paid').reduce((sum, c) => sum + Number(c.amount), 0),
          deferred: propertyCosts.filter(c => c.cost_type === 'deferred').reduce((sum, c) => sum + Number(c.amount), 0),
        };
      });

      setProperties(propertyFinancials);
      setLoading(false);
    }

    fetchData();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const totals = properties.reduce(
    (acc, p) => ({
      estimated: acc.estimated + p.estimated,
      paid: acc.paid + p.paid,
      deferred: acc.deferred + p.deferred,
      salePrice: acc.salePrice + (p.sale_price || 0),
    }),
    { estimated: 0, paid: 0, deferred: 0, salePrice: 0 }
  );

  const totalCosts = totals.paid + totals.deferred;
  const paidPercentage = totalCosts > 0 ? (totals.paid / totalCosts) * 100 : 0;
  const estimatedProfit = totals.salePrice - totalCosts;

  return (
    <AppLayout title="Financials" breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Financials' }]}>
      <div className="space-y-6">
        {/* Header with Export */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-display">Financial Overview</h2>
            <p className="text-muted-foreground">Track costs and profitability across all properties</p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" disabled={properties.length === 0}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => exportToPDF(properties)}>
                <FileText className="h-4 w-4 mr-2" />
                Export as PDF
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToCSV(properties)}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Export as CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-muted p-2">
                  <TrendingUp className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estimated</p>
                  <p className="text-2xl font-bold">{formatCurrency(totals.estimated)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-success/10 p-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Paid</p>
                  <p className="text-2xl font-bold text-success">{formatCurrency(totals.paid)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-warning/10 p-2">
                  <Clock className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Deferred</p>
                  <p className="text-2xl font-bold text-warning">{formatCurrency(totals.deferred)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className={`rounded-full p-2 ${estimatedProfit >= 0 ? 'bg-success/10' : 'bg-destructive/10'}`}>
                  <DollarSign className={`h-5 w-5 ${estimatedProfit >= 0 ? 'text-success' : 'text-destructive'}`} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Est. Net Profit</p>
                  <p className={`text-2xl font-bold ${estimatedProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                    {formatCurrency(estimatedProfit)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Progress */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Overall Payment Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {formatCurrency(totals.paid)} paid of {formatCurrency(totalCosts)} total
                </span>
                <span className="font-medium">{Math.round(paidPercentage)}%</span>
              </div>
              <Progress value={paidPercentage} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Properties Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Property Financials
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="py-8 text-center text-muted-foreground">Loading...</div>
            ) : properties.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground">No properties found.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Property</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Estimated</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead className="text-right">Deferred</TableHead>
                    <TableHead className="text-right">Sale Price</TableHead>
                    <TableHead className="text-right">Est. Net</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {properties.map(property => {
                    const propertyTotal = property.paid + property.deferred;
                    const propertyNet = (property.sale_price || 0) - propertyTotal;
                    return (
                      <TableRow key={property.id}>
                        <TableCell>
                          <Link
                            to={`/properties/${property.id}`}
                            className="font-medium hover:text-primary hover:underline"
                          >
                            {property.address}
                          </Link>
                          <p className="text-sm text-muted-foreground">{property.city}</p>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {property.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(property.estimated)}</TableCell>
                        <TableCell className="text-right text-success">{formatCurrency(property.paid)}</TableCell>
                        <TableCell className="text-right text-warning">{formatCurrency(property.deferred)}</TableCell>
                        <TableCell className="text-right">
                          {property.sale_price ? formatCurrency(property.sale_price) : '—'}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${propertyNet >= 0 ? 'text-success' : 'text-destructive'}`}>
                          {property.sale_price ? formatCurrency(propertyNet) : '—'}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
