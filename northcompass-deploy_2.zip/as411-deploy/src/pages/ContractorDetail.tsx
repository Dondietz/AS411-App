import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Phone, 
  Mail, 
  DollarSign, 
  MessageSquare, 
  FileText,
  HardHat,
  Building
} from 'lucide-react';
import { SendSmsDialog } from '@/components/contractors/SendSmsDialog';
import { SendDocumentDialog } from '@/components/contractors/SendDocumentDialog';
import { ContractorCommunicationHistory } from '@/components/contractors/ContractorCommunicationHistory';
import { ContractorBidsTab } from '@/components/contractors/ContractorBidsTab';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

export default function ContractorDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [smsDialogOpen, setSmsDialogOpen] = useState(false);
  const [documentDialogOpen, setDocumentDialogOpen] = useState(false);

  const { data: contractor, isLoading } = useQuery({
    queryKey: ['contractor', id],
    queryFn: async () => {
      if (!id) throw new Error('No contractor ID');
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return data as Contractor;
    },
    enabled: !!id,
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('id, address, city')
        .order('address');
      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading contractor...</div>
        </div>
      </AppLayout>
    );
  }

  if (!contractor) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <div className="text-muted-foreground">Contractor not found</div>
          <Button variant="outline" onClick={() => navigate('/contractors')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Contractors
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/contractors')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-display font-bold text-foreground">
                  {contractor.company_name}
                </h1>
                <Badge variant={contractor.is_active ? 'default' : 'secondary'}>
                  {contractor.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </div>
              {contractor.contact_name && (
                <p className="text-muted-foreground mt-1">{contractor.contact_name}</p>
              )}
            </div>
          </div>
          <div className="flex gap-2 ml-12 sm:ml-0">
            <Button 
              variant="outline" 
              onClick={() => setSmsDialogOpen(true)}
              disabled={!contractor.phone}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Send SMS
            </Button>
            <Button onClick={() => setDocumentDialogOpen(true)}>
              <FileText className="h-4 w-4 mr-2" />
              Send Document
            </Button>
          </div>
        </div>

        {/* Contractor Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <HardHat className="h-5 w-5" />
              Contractor Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {contractor.specialty && (
                <div>
                  <p className="text-sm text-muted-foreground">Specialty</p>
                  <Badge variant="secondary" className="mt-1">{contractor.specialty}</Badge>
                </div>
              )}
              {contractor.phone && (
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <a 
                    href={`tel:${contractor.phone}`} 
                    className="flex items-center gap-2 text-primary hover:underline mt-1"
                  >
                    <Phone className="h-4 w-4" />
                    {contractor.phone}
                  </a>
                </div>
              )}
              {contractor.email && (
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <a 
                    href={`mailto:${contractor.email}`} 
                    className="flex items-center gap-2 text-primary hover:underline mt-1"
                  >
                    <Mail className="h-4 w-4" />
                    {contractor.email}
                  </a>
                </div>
              )}
              {contractor.hourly_rate && (
                <div>
                  <p className="text-sm text-muted-foreground">Hourly Rate</p>
                  <p className="flex items-center gap-2 mt-1">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    ${contractor.hourly_rate}/hr
                  </p>
                </div>
              )}
            </div>
            {contractor.notes && (
              <div className="mt-4 pt-4 border-t">
                <p className="text-sm text-muted-foreground">Notes</p>
                <p className="mt-1">{contractor.notes}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bids & Communication History */}
        <Tabs defaultValue="bids" className="w-full">
          <TabsList>
            <TabsTrigger value="bids">Bids & Quotes</TabsTrigger>
            <TabsTrigger value="history">Communication History</TabsTrigger>
          </TabsList>
          <TabsContent value="bids" className="mt-4">
            <ContractorBidsTab contractor={contractor} properties={properties} />
          </TabsContent>
          <TabsContent value="history" className="mt-4">
            <ContractorCommunicationHistory contractorId={contractor.id} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      <SendSmsDialog
        open={smsDialogOpen}
        onOpenChange={setSmsDialogOpen}
        contractor={contractor}
        properties={properties}
      />
      <SendDocumentDialog
        open={documentDialogOpen}
        onOpenChange={setDocumentDialogOpen}
        contractor={contractor}
        properties={properties}
      />
    </AppLayout>
  );
}
