// Messaging module type definitions

export type ThreadType = 'client_coord' | 'contractor_coord' | 'internal';
export type MessageType = 'text' | 'image' | 'file' | 'system';

export interface Thread {
  id: string;
  property_id: string;
  thread_type: ThreadType;
  title: string;
  created_by_user_id?: string;
  last_message_at: string;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
  // Joined data
  participants?: ThreadParticipant[];
  last_message?: ThreadMessage;
  unread_count?: number;
}

export interface ThreadParticipant {
  id: string;
  thread_id: string;
  user_id: string;
  role: string;
  last_read_at?: string;
  muted: boolean;
  created_at: string;
  // Joined data
  profile?: {
    id: string;
    full_name: string;
    email: string;
    avatar_url?: string;
  };
}

export interface ThreadMessage {
  id: string;
  thread_id: string;
  property_id: string;
  sender_user_id?: string;
  sender_role: string;
  message_type: MessageType;
  body: string;
  attachment_url?: string;
  created_at: string;
  edited_at?: string;
  // Joined data
  sender?: {
    id: string;
    full_name: string;
    email: string;
    avatar_url?: string;
  };
}

export interface CreateThreadInput {
  property_id: string;
  thread_type: ThreadType;
  title: string;
  participant_user_ids: string[];
}

export interface SendMessageInput {
  thread_id: string;
  property_id: string;
  body: string;
  message_type?: MessageType;
  attachment_url?: string;
}
