import { format } from 'date-fns';
import templateUrl from '@/assets/AS411_Invoice_TEMPLATE.xlsx';
import { read, utils, writeFileXLSX, type WorkSheet } from 'xlsx';

interface DeferredInvoiceProperty {
  id: string;
  address: string;
  city?: string;
  state?: string;
  zipCode?: string;
  salePrice?: number;
  clientName?: string;
  clientEmail?: string | null;
  clientPhone?: string | null;
}

interface DeferredInvoiceCost {
  description: string;
  category?: string | null;
  contractorName?: string | null;
  invoiceNumber?: string | null;
  amount: number;
  createdAt?: string;
  notes?: string | null;
}

interface ExportDeferredCostsInvoiceParams {
  property: DeferredInvoiceProperty;
  costs: DeferredInvoiceCost[];
}

const CURRENCY_FORMAT = '$#,##0.00';
const MAX_TEMPLATE_LINE_ITEMS = 10;

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);

const normalize = (value: unknown) => String(value ?? '').trim().replace(/\s+/g, ' ').toLowerCase();

const findCellAddress = (worksheet: WorkSheet, text: string) => {
  const target = normalize(text);

  return Object.entries(worksheet).find(([address, cell]) => {
    if (address.startsWith('!') || !cell || typeof cell !== 'object' || !('v' in cell)) return false;
    return normalize(cell.v) === target;
  })?.[0];
};

const offsetAddress = (address: string, rowOffset = 0, columnOffset = 0) => {
  const cell = utils.decode_cell(address);
  return utils.encode_cell({ r: cell.r + rowOffset, c: cell.c + columnOffset });
};

const setCellValue = (worksheet: WorkSheet, address: string, value: string | number) => {
  const existing = worksheet[address] ?? {};
  worksheet[address] = {
    ...existing,
    t: typeof value === 'number' ? 'n' : 's',
    v: value,
  };
};

const setCurrencyValue = (worksheet: WorkSheet, address: string, value: number) => {
  const existing = worksheet[address] ?? {};
  worksheet[address] = {
    ...existing,
    t: 'n',
    v: value,
    z: CURRENCY_FORMAT,
  };
};

const formatLocation = (property: DeferredInvoiceProperty) =>
  [property.address, [property.city, property.state, property.zipCode].filter(Boolean).join(', ')].filter(Boolean).join('\n');

const buildLineItems = (costs: DeferredInvoiceCost[]) => {
  if (costs.length <= MAX_TEMPLATE_LINE_ITEMS) return costs;

  const visibleCosts = costs.slice(0, MAX_TEMPLATE_LINE_ITEMS - 1);
  const remainingCosts = costs.slice(MAX_TEMPLATE_LINE_ITEMS - 1);
  const remainingTotal = remainingCosts.reduce((sum, cost) => sum + Number(cost.amount), 0);

  visibleCosts.push({
    description: `Additional ${remainingCosts.length} deferred cost item${remainingCosts.length === 1 ? '' : 's'}`,
    amount: remainingTotal,
    notes: 'Combined to fit invoice template',
  });

  return visibleCosts;
};

const buildDescription = (cost: DeferredInvoiceCost) => {
  const meta = [cost.category, cost.contractorName].filter(Boolean).join(' • ');
  return meta ? `${cost.description} — ${meta}` : cost.description;
};

const setValueNextToLabel = (worksheet: WorkSheet, label: string, value: string | number, currency = false) => {
  const labelCell = findCellAddress(worksheet, label);
  if (!labelCell) return;
  const target = offsetAddress(labelCell, 0, 1);
  if (currency && typeof value === 'number') {
    setCurrencyValue(worksheet, target, value);
    return;
  }
  setCellValue(worksheet, target, value);
};

const setValueBelowLabel = (worksheet: WorkSheet, label: string, value: string | number) => {
  const labelCell = findCellAddress(worksheet, label);
  if (!labelCell) return;
  setCellValue(worksheet, offsetAddress(labelCell, 1, 0), value);
};

export async function exportDeferredCostsInvoice({ property, costs }: ExportDeferredCostsInvoiceParams) {
  const invoiceDate = new Date();
  const invoiceNumber = `INV-${property.id.slice(0, 8).toUpperCase()}-${format(invoiceDate, 'yyyyMMdd')}`;
  const subtotal = costs.reduce((sum, cost) => sum + Number(cost.amount), 0);
  const taxAmount = 0;
  const totalDue = subtotal + taxAmount;
  const earliestDate = costs.map((cost) => cost.createdAt).filter(Boolean).sort()[0];
  const sortedDates = costs.map((cost) => cost.createdAt).filter(Boolean).sort();
  const latestDate = sortedDates[sortedDates.length - 1];
  const durationText = earliestDate && latestDate
    ? earliestDate === latestDate
      ? '1 day'
      : `${Math.max(1, Math.ceil((new Date(latestDate).getTime() - new Date(earliestDate).getTime()) / 86400000) + 1)} days`
    : `${costs.length} item${costs.length === 1 ? '' : 's'}`;

  const response = await fetch(templateUrl);
  const buffer = await response.arrayBuffer();
  const workbook = read(buffer, { type: 'array', cellStyles: true });
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];

  setCellValue(worksheet, findCellAddress(worksheet, 'Moving Invoice') ?? 'F1', 'Deferred Invoice');
  setValueNextToLabel(worksheet, 'Name:', property.clientName || property.address);
  setValueNextToLabel(worksheet, 'Address', formatLocation(property));
  setValueNextToLabel(worksheet, 'Contact:', property.clientPhone || '—');
  setValueNextToLabel(worksheet, 'Email:', property.clientEmail || '—');
  setValueBelowLabel(worksheet, 'DATE ISSUE', format(invoiceDate, 'MMM d, yyyy'));
  setValueBelowLabel(worksheet, 'START DATE', earliestDate ? format(new Date(earliestDate), 'MMM d, yyyy') : format(invoiceDate, 'MMM d, yyyy'));
  setValueBelowLabel(worksheet, 'END DATE', latestDate ? format(new Date(latestDate), 'MMM d, yyyy') : format(invoiceDate, 'MMM d, yyyy'));
  setValueBelowLabel(worksheet, 'DURATION', durationText);
  setValueBelowLabel(
    worksheet,
    'SCOPE OF WORK',
    `Deferred cost invoice for ${property.address}${property.salePrice ? ` • Expected sale price ${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(property.salePrice)}` : ''}`,
  );

  const firstLineItemCell = findCellAddress(worksheet, '1)') ?? 'A29';
  const lineItems = buildLineItems(costs);

  for (let index = 0; index < MAX_TEMPLATE_LINE_ITEMS; index += 1) {
    const rowBase = offsetAddress(firstLineItemCell, index, 0);
    const row = utils.decode_cell(rowBase).r;
    const descriptionCell = utils.encode_cell({ r: row, c: 1 });
    const qtyCell = utils.encode_cell({ r: row, c: 5 });
    const costCell = utils.encode_cell({ r: row, c: 6 });
    const amountCell = utils.encode_cell({ r: row, c: 7 });

    const item = lineItems[index];

    setCellValue(worksheet, rowBase, `${index + 1})`);

    if (item) {
      setCellValue(worksheet, descriptionCell, buildDescription(item));
      setCellValue(worksheet, qtyCell, 1);
      setCurrencyValue(worksheet, costCell, Number(item.amount));
      setCurrencyValue(worksheet, amountCell, Number(item.amount));
    } else {
      setCellValue(worksheet, descriptionCell, '');
      setCellValue(worksheet, qtyCell, '');
      setCellValue(worksheet, costCell, '');
      setCellValue(worksheet, amountCell, '');
    }
  }

  setValueNextToLabel(worksheet, 'TOTAL AMOUNT', subtotal, true);
  setValueNextToLabel(worksheet, 'DISCOUNT', '0%');
  setCurrencyValue(worksheet, offsetAddress(findCellAddress(worksheet, 'DISCOUNT') ?? 'G40', 0, 2), 0);
  setValueNextToLabel(worksheet, 'SALES TAX', '0%');
  setCurrencyValue(worksheet, offsetAddress(findCellAddress(worksheet, 'SALES TAX') ?? 'G41', 0, 2), taxAmount);
  setValueNextToLabel(worksheet, 'TOTAL AMOUNT DUE', totalDue, true);
  setCellValue(worksheet, findCellAddress(worksheet, 'Preparer') ? offsetAddress(findCellAddress(worksheet, 'Preparer')!, 1, 0) : 'A46', 'North Compass');
  setCellValue(worksheet, findCellAddress(worksheet, 'Approved') ? offsetAddress(findCellAddress(worksheet, 'Approved')!, 1, 0) : 'A48', property.clientName || property.address);

  const filename = `${slugify(property.address)}-deferred-invoice-${format(invoiceDate, 'yyyy-MM-dd')}.xlsx`;
  writeFileXLSX(workbook, filename);
}
