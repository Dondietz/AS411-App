import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

/**
 * Creates the default client-coordinator thread when a property is created.
 * Called after property creation with client assigned.
 */
export async function createClientThread(
  propertyId: string,
  coordinatorId: string,
  clientName: string
): Promise<{ error?: string }> {
  // Create the thread
  const { data: thread, error: threadError } = await supabase
    .from('threads')
    .insert({
      property_id: propertyId,
      thread_type: 'client_coord',
      title: `${clientName} ↔ Coordinator`,
      created_by_user_id: coordinatorId,
    })
    .select()
    .single();

  if (threadError) return { error: threadError.message };

  // Add coordinator as participant
  const { error: participantError } = await supabase
    .from('thread_participants')
    .insert({
      thread_id: thread.id,
      user_id: coordinatorId,
      role: 'coordinator' as AppRole,
    });

  if (participantError) return { error: participantError.message };

  return {};
}

/**
 * Creates a contractor thread for communication between coordinator and contractor.
 */
export async function createContractorThread(
  propertyId: string,
  coordinatorId: string,
  contractorName: string,
  contractorUserId?: string
): Promise<{ threadId?: string; error?: string }> {
  const { data: thread, error: threadError } = await supabase
    .from('threads')
    .insert({
      property_id: propertyId,
      thread_type: 'contractor_coord',
      title: `${contractorName} ↔ Coordinator`,
      created_by_user_id: coordinatorId,
    })
    .select()
    .single();

  if (threadError) return { error: threadError.message };

  // Add coordinator as participant
  await supabase.from('thread_participants').insert({
    thread_id: thread.id,
    user_id: coordinatorId,
    role: 'coordinator' as AppRole,
  });

  // Add contractor if they have a user account
  if (contractorUserId) {
    await supabase.from('thread_participants').insert({
      thread_id: thread.id,
      user_id: contractorUserId,
      role: 'contractor' as AppRole,
    });
  }

  return { threadId: thread.id };
}

/**
 * Sends a system message to a thread.
 * Used for automated notifications from other modules.
 */
export async function sendSystemMessage(
  threadId: string,
  propertyId: string,
  message: string
): Promise<{ error?: string }> {
  const { error } = await supabase.from('thread_messages').insert({
    thread_id: threadId,
    property_id: propertyId,
    sender_role: 'admin' as AppRole,
    message_type: 'system',
    body: message,
  });

  if (error) return { error: error.message };

  // Update thread's last_message_at
  await supabase
    .from('threads')
    .update({ last_message_at: new Date().toISOString() })
    .eq('id', threadId);

  return {};
}

// ============================================================
// Integration hooks for other modules (placeholder functions)
// ============================================================

/**
 * Called when a bid is submitted by a contractor.
 * Creates a system message in the contractor's thread.
 */
export async function onBidSubmitted(
  propertyId: string,
  contractorThreadId: string,
  bidAmount: number,
  bidId: string
): Promise<void> {
  await sendSystemMessage(
    contractorThreadId,
    propertyId,
    `💰 Bid received: $${bidAmount.toLocaleString()} – View Bid`
  );
}

/**
 * Called when an invoice is uploaded by a contractor.
 * Creates a system message in the contractor's thread.
 */
export async function onInvoiceUploaded(
  propertyId: string,
  contractorThreadId: string,
  invoiceNumber: string
): Promise<void> {
  await sendSystemMessage(
    contractorThreadId,
    propertyId,
    `📄 Invoice uploaded: ${invoiceNumber} – View Invoice`
  );
}

/**
 * Called when a task is completed.
 * Creates a system message in the client thread.
 */
export async function onTaskCompleted(
  propertyId: string,
  taskName: string
): Promise<void> {
  // Find the client thread for this property
  const { data: clientThread } = await supabase
    .from('threads')
    .select('id')
    .eq('property_id', propertyId)
    .eq('thread_type', 'client_coord')
    .maybeSingle();

  if (clientThread) {
    await sendSystemMessage(
      clientThread.id,
      propertyId,
      `✅ Update: Task completed – ${taskName}`
    );
  }
}

/**
 * Gets unread message count for a user across all their threads.
 */
export async function getUnreadCount(userId: string): Promise<number> {
  const { data: participations } = await supabase
    .from('thread_participants')
    .select('thread_id, last_read_at')
    .eq('user_id', userId);

  if (!participations || participations.length === 0) return 0;

  let totalUnread = 0;

  for (const p of participations) {
    const { count } = await supabase
      .from('thread_messages')
      .select('*', { count: 'exact', head: true })
      .eq('thread_id', p.thread_id)
      .gt('created_at', p.last_read_at || '1970-01-01')
      .neq('sender_user_id', userId);

    totalUnread += count || 0;
  }

  return totalUnread;
}
