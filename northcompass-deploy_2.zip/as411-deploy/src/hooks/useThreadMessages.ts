import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import type { ThreadMessage } from '@/types/messaging';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

export function useThreadMessages(threadId: string | null) {
  const { user, roles } = useAuth();
  const [messages, setMessages] = useState<ThreadMessage[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMessages = useCallback(async () => {
    if (!threadId) {
      setMessages([]);
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('thread_messages')
      .select('*, sender:profiles(id, full_name, email, avatar_url)')
      .eq('thread_id', threadId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching messages:', error);
      return;
    }

    setMessages((data || []) as ThreadMessage[]);
    setLoading(false);

    // Update last read timestamp for current user
    if (user) {
      await supabase
        .from('thread_participants')
        .update({ last_read_at: new Date().toISOString() })
        .eq('thread_id', threadId)
        .eq('user_id', user.id);
    }
  }, [threadId, user]);

  useEffect(() => {
    fetchMessages();

    if (!threadId) return;

    // Subscribe to new messages
    const channel = supabase
      .channel(`thread-messages-${threadId}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'thread_messages', filter: `thread_id=eq.${threadId}` },
        async (payload) => {
          const { data } = await supabase
            .from('thread_messages')
            .select('*, sender:profiles(id, full_name, email, avatar_url)')
            .eq('id', payload.new.id)
            .single();
          
          if (data) {
            setMessages(prev => [...prev, data as ThreadMessage]);
            
            // Update last read
            if (user) {
              await supabase
                .from('thread_participants')
                .update({ last_read_at: new Date().toISOString() })
                .eq('thread_id', threadId)
                .eq('user_id', user.id);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [threadId, fetchMessages, user]);

  const sendMessage = async (
    body: string, 
    propertyId: string, 
    attachmentUrl?: string,
    threadTitle?: string,
    propertyAddress?: string
  ) => {
    if (!threadId || !user || !body.trim()) {
      return { error: 'Invalid input' };
    }

    const userRole = (roles[0] || 'coordinator') as AppRole;

    const { error } = await supabase.from('thread_messages').insert({
      thread_id: threadId,
      property_id: propertyId,
      sender_user_id: user.id,
      sender_role: userRole,
      body: body.trim(),
      message_type: attachmentUrl ? 'file' : 'text',
      attachment_url: attachmentUrl,
    });

    if (error) return { error: error.message };

    // Update thread's last_message_at
    await supabase
      .from('threads')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', threadId);

    // Get sender profile for notifications
    const { data: senderProfile } = await supabase
      .from('profiles')
      .select('full_name, email')
      .eq('id', user.id)
      .single();

    // Send notification based on sender role
    if (userRole === 'client') {
      // Client sending message → notify coordinator
      try {
        if (senderProfile) {
          await supabase.functions.invoke('notify-message', {
            body: {
              senderName: senderProfile.full_name,
              senderEmail: senderProfile.email,
              messageBody: body.trim(),
              threadTitle: threadTitle || 'Message Thread',
              propertyAddress: propertyAddress,
            },
          });
        }
      } catch (notifyError) {
        console.error('Error sending notification to coordinator:', notifyError);
      }
    } else if (userRole === 'coordinator' || userRole === 'admin') {
      // Coordinator sending message → notify client participants
      try {
        // Get thread participants who are clients (including phone for SMS)
        const { data: participants } = await supabase
          .from('thread_participants')
          .select('user_id, role, profile:profiles(id, full_name, email, phone)')
          .eq('thread_id', threadId)
          .eq('role', 'client');

        if (participants && participants.length > 0) {
          // Send notification to each client participant
          for (const participant of participants) {
            const clientProfile = participant.profile as { id: string; full_name: string; email: string; phone: string | null } | null;
            
            // If no phone in profile, check the clients table (phone may be stored there)
            let clientPhone = clientProfile?.phone;
            if (!clientPhone && clientProfile?.id) {
              const { data: clientRecord } = await supabase
                .from('clients')
                .select('phone')
                .eq('user_id', clientProfile.id)
                .single();
              clientPhone = clientRecord?.phone || null;
            }
            
            if (clientProfile?.email || clientPhone) {
              console.log('Sending notification to client:', clientProfile?.email, clientPhone);
              await supabase.functions.invoke('notify-message', {
                body: {
                  senderName: senderProfile?.full_name || 'Your Coordinator',
                  senderEmail: senderProfile?.email || '',
                  messageBody: body.trim(),
                  threadTitle: threadTitle || 'Message Thread',
                  propertyAddress: propertyAddress,
                  recipientEmail: clientProfile?.email,
                  recipientName: clientProfile?.full_name,
                  recipientPhone: clientPhone,
                },
              });
            }
          }
        }
      } catch (notifyError) {
        console.error('Error sending notification to client:', notifyError);
      }
    }

    return { error: null };
  };

  return {
    messages,
    loading,
    sendMessage,
    refetch: fetchMessages,
  };
}
