import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import type { Thread, ThreadMessage, ThreadParticipant } from '@/types/messaging';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

export function useThreads(propertyId: string) {
  const { user, roles } = useAuth();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchThreads = useCallback(async () => {
    if (!propertyId) return;
    
    const { data, error } = await supabase
      .from('threads')
      .select(`
        *,
        participants:thread_participants(
          *,
          profile:profiles(id, full_name, email, avatar_url)
        )
      `)
      .eq('property_id', propertyId)
      .eq('is_archived', false)
      .order('last_message_at', { ascending: false });

    if (error) {
      console.error('Error fetching threads:', error);
      return;
    }

    // Fetch last message for each thread
    const threadsWithLastMessage = await Promise.all(
      (data || []).map(async (thread) => {
        const { data: lastMsg } = await supabase
          .from('thread_messages')
          .select('*, sender:profiles(id, full_name, email, avatar_url)')
          .eq('thread_id', thread.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        // Calculate unread count
        const currentParticipant = thread.participants?.find(
          (p: ThreadParticipant) => p.user_id === user?.id
        );
        
        let unreadCount = 0;
        if (currentParticipant?.last_read_at) {
          const { count } = await supabase
            .from('thread_messages')
            .select('*', { count: 'exact', head: true })
            .eq('thread_id', thread.id)
            .gt('created_at', currentParticipant.last_read_at)
            .neq('sender_user_id', user?.id);
          unreadCount = count || 0;
        }

        return {
          ...thread,
          last_message: lastMsg as ThreadMessage | undefined,
          unread_count: unreadCount,
        } as Thread;
      })
    );

    setThreads(threadsWithLastMessage);
    setLoading(false);
  }, [propertyId, user?.id]);

  useEffect(() => {
    fetchThreads();

    // Subscribe to thread updates
    const channel = supabase
      .channel(`threads-${propertyId}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'threads', filter: `property_id=eq.${propertyId}` },
        () => fetchThreads()
      )
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'thread_messages' },
        () => fetchThreads()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [propertyId, fetchThreads]);

  const createThread = async (
    threadType: 'client_coord' | 'contractor_coord' | 'internal',
    title: string,
    participantUserIds: string[]
  ) => {
    if (!user) return { error: 'Not authenticated' };

    const userRole = (roles[0] || 'coordinator') as AppRole;

    // Create the thread using the SECURITY DEFINER function
    const { data: newThreadId, error: threadError } = await supabase
      .rpc('create_thread', {
        thread_property_id: propertyId,
        thread_type_in: threadType,
        thread_title: title,
      });

    if (threadError) return { error: threadError.message };

    // Add participants - coordinator + all specified participants
    const participantRole: AppRole = threadType === 'client_coord' ? 'client' : 'contractor';
    const participants: { thread_id: string; user_id: string; role: AppRole }[] = [
      { thread_id: newThreadId, user_id: user.id, role: userRole },
    ];

    // Add each participant with their appropriate role
    for (const userId of participantUserIds) {
      if (userId && userId !== user.id) {
        participants.push({
          thread_id: newThreadId,
          user_id: userId,
          role: participantRole,
        });
      }
    }

    if (participants.length > 0) {
      const { error: participantError } = await supabase
        .from('thread_participants')
        .insert(participants);

      if (participantError) {
        console.error('Error adding participants:', participantError);
        return { error: participantError.message };
      }
    }

    await fetchThreads();
    return { data: { id: newThreadId } };
  };

  const archiveThread = async (threadId: string) => {
    const { error } = await supabase
      .from('threads')
      .update({ is_archived: true })
      .eq('id', threadId);

    if (!error) {
      await fetchThreads();
    }
    return { error };
  };

  return {
    threads,
    loading,
    createThread,
    archiveThread,
    refetch: fetchThreads,
  };
}
