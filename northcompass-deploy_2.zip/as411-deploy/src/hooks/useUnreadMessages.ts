import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

export function useUnreadMessages() {
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const currentUserIdRef = useRef<string | null>(null);

  // Request notification permission on mount
  useEffect(() => {
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
      if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
          setNotificationPermission(permission);
        });
      }
    }
  }, []);

  const playNotificationSound = useCallback(() => {
    try {
      const audio = new Audio('/sounds/notification.mp3');
      audio.volume = 0.5;
      audio.play().catch(err => console.log('Could not play notification sound:', err));
    } catch (err) {
      console.log('Error creating audio:', err);
    }
  }, []);

  const showNotification = useCallback(async (message: { body: string; sender_user_id: string | null; thread_id: string }) => {
    if (message.sender_user_id === currentUserIdRef.current) return;

    // Play notification sound regardless of notification permission
    playNotificationSound();

    if (notificationPermission !== 'granted') return;

    // Get sender name
    let senderName = 'Someone';
    if (message.sender_user_id) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', message.sender_user_id)
        .single();
      if (profile?.full_name) {
        senderName = profile.full_name;
      }
    }

    // Get thread title
    const { data: thread } = await supabase
      .from('threads')
      .select('title')
      .eq('id', message.thread_id)
      .single();

    const notification = new Notification('New Message', {
      body: `${senderName}: ${message.body.substring(0, 100)}${message.body.length > 100 ? '...' : ''}`,
      icon: '/favicon.ico',
      tag: `message-${message.thread_id}`,
      requireInteraction: false,
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  }, [notificationPermission, playNotificationSound]);

  const fetchUnreadCount = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setUnreadCount(0);
      setLoading(false);
      currentUserIdRef.current = null;
      return;
    }
    currentUserIdRef.current = user.id;

    // Get all threads the user participates in with their last_read_at
    const { data: participations, error: partError } = await supabase
      .from('thread_participants')
      .select('thread_id, last_read_at')
      .eq('user_id', user.id);

    if (partError || !participations?.length) {
      setUnreadCount(0);
      setLoading(false);
      return;
    }

    // Count unread messages across all threads
    let totalUnread = 0;
    for (const participation of participations) {
      const query = supabase
        .from('thread_messages')
        .select('id', { count: 'exact', head: true })
        .eq('thread_id', participation.thread_id)
        .neq('sender_user_id', user.id);

      if (participation.last_read_at) {
        query.gt('created_at', participation.last_read_at);
      }

      const { count } = await query;
      totalUnread += count || 0;
    }

    setUnreadCount(totalUnread);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchUnreadCount();

    // Subscribe to new messages
    const channel = supabase
      .channel('unread-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'thread_messages',
        },
        (payload) => {
          const newMessage = payload.new as { body: string; sender_user_id: string | null; thread_id: string };
          showNotification(newMessage);
          fetchUnreadCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'thread_participants',
        },
        () => {
          fetchUnreadCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchUnreadCount, showNotification]);

  return { unreadCount, loading, refetch: fetchUnreadCount };
}
