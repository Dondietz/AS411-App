import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface EdgeFunctionOptions {
  body?: Record<string, unknown>;
  headers?: Record<string, string>;
}

interface EdgeFunctionResult<T> {
  data: T | null;
  error: Error | null;
}

// Redirect to auth page without using hooks
const redirectToAuth = () => {
  setTimeout(() => {
    window.location.href = '/auth';
  }, 0);
};

export function useEdgeFunction() {
  const [isLoading, setIsLoading] = useState(false);

  const invoke = useCallback(async <T = unknown>(
    functionName: string,
    options?: EdgeFunctionOptions,
    maxRetries = 2
  ): Promise<EdgeFunctionResult<T>> => {
    setIsLoading(true);
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const refreshOrThrow = async () => {
          const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
          if (refreshError || !refreshData.session) {
            try {
              await supabase.auth.signOut();
            } catch {
              // ignore
            }
            redirectToAuth();
            throw new Error('Your session expired. Redirecting to login...');
          }
          return refreshData.session;
        };

        // Ensure we have a session
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession();

        if (sessionError) {
          throw new Error('Session error: ' + sessionError.message);
        }

        if (!session) {
          await refreshOrThrow();
        }

        const { data, error } = await supabase.functions.invoke<T>(functionName, {
          body: options?.body,
          headers: options?.headers,
        });

        if (error) {
          const isAuthError =
            error.message?.includes('Unauthorized') ||
            error.message?.includes('403') ||
            error.message?.includes('session') ||
            error.message?.includes('JWT');

          if (isAuthError && attempt < maxRetries) {
            await refreshOrThrow();
            continue;
          }
          throw error;
        }

        // Check for error in response data
        if (data && typeof data === 'object' && 'error' in data) {
          const responseError = (data as { error: string }).error;
          const isAuthError =
            responseError?.includes('Unauthorized') ||
            responseError?.includes('verify user');

          if (isAuthError && attempt < maxRetries) {
            await refreshOrThrow();
            continue;
          }
          throw new Error(responseError);
        }

        setIsLoading(false);
        return { data, error: null };
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));

        const isAuthError =
          lastError.message?.includes('Unauthorized') ||
          lastError.message?.includes('403') ||
          lastError.message?.includes('session') ||
          lastError.message?.includes('verify user') ||
          lastError.message?.includes('log in again') ||
          lastError.message?.includes('Redirecting to login');

        if (isAuthError && attempt < maxRetries) {
          continue;
        }
      }
    }

    // If we exhausted retries and this still looks like an auth error, redirect to login
    if (
      lastError?.message?.includes('Unauthorized') ||
      lastError?.message?.includes('403') ||
      lastError?.message?.includes('session') ||
      lastError?.message?.includes('verify user')
    ) {
      try {
        await supabase.auth.signOut();
      } catch {
        // ignore
      }
      redirectToAuth();
      lastError = new Error('Your session expired. Redirecting to login...');
    }

    setIsLoading(false);
    return { data: null, error: lastError };
  }, []);

  return { invoke, isLoading };
}
