import { useState, useEffect, useMemo } from 'react';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, isSameMonth, isSameDay, isToday } from 'date-fns';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, MapPin, CheckCircle2, AlertCircle, Circle, Loader2, GripVertical, Plus, Clock } from 'lucide-react';
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, useDraggable, useDroppable, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useCalendarSettings } from '@/hooks/useCalendarSettings';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { CreateCalendarTaskDialog } from './CreateCalendarTaskDialog';
import type { Database } from '@/integrations/supabase/types';

type Task = Database['public']['Tables']['tasks']['Row'] & {
  property?: { address: string; city: string } | null;
  contractor?: { company_name: string } | null;
  assigned_to_profile?: { full_name: string } | null;
};

type Appointment = Database['public']['Tables']['appointments']['Row'] & {
  property?: { address: string; city: string } | null;
};

type TaskStatus = Database['public']['Enums']['task_status'];

const statusConfig: Record<TaskStatus, { icon: typeof Circle; color: string; label: string }> = {
  pending: { icon: Circle, color: 'text-muted-foreground', label: 'Pending' },
  in_progress: { icon: AlertCircle, color: 'text-blue-500', label: 'In Progress' },
  completed: { icon: CheckCircle2, color: 'text-green-500', label: 'Completed' },
  blocked: { icon: AlertCircle, color: 'text-destructive', label: 'Blocked' },
};

// Draggable task item component
function DraggableTaskItem({ task }: { task: Task }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: task.id,
    data: { task },
  });

  const config = statusConfig[task.status];
  const StatusIcon = config.icon;

  return (
    <div
      ref={setNodeRef}
      className={cn(
        "p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-grab active:cursor-grabbing",
        isDragging && "opacity-50"
      )}
    >
      <div className="flex items-start gap-2">
        <div {...attributes} {...listeners} className="mt-0.5 cursor-grab">
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </div>
        <StatusIcon className={cn("h-4 w-4 mt-0.5 shrink-0", config.color)} />
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">{task.title}</p>
          {task.description && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
              {task.description}
            </p>
          )}
          <div className="flex flex-wrap items-center gap-2 mt-2">
            <Badge variant="outline" className="text-xs">
              {config.label}
            </Badge>
            <Badge variant="secondary" className="text-xs capitalize">
              {task.phase}
            </Badge>
          </div>
          {task.property && (
            <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span className="truncate">
                {task.property.address}, {task.property.city}
              </span>
            </div>
          )}
          {(task.assigned_to_profile || task.contractor) && (
            <p className="text-xs text-muted-foreground mt-1">
              Assigned: {task.assigned_to_profile?.full_name || task.contractor?.company_name}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// Droppable calendar day cell
function DroppableCalendarDay({ 
  date, 
  taskCount,
  appointmentCount,
  isSelected, 
  isCurrentMonth,
  onClick,
  onDoubleClick
}: { 
  date: Date; 
  taskCount: number;
  appointmentCount: number;
  isSelected: boolean;
  isCurrentMonth: boolean;
  onClick: () => void;
  onDoubleClick: () => void;
}) {
  const dateId = format(date, 'yyyy-MM-dd');
  const { isOver, setNodeRef } = useDroppable({ id: dateId });

  return (
    <div
      ref={setNodeRef}
      onClick={onClick}
      onDoubleClick={onDoubleClick}
      className={cn(
        "h-16 md:h-20 p-1 border rounded-md cursor-pointer transition-all flex flex-col",
        isCurrentMonth ? "bg-card" : "bg-muted/30 text-muted-foreground",
        isSelected && "ring-2 ring-primary",
        isToday(date) && "border-primary",
        isOver && "bg-primary/20 ring-2 ring-primary ring-dashed"
      )}
    >
      <span className={cn(
        "text-sm font-medium",
        isToday(date) && "text-primary"
      )}>
        {date.getDate()}
      </span>
      {(taskCount > 0 || appointmentCount > 0) && (
        <div className="flex-1 flex items-end gap-1">
          {taskCount > 0 && (
            <div className="flex gap-0.5 flex-wrap">
              {taskCount <= 3 ? (
                Array.from({ length: taskCount }).map((_, i) => (
                  <div key={i} className="h-1.5 w-1.5 rounded-full bg-primary" />
                ))
              ) : (
                <span className="text-[10px] text-primary font-medium bg-primary/10 px-1 rounded">
                  {taskCount}
                </span>
              )}
            </div>
          )}
          {appointmentCount > 0 && (
            <div className="flex gap-0.5 flex-wrap">
              {appointmentCount <= 2 ? (
                Array.from({ length: appointmentCount }).map((_, i) => (
                  <div key={i} className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                ))
              ) : (
                <span className="text-[10px] text-amber-600 font-medium bg-amber-100 px-1 rounded">
                  {appointmentCount}
                </span>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Appointment item component
function AppointmentItem({ appointment }: { appointment: Appointment }) {
  return (
    <div className="p-3 rounded-lg border bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
      <div className="flex items-start gap-2">
        <Clock className="h-4 w-4 mt-0.5 shrink-0 text-amber-600" />
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">{appointment.title}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {format(parseISO(appointment.start_time), 'h:mm a')} - {format(parseISO(appointment.end_time), 'h:mm a')}
          </p>
          {appointment.description && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
              {appointment.description}
            </p>
          )}
          {appointment.location && (
            <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span className="truncate">{appointment.location}</span>
            </div>
          )}
          {appointment.property && (
            <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span className="truncate">
                {appointment.property.address}, {appointment.property.city}
              </span>
            </div>
          )}
          <Badge variant="outline" className="mt-2 text-xs bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-300">
            Appointment
          </Badge>
        </div>
      </div>
    </div>
  );
}

// Drag overlay task preview
function TaskDragOverlay({ task }: { task: Task }) {
  const config = statusConfig[task.status];
  return (
    <div className="p-2 rounded-lg border bg-card shadow-lg max-w-[200px]">
      <p className="font-medium text-sm truncate">{task.title}</p>
      <Badge variant="outline" className="text-xs mt-1">
        {config.label}
      </Badge>
    </div>
  );
}

export function TaskCalendar() {
  const { settings } = useCalendarSettings();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [createDialogDate, setCreateDialogDate] = useState<Date>(new Date());

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 8 },
    })
  );

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([fetchTasks(), fetchAppointments()]);
    setLoading(false);
  };

  const fetchTasks = async () => {
    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        property:properties(address, city),
        contractor:contractors(company_name),
        assigned_to_profile:profiles!tasks_assigned_to_fkey(full_name)
      `)
      .not('due_date', 'is', null)
      .order('due_date', { ascending: true });

    if (!error && data) {
      setTasks(data as Task[]);
    }
  };

  const fetchAppointments = async () => {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        *,
        property:properties(address, city)
      `)
      .order('start_time', { ascending: true });

    if (!error && data) {
      setAppointments(data as Appointment[]);
    }
  };

  const tasksByDate = useMemo(() => {
    const map = new Map<string, Task[]>();
    tasks.forEach(task => {
      if (task.due_date) {
        const dateKey = format(parseISO(task.due_date), 'yyyy-MM-dd');
        const existing = map.get(dateKey) || [];
        map.set(dateKey, [...existing, task]);
      }
    });
    return map;
  }, [tasks]);

  const tasksForSelectedDate = useMemo(() => {
    const dateKey = format(selectedDate, 'yyyy-MM-dd');
    return tasksByDate.get(dateKey) || [];
  }, [selectedDate, tasksByDate]);

  const appointmentsByDate = useMemo(() => {
    const map = new Map<string, Appointment[]>();
    appointments.forEach(apt => {
      const dateKey = format(parseISO(apt.start_time), 'yyyy-MM-dd');
      const existing = map.get(dateKey) || [];
      map.set(dateKey, [...existing, apt]);
    });
    return map;
  }, [appointments]);

  const appointmentsForSelectedDate = useMemo(() => {
    const dateKey = format(selectedDate, 'yyyy-MM-dd');
    return appointmentsByDate.get(dateKey) || [];
  }, [selectedDate, appointmentsByDate]);

  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const calStart = startOfWeek(monthStart, { weekStartsOn: settings.weekStartsOn });
    const calEnd = endOfWeek(monthEnd, { weekStartsOn: settings.weekStartsOn });
    return eachDayOfInterval({ start: calStart, end: calEnd });
  }, [currentMonth, settings.weekStartsOn]);

  const weekDays = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const reordered = [...days.slice(settings.weekStartsOn), ...days.slice(0, settings.weekStartsOn)];
    return reordered;
  }, [settings.weekStartsOn]);

  const handlePrevMonth = () => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentMonth(today);
    setSelectedDate(today);
  };

  const getTaskCountForDate = (date: Date) => {
    const dateKey = format(date, 'yyyy-MM-dd');
    return tasksByDate.get(dateKey)?.length || 0;
  };

  const getAppointmentCountForDate = (date: Date) => {
    const dateKey = format(date, 'yyyy-MM-dd');
    return appointmentsByDate.get(dateKey)?.length || 0;
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const task = tasks.find(t => t.id === active.id);
    if (task) setActiveTask(task);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const taskId = active.id as string;
    const newDate = over.id as string;
    const task = tasks.find(t => t.id === taskId);

    if (!task || task.due_date === newDate) return;

    // Optimistic update
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, due_date: newDate } : t
    ));

    const { error } = await supabase
      .from('tasks')
      .update({ due_date: newDate })
      .eq('id', taskId);

    if (error) {
      // Revert on error
      setTasks(prev => prev.map(t => 
        t.id === taskId ? { ...t, due_date: task.due_date } : t
      ));
      toast({
        title: "Failed to reschedule task",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Task rescheduled",
        description: `"${task.title}" moved to ${format(parseISO(newDate), 'MMM d, yyyy')}`,
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Task Calendar
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleToday}>
                Today
              </Button>
              <Button variant="outline" size="icon" onClick={handlePrevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="min-w-[140px] text-center font-medium">
                {format(currentMonth, 'MMMM yyyy')}
              </span>
              <Button variant="outline" size="icon" onClick={handleNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Week header */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {weekDays.map(day => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
            </div>
            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map(date => (
                <DroppableCalendarDay
                  key={date.toISOString()}
                  date={date}
                  taskCount={getTaskCountForDate(date)}
                  appointmentCount={getAppointmentCountForDate(date)}
                  isSelected={isSameDay(date, selectedDate)}
                  isCurrentMonth={isSameMonth(date, currentMonth)}
                  onClick={() => setSelectedDate(date)}
                  onDoubleClick={() => {
                    setCreateDialogDate(date);
                    setCreateDialogOpen(true);
                  }}
                />
              ))}
            </div>
            <div className="flex items-center gap-4 mt-4 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span>Tasks</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-2 w-2 rounded-full bg-amber-500" />
                <span>Appointments</span>
              </div>
              <span className="ml-auto">Double-click to create task • Drag to reschedule</span>
            </div>
          </CardContent>
        </Card>

        {/* Tasks and Appointments for selected date */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              {format(selectedDate, 'EEEE, MMMM d, yyyy')}
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {tasksForSelectedDate.length} task{tasksForSelectedDate.length !== 1 ? 's' : ''}, {appointmentsForSelectedDate.length} appointment{appointmentsForSelectedDate.length !== 1 ? 's' : ''}
            </p>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] pr-4">
              {tasksForSelectedDate.length === 0 && appointmentsForSelectedDate.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                  <CalendarIcon className="h-8 w-8 mb-2 opacity-50" />
                  <p className="text-sm">No tasks or appointments</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 gap-1"
                    onClick={() => {
                      setCreateDialogDate(selectedDate);
                      setCreateDialogOpen(true);
                    }}
                  >
                    <Plus className="h-4 w-4" />
                    Add Task
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {appointmentsForSelectedDate.map(apt => (
                    <AppointmentItem key={apt.id} appointment={apt} />
                  ))}
                  {tasksForSelectedDate.map(task => (
                    <DraggableTaskItem key={task.id} task={task} />
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Drag overlay */}
      <DragOverlay>
        {activeTask && <TaskDragOverlay task={activeTask} />}
      </DragOverlay>

      {/* Create task dialog */}
      <CreateCalendarTaskDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        defaultDate={createDialogDate}
        onTaskCreated={fetchTasks}
      />
    </DndContext>
  );
}
