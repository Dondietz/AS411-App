import { Calendar, Building2, GripVertical } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { Task } from '@/types/database';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';

interface TaskCardProps {
  task: Task;
  onClick?: () => void;
  isDragging?: boolean;
}

export function TaskCard({ task, onClick, isDragging: isDraggingProp }: TaskCardProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: task.id,
  });

  const style = transform ? {
    transform: CSS.Translate.toString(transform),
  } : undefined;

  const priorityColors = {
    1: 'border-l-muted-foreground',
    2: 'border-l-info',
    3: 'border-l-warning',
    4: 'border-l-destructive',
  };

  const isBeingDragged = isDragging || isDraggingProp;

  return (
    <Card 
      ref={setNodeRef}
      style={style}
      className={cn(
        'cursor-grab card-hover border-l-4 touch-none',
        priorityColors[task.priority as keyof typeof priorityColors] || priorityColors[1],
        isBeingDragged && 'opacity-50 shadow-lg rotate-2 scale-105 cursor-grabbing'
      )}
      onClick={onClick}
      {...attributes}
      {...listeners}
    >
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <h4 className="font-medium text-sm text-foreground leading-tight">{task.title}</h4>
          <GripVertical className="h-4 w-4 text-muted-foreground/50 shrink-0" />
        </div>

        {task.description && (
          <p className="text-xs text-muted-foreground line-clamp-2">{task.description}</p>
        )}

        <div className="flex items-center gap-3 flex-wrap text-xs text-muted-foreground">
          {task.due_date && (
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>{format(new Date(task.due_date), 'MMM d')}</span>
            </div>
          )}
          {task.property && (
            <div className="flex items-center gap-1">
              <Building2 className="h-3 w-3" />
              <span className="truncate max-w-[100px]">{task.property.address}</span>
            </div>
          )}
        </div>

        {(task.assignee || task.contractor) && (
          <div className="flex items-center gap-2 pt-2 border-t">
            <Avatar className="h-6 w-6">
              <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                {(task.assignee?.full_name || task.contractor?.company_name || 'U')
                  .split(' ')
                  .map(n => n[0])
                  .join('')
                  .slice(0, 2)}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground truncate">
              {task.assignee?.full_name || task.contractor?.company_name}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
