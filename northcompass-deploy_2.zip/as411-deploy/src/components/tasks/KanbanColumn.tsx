import { cn } from '@/lib/utils';
import { TaskCard } from './TaskCard';
import type { Task, TaskStatus } from '@/types/database';
import { useDroppable } from '@dnd-kit/core';

interface KanbanColumnProps {
  title: string;
  status: TaskStatus;
  tasks: Task[];
  onTaskClick?: (task: Task) => void;
  className?: string;
}

const columnColors: Record<TaskStatus, string> = {
  pending: 'border-t-muted-foreground',
  in_progress: 'border-t-info',
  completed: 'border-t-success',
  blocked: 'border-t-destructive',
};

export function KanbanColumn({ title, status, tasks, onTaskClick, className }: KanbanColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: status,
  });

  return (
    <div 
      ref={setNodeRef}
      className={cn(
        'kanban-column border-t-4 transition-colors duration-200',
        columnColors[status],
        isOver && 'bg-primary/5 ring-2 ring-primary/20',
        className
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">{title}</h3>
        <span className="flex items-center justify-center h-6 w-6 rounded-full bg-muted text-muted-foreground text-xs font-medium">
          {tasks.length}
        </span>
      </div>
      <div className="space-y-3 min-h-[100px]">
        {tasks.map((task) => (
          <TaskCard 
            key={task.id} 
            task={task} 
            onClick={() => onTaskClick?.(task)}
          />
        ))}
        {tasks.length === 0 && (
          <div className={cn(
            "text-center py-8 text-muted-foreground text-sm border-2 border-dashed rounded-lg transition-colors",
            isOver && "border-primary/40 bg-primary/5"
          )}>
            {isOver ? 'Drop here' : 'No tasks'}
          </div>
        )}
      </div>
    </div>
  );
}
