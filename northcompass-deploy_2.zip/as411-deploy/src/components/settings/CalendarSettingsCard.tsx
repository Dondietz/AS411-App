import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar, RotateCcw } from 'lucide-react';
import {
  useCalendarSettings,
  COMMON_TIMEZONES,
  WEEK_START_OPTIONS,
  type CalendarSettings,
} from '@/hooks/useCalendarSettings';
import { useToast } from '@/hooks/use-toast';

export function CalendarSettingsCard() {
  const { settings, updateSettings, resetSettings } = useCalendarSettings();
  const { toast } = useToast();

  const handleTimezoneChange = (timezone: string) => {
    updateSettings({ timezone });
    toast({ title: 'Settings saved', description: `Timezone set to ${timezone}` });
  };

  const handleWeekStartChange = (value: string) => {
    updateSettings({ weekStartsOn: parseInt(value) as CalendarSettings['weekStartsOn'] });
    toast({ title: 'Settings saved', description: `Week starts on ${WEEK_START_OPTIONS.find(o => o.value === parseInt(value))?.label}` });
  };

  const handleReset = () => {
    resetSettings();
    toast({ title: 'Settings reset', description: 'Calendar settings restored to defaults' });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Calendar Settings
        </CardTitle>
        <CardDescription>
          Configure how dates and calendars are displayed throughout the app
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="timezone">Timezone</Label>
          <Select value={settings.timezone} onValueChange={handleTimezoneChange}>
            <SelectTrigger id="timezone">
              <SelectValue placeholder="Select timezone" />
            </SelectTrigger>
            <SelectContent>
              {COMMON_TIMEZONES.map(tz => (
                <SelectItem key={tz} value={tz}>
                  {tz.replace(/_/g, ' ')}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Times will be displayed in this timezone
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="week-start">First day of week</Label>
          <Select
            value={settings.weekStartsOn.toString()}
            onValueChange={handleWeekStartChange}
          >
            <SelectTrigger id="week-start">
              <SelectValue placeholder="Select first day" />
            </SelectTrigger>
            <SelectContent>
              {WEEK_START_OPTIONS.map(option => (
                <SelectItem key={option.value} value={option.value.toString()}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Calendar weeks will start on this day
          </p>
        </div>

        <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
          <RotateCcw className="h-4 w-4" />
          Reset to Defaults
        </Button>
      </CardContent>
    </Card>
  );
}
