import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  FileText, 
  Image, 
  FileSpreadsheet, 
  File, 
  Download, 
  Trash2, 
  MoreVertical,
  Tag,
  Eye,
} from 'lucide-react';
import { format } from 'date-fns';

interface FileRecord {
  id: string;
  file_name: string;
  file_url: string;
  file_type: string | null;
  file_size: number | null;
  category: string | null;
  created_at: string;
  property_id: string;
}

interface FileCardProps {
  file: FileRecord;
  onDelete: (id: string) => void;
  onCategoryChange: (id: string, category: string) => void;
}

const FILE_CATEGORIES = [
  { value: 'document', label: 'Document' },
  { value: 'photo', label: 'Photo' },
  { value: 'contract', label: 'Contract' },
  { value: 'invoice', label: 'Invoice' },
  { value: 'report', label: 'Report' },
  { value: 'other', label: 'Other' },
];

function getFileIcon(fileType: string | null) {
  if (!fileType) return <File className="h-8 w-8" />;
  
  if (fileType.startsWith('image/')) {
    return <Image className="h-8 w-8 text-green-500" />;
  }
  if (fileType.includes('pdf')) {
    return <FileText className="h-8 w-8 text-red-500" />;
  }
  if (fileType.includes('spreadsheet') || fileType.includes('excel') || fileType.includes('csv')) {
    return <FileSpreadsheet className="h-8 w-8 text-emerald-500" />;
  }
  if (fileType.includes('document') || fileType.includes('word')) {
    return <FileText className="h-8 w-8 text-blue-500" />;
  }
  return <File className="h-8 w-8 text-muted-foreground" />;
}

function formatFileSize(bytes: number | null) {
  if (!bytes) return 'Unknown size';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function FileCard({ file, onDelete, onCategoryChange }: FileCardProps) {
  const { toast } = useToast();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      // Extract file path from URL
      const urlParts = file.file_url.split('/property-files/');
      const filePath = urlParts[1];
      
      if (filePath) {
        const { data, error } = await supabase.storage
          .from('property-files')
          .download(filePath);
        
        if (error) throw error;
        
        // Create download link
        const url = URL.createObjectURL(data);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.file_name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({ title: 'File downloaded' });
      }
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: 'Download failed',
        description: 'Could not download the file',
        variant: 'destructive',
      });
    } finally {
      setDownloading(false);
    }
  };

  const handlePreview = async () => {
    try {
      const urlParts = file.file_url.split('/property-files/');
      const filePath = urlParts[1];
      
      if (filePath) {
        const { data } = await supabase.storage
          .from('property-files')
          .createSignedUrl(filePath, 3600);
        
        if (data?.signedUrl) {
          window.open(data.signedUrl, '_blank');
        }
      }
    } catch (error) {
      console.error('Preview error:', error);
      toast({
        title: 'Preview failed',
        description: 'Could not open the file',
        variant: 'destructive',
      });
    }
  };

  const handleDelete = async () => {
    try {
      const urlParts = file.file_url.split('/property-files/');
      const filePath = urlParts[1];
      
      if (filePath) {
        await supabase.storage.from('property-files').remove([filePath]);
      }
      
      const { error } = await supabase.from('files').delete().eq('id', file.id);
      
      if (error) throw error;
      
      onDelete(file.id);
      toast({ title: 'File deleted' });
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: 'Delete failed',
        description: 'Could not delete the file',
        variant: 'destructive',
      });
    } finally {
      setDeleteDialogOpen(false);
    }
  };

  return (
    <>
      <Card className="group hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 p-2 bg-muted rounded-lg">
              {getFileIcon(file.file_type)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate" title={file.file_name}>
                {file.file_name}
              </p>
              <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                <span>{formatFileSize(file.file_size)}</span>
                <span>•</span>
                <span>{format(new Date(file.created_at), 'MMM d, yyyy')}</span>
              </div>
              {file.category && (
                <Badge variant="secondary" className="mt-2 text-xs">
                  <Tag className="h-3 w-3 mr-1" />
                  {FILE_CATEGORIES.find(c => c.value === file.category)?.label || file.category}
                </Badge>
              )}
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handlePreview}>
                  <Eye className="h-4 w-4 mr-2" />
                  Preview
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleDownload} disabled={downloading}>
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-muted-foreground text-xs" disabled>
                  Category
                </DropdownMenuItem>
                {FILE_CATEGORIES.map((cat) => (
                  <DropdownMenuItem 
                    key={cat.value}
                    onClick={() => onCategoryChange(file.id, cat.value)}
                    className={file.category === cat.value ? 'bg-accent' : ''}
                  >
                    <Tag className="h-4 w-4 mr-2" />
                    {cat.label}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => setDeleteDialogOpen(true)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete file?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete "{file.file_name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
