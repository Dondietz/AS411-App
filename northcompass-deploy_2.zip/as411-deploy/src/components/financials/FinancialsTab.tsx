import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { CostSummary } from './CostSummary';
import { CostsTable } from './CostsTable';
import { CostDialog } from './CostDialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { exportDeferredCostsInvoice } from '@/lib/exportDeferredInvoice';
import { DollarSign, FileSpreadsheet, Filter } from 'lucide-react';
import type { Database } from '@/integrations/supabase/types';

type Cost = Database['public']['Tables']['costs']['Row'] & {
  contractor?: { company_name: string } | null;
};

type Contractor = Database['public']['Tables']['contractors']['Row'];

interface FinancialsTabProps {
  propertyId: string;
  propertyAddress: string;
  propertyCity?: string;
  propertyState?: string;
  propertyZipCode?: string | null;
  salePrice?: number;
  clientName?: string;
  clientEmail?: string | null;
  clientPhone?: string | null;
}

export function FinancialsTab({
  propertyId,
  propertyAddress,
  propertyCity,
  propertyState,
  propertyZipCode,
  salePrice,
  clientName,
  clientEmail,
  clientPhone,
}: FinancialsTabProps) {
  const [costs, setCosts] = useState<Cost[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterContractor, setFilterContractor] = useState<string>('all');
  const { toast } = useToast();

  const fetchCosts = useCallback(async () => {
    const { data } = await supabase
      .from('costs')
      .select('*, contractor:contractors(company_name)')
      .eq('property_id', propertyId)
      .order('created_at', { ascending: false });
    if (data) setCosts(data as Cost[]);
    setLoading(false);
  }, [propertyId]);

  const fetchContractors = useCallback(async () => {
    const { data } = await supabase.from('contractors').select('*').eq('is_active', true);
    if (data) setContractors(data);
  }, []);

  useEffect(() => {
    fetchCosts();
    fetchContractors();

    const channel = supabase
      .channel(`costs-${propertyId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'costs', filter: `property_id=eq.${propertyId}` }, fetchCosts)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [propertyId, fetchCosts, fetchContractors]);

  const filteredCosts = costs.filter(cost => {
    if (filterStatus !== 'all' && cost.cost_type !== filterStatus) return false;
    if (filterCategory !== 'all' && cost.category !== filterCategory) return false;
    if (filterContractor !== 'all' && cost.contractor_id !== filterContractor) return false;
    return true;
  });

  const categories = [...new Set(costs.map(c => c.category).filter(Boolean))];
  const deferredCostItems = costs.filter(cost => cost.cost_type === 'deferred');

  const estimatedCosts = costs.filter(c => c.cost_type === 'estimated').reduce((sum, c) => sum + Number(c.amount), 0);
  const paidCosts = costs.filter(c => c.cost_type === 'paid').reduce((sum, c) => sum + Number(c.amount), 0);
  const deferredCosts = deferredCostItems.reduce((sum, c) => sum + Number(c.amount), 0);

  const handleExportDeferredInvoice = async () => {
    if (deferredCostItems.length === 0) {
      toast({
        title: 'No deferred costs',
        description: 'Add at least one deferred cost before exporting an invoice.',
      });
      return;
    }

    try {
      setExporting(true);
      await exportDeferredCostsInvoice({
        property: {
          id: propertyId,
          address: propertyAddress,
          city: propertyCity,
          state: propertyState,
          zipCode: propertyZipCode ?? undefined,
          salePrice,
          clientName,
          clientEmail,
          clientPhone,
        },
        costs: deferredCostItems.map(cost => ({
          description: cost.description,
          category: cost.category,
          contractorName: cost.contractor?.company_name,
          invoiceNumber: cost.invoice_number,
          amount: Number(cost.amount),
          createdAt: cost.created_at,
          notes: cost.notes,
        })),
      });

      toast({
        title: 'Invoice exported',
        description: 'Deferred cost invoice downloaded from your Excel template.',
      });
    } catch (error) {
      toast({
        title: 'Export failed',
        description: error instanceof Error ? error.message : 'Could not generate the Excel invoice.',
        variant: 'destructive',
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="max-w-md">
        <CostSummary
          estimatedCosts={estimatedCosts}
          paidCosts={paidCosts}
          deferredCosts={deferredCosts}
          salePrice={salePrice}
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-primary" />
              Cost Details
            </CardTitle>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="estimated">Estimated</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="deferred">Deferred</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat!}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterContractor} onValueChange={setFilterContractor}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Contractor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Contractors</SelectItem>
                    {contractors.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button variant="outline" onClick={handleExportDeferredInvoice} disabled={deferredCostItems.length === 0 || exporting}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                {exporting ? 'Exporting…' : 'Export Deferred Invoice'}
              </Button>
              <CostDialog propertyId={propertyId} onSuccess={fetchCosts} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-8 text-center text-muted-foreground">Loading...</div>
          ) : (
            <CostsTable costs={filteredCosts} propertyId={propertyId} onRefresh={fetchCosts} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
