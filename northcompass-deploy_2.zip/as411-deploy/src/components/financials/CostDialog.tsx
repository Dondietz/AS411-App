import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Loader2 } from 'lucide-react';
import type { Database } from '@/integrations/supabase/types';

type CostType = Database['public']['Enums']['cost_type'];
type Cost = Database['public']['Tables']['costs']['Row'];
type Contractor = Database['public']['Tables']['contractors']['Row'];

const COST_CATEGORIES = [
  'Cleanout',
  'Repairs',
  'Landscaping',
  'Legal',
  'Marketing',
  'Staging',
  'Utilities',
  'Insurance',
  'Permits',
  'Other'
];

interface CostDialogProps {
  propertyId: string;
  cost?: Cost | null;
  onSuccess: () => void;
  trigger?: React.ReactNode;
}

export function CostDialog({ propertyId, cost, onSuccess, trigger }: CostDialogProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    cost_type: 'estimated' as CostType,
    category: '',
    contractor_id: '',
    invoice_number: '',
    paid_date: '',
    notes: ''
  });

  useEffect(() => {
    if (open) {
      supabase.from('contractors').select('*').eq('is_active', true).then(({ data }) => {
        if (data) setContractors(data);
      });
    }
  }, [open]);

  useEffect(() => {
    if (cost) {
      setFormData({
        description: cost.description,
        amount: String(cost.amount),
        cost_type: cost.cost_type,
        category: cost.category || '',
        contractor_id: cost.contractor_id || '',
        invoice_number: cost.invoice_number || '',
        paid_date: cost.paid_date || '',
        notes: cost.notes || ''
      });
    } else {
      setFormData({
        description: '',
        amount: '',
        cost_type: 'estimated',
        category: '',
        contractor_id: '',
        invoice_number: '',
        paid_date: '',
        notes: ''
      });
    }
  }, [cost, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description.trim() || !formData.amount) {
      toast({ title: 'Error', description: 'Description and amount are required', variant: 'destructive' });
      return;
    }

    setLoading(true);
    const payload = {
      property_id: propertyId,
      description: formData.description.trim(),
      amount: parseFloat(formData.amount),
      cost_type: formData.cost_type,
      category: formData.category || null,
      contractor_id: formData.contractor_id || null,
      invoice_number: formData.invoice_number || null,
      paid_date: formData.paid_date || null,
      notes: formData.notes || null
    };

    const { error } = cost
      ? await supabase.from('costs').update(payload).eq('id', cost.id)
      : await supabase.from('costs').insert(payload);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: cost ? 'Cost updated' : 'Cost added' });
      setOpen(false);
      onSuccess();
    }
    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button size="sm">
            <Plus className="h-4 w-4 mr-1" /> Add Cost
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{cost ? 'Edit Cost' : 'Add Cost'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2 space-y-2">
              <Label>Description *</Label>
              <Input
                value={formData.description}
                onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="e.g., Kitchen renovation"
              />
            </div>

            <div className="space-y-2">
              <Label>Amount *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={e => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={formData.cost_type}
                onValueChange={v => setFormData(prev => ({ ...prev, cost_type: v as CostType }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="estimated">Estimated</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="deferred">Deferred</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={formData.category}
                onValueChange={v => setFormData(prev => ({ ...prev, category: v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {COST_CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Contractor</Label>
              <Select
                value={formData.contractor_id}
                onValueChange={v => setFormData(prev => ({ ...prev, contractor_id: v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select contractor" />
                </SelectTrigger>
                <SelectContent>
                  {contractors.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Invoice Number</Label>
              <Input
                value={formData.invoice_number}
                onChange={e => setFormData(prev => ({ ...prev, invoice_number: e.target.value }))}
                placeholder="INV-001"
              />
            </div>

            <div className="space-y-2">
              <Label>Paid Date</Label>
              <Input
                type="date"
                value={formData.paid_date}
                onChange={e => setFormData(prev => ({ ...prev, paid_date: e.target.value }))}
              />
            </div>

            <div className="col-span-2 space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Additional details..."
                rows={2}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              {cost ? 'Update' : 'Add'} Cost
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
