import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { DollarSign, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CostSummaryProps {
  estimatedCosts: number;
  paidCosts: number;
  deferredCosts: number;
  salePrice?: number;
}

export function CostSummary({ estimatedCosts, paidCosts, deferredCosts, salePrice }: CostSummaryProps) {
  const totalCosts = paidCosts + deferredCosts;
  const paidPercentage = totalCosts > 0 ? (paidCosts / totalCosts) * 100 : 0;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const estimatedProfit = salePrice ? salePrice - totalCosts : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <DollarSign className="h-5 w-5 text-primary" />
          Financial Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <TrendingUp className="h-3 w-3" /> Estimated
            </p>
            <p className="text-xl font-bold text-foreground">{formatCurrency(estimatedCosts)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <CheckCircle className="h-3 w-3" /> Paid
            </p>
            <p className="text-xl font-bold text-success">{formatCurrency(paidCosts)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" /> Deferred
            </p>
            <p className="text-xl font-bold text-warning">{formatCurrency(deferredCosts)}</p>
          </div>
          {salePrice && (
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Sale Price</p>
              <p className="text-xl font-bold text-primary">{formatCurrency(salePrice)}</p>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Payment Progress</span>
            <span className="font-medium">{Math.round(paidPercentage)}% paid</span>
          </div>
          <Progress value={paidPercentage} className="h-2" />
        </div>

        {estimatedProfit !== null && (
          <div className={cn(
            'rounded-lg p-4 text-center',
            estimatedProfit >= 0 ? 'bg-success/10' : 'bg-destructive/10'
          )}>
            <p className="text-sm text-muted-foreground mb-1">Estimated Net</p>
            <p className={cn(
              'text-2xl font-bold',
              estimatedProfit >= 0 ? 'text-success' : 'text-destructive'
            )}>
              {formatCurrency(estimatedProfit)}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
