import { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { CostDialog } from './CostDialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Pencil, Trash2, Building2 } from 'lucide-react';
import { format } from 'date-fns';
import type { Database } from '@/integrations/supabase/types';

type Cost = Database['public']['Tables']['costs']['Row'] & {
  contractor?: { company_name: string } | null;
};

interface CostsTableProps {
  costs: Cost[];
  propertyId: string;
  onRefresh: () => void;
}

export function CostsTable({ costs, propertyId, onRefresh }: CostsTableProps) {
  const [editingCost, setEditingCost] = useState<Cost | null>(null);
  const { toast } = useToast();

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('costs').delete().eq('id', id);
    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Cost deleted' });
      onRefresh();
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (type: string) => {
    switch (type) {
      case 'paid':
        return <Badge variant="default" className="bg-success text-success-foreground">Paid</Badge>;
      case 'deferred':
        return <Badge variant="secondary" className="bg-warning/20 text-warning-foreground">Deferred</Badge>;
      default:
        return <Badge variant="outline">Estimated</Badge>;
    }
  };

  if (costs.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p>No costs recorded yet.</p>
      </div>
    );
  }

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Description</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Contractor</TableHead>
            <TableHead>Invoice</TableHead>
            <TableHead className="text-right">Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Paid Date</TableHead>
            <TableHead className="w-20"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {costs.map(cost => (
            <TableRow key={cost.id}>
              <TableCell className="font-medium">{cost.description}</TableCell>
              <TableCell>{cost.category || '—'}</TableCell>
              <TableCell>
                {cost.contractor ? (
                  <span className="flex items-center gap-1 text-sm">
                    <Building2 className="h-3 w-3" />
                    {cost.contractor.company_name}
                  </span>
                ) : '—'}
              </TableCell>
              <TableCell className="text-muted-foreground">{cost.invoice_number || '—'}</TableCell>
              <TableCell className="text-right font-medium">{formatCurrency(cost.amount)}</TableCell>
              <TableCell>{getStatusBadge(cost.cost_type)}</TableCell>
              <TableCell className="text-muted-foreground">
                {cost.paid_date ? format(new Date(cost.paid_date), 'MMM d, yyyy') : '—'}
              </TableCell>
              <TableCell>
                <div className="flex gap-1">
                  <CostDialog
                    propertyId={propertyId}
                    cost={cost}
                    onSuccess={onRefresh}
                    trigger={
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Pencil className="h-4 w-4" />
                      </Button>
                    }
                  />
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete cost?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently remove this cost entry.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(cost.id)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {editingCost && (
        <CostDialog
          propertyId={propertyId}
          cost={editingCost}
          onSuccess={() => {
            setEditingCost(null);
            onRefresh();
          }}
        />
      )}
    </>
  );
}
