import { MapPin, User, Calendar, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { StatusBadge } from '@/components/ui/status-badge';
import { Button } from '@/components/ui/button';
import type { PropertyWithDetails } from '@/types/database';
import { format } from 'date-fns';

interface PropertyCardProps {
  property: PropertyWithDetails;
}

export function PropertyCard({ property }: PropertyCardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Card className="card-hover overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary shrink-0" />
              <h3 className="font-semibold text-foreground truncate">{property.address}</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              {property.city}, {property.state} {property.zip_code}
            </p>
          </div>
          <StatusBadge status={property.status} type="property" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          {property.client && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span className="truncate">{property.client.full_name}</span>
            </div>
          )}
          {property.intake_date && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>{format(new Date(property.intake_date), 'MMM d, yyyy')}</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t pt-4">
          <div className="space-y-1">
            {property.pending_tasks_count !== undefined && (
              <p className="text-xs text-muted-foreground">
                {property.pending_tasks_count} pending task{property.pending_tasks_count !== 1 ? 's' : ''}
              </p>
            )}
            {property.deferred_costs !== undefined && property.deferred_costs > 0 && (
              <p className="text-xs font-medium text-warning">
                {formatCurrency(property.deferred_costs)} deferred
              </p>
            )}
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to={`/properties/${property.id}`}>
              View <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
