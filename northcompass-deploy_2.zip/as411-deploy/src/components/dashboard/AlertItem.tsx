import { AlertTriangle, Clock, CheckCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

type AlertType = 'warning' | 'urgent' | 'success' | 'info';

interface AlertItemProps {
  type: AlertType;
  title: string;
  description: string;
  timestamp?: string;
}

const alertConfig: Record<AlertType, { icon: typeof AlertTriangle; className: string }> = {
  warning: { icon: AlertTriangle, className: 'bg-warning/10 text-warning border-warning/20' },
  urgent: { icon: Clock, className: 'bg-destructive/10 text-destructive border-destructive/20' },
  success: { icon: CheckCircle, className: 'bg-success/10 text-success border-success/20' },
  info: { icon: Info, className: 'bg-info/10 text-info border-info/20' },
};

export function AlertItem({ type, title, description, timestamp }: AlertItemProps) {
  const config = alertConfig[type];
  const Icon = config.icon;

  return (
    <div className={cn(
      'flex items-start gap-3 rounded-lg border p-3 animate-slide-up',
      config.className
    )}>
      <Icon className="h-5 w-5 shrink-0 mt-0.5" />
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm">{title}</p>
        <p className="text-xs opacity-80 mt-0.5">{description}</p>
        {timestamp && (
          <p className="text-xs opacity-60 mt-1">{timestamp}</p>
        )}
      </div>
    </div>
  );
}
