import { useState } from 'react';
import { format } from 'date-fns';
import { Phone, MessageSquare, Users, Video, Mail, MoreHorizontal, ArrowUpRight, ArrowDownLeft, Pencil, Trash2 } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Communication {
  id: string;
  date: string;
  communication_type: string;
  direction: string | null;
  parties_involved: string | null;
  notes: string;
  created_by: string | null;
  creator?: {
    full_name: string;
  } | null;
}

const typeConfig: Record<string, { label: string; icon: React.ComponentType<{ className?: string }> }> = {
  phone_call: { label: 'Phone Call', icon: Phone },
  in_person: { label: 'Meeting', icon: Users },
  text_message: { label: 'Text', icon: MessageSquare },
  email: { label: 'Email', icon: Mail },
  video_call: { label: 'Video', icon: Video },
  other: { label: 'Other', icon: MoreHorizontal },
};

interface CommunicationLogTableProps {
  communications: Communication[];
  onEdit?: (communication: Communication) => void;
  onRefresh?: () => void;
}

export function CommunicationLogTable({ communications, onEdit, onRefresh }: CommunicationLogTableProps) {
  const { toast } = useToast();
  const [selectedComm, setSelectedComm] = useState<Communication | null>(null);
  const [deleteComm, setDeleteComm] = useState<Communication | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!deleteComm) return;
    setIsDeleting(true);

    const { error } = await supabase
      .from('communications')
      .delete()
      .eq('id', deleteComm.id);

    if (error) {
      toast({ title: 'Error', description: 'Could not delete communication', variant: 'destructive' });
    } else {
      toast({ title: 'Deleted', description: 'Communication entry removed' });
      setDeleteComm(null);
      setSelectedComm(null);
      onRefresh?.();
    }
    setIsDeleting(false);
  };

  if (communications.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>No communications logged yet</p>
        <p className="text-sm mt-1">Use the buttons above to log your first entry</p>
      </div>
    );
  }

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[140px]">Date</TableHead>
              <TableHead className="w-[120px]">Type</TableHead>
              <TableHead className="w-[200px]">Parties</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead className="w-[120px]">Logged By</TableHead>
              <TableHead className="w-[80px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {communications.map(comm => {
              const TypeIcon = typeConfig[comm.communication_type]?.icon || MoreHorizontal;
              const typeLabel = typeConfig[comm.communication_type]?.label || comm.communication_type;

              return (
                <TableRow
                  key={comm.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setSelectedComm(comm)}
                >
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span>{format(new Date(comm.date), 'MMM d, yyyy')}</span>
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(comm.date), 'h:mm a')}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <TypeIcon className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{typeLabel}</span>
                      {comm.direction && (
                        comm.direction === 'outbound' ? (
                          <ArrowUpRight className="h-3 w-3 text-blue-500" />
                        ) : (
                          <ArrowDownLeft className="h-3 w-3 text-green-500" />
                        )
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm line-clamp-2">
                      {comm.parties_involved || '—'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-muted-foreground line-clamp-2">
                      {comm.notes}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-muted-foreground">
                      {comm.creator?.full_name || '—'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => onEdit?.(comm)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => setDeleteComm(comm)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedComm} onOpenChange={() => setSelectedComm(null)}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Communication Details</DialogTitle>
          </DialogHeader>
          {selectedComm && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Date & Time</p>
                  <p>{format(new Date(selectedComm.date), 'MMMM d, yyyy · h:mm a')}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Type</p>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const TypeIcon = typeConfig[selectedComm.communication_type]?.icon || MoreHorizontal;
                      return <TypeIcon className="h-4 w-4" />;
                    })()}
                    <span>{typeConfig[selectedComm.communication_type]?.label || selectedComm.communication_type}</span>
                    {selectedComm.direction && (
                      <Badge variant="secondary" className="text-xs">
                        {selectedComm.direction}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              {selectedComm.parties_involved && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Parties Involved</p>
                  <p className="whitespace-pre-wrap">{selectedComm.parties_involved}</p>
                </div>
              )}

              <div>
                <p className="text-sm font-medium text-muted-foreground">Notes</p>
                <p className="whitespace-pre-wrap text-sm">{selectedComm.notes}</p>
              </div>

              <div className="pt-4 border-t text-xs text-muted-foreground">
                Logged by {selectedComm.creator?.full_name || 'Unknown'} on{' '}
                {format(new Date(selectedComm.date), 'MMMM d, yyyy')}
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedComm(null);
                    onEdit?.(selectedComm);
                  }}
                  className="gap-2"
                >
                  <Pencil className="h-4 w-4" /> Edit
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => {
                    setDeleteComm(selectedComm);
                  }}
                  className="gap-2"
                >
                  <Trash2 className="h-4 w-4" /> Delete
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteComm} onOpenChange={() => setDeleteComm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Communication Entry?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this communication log entry. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
