import { useState, useEffect } from 'react';
import { Phone, MessageSquare, Users, Plus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { LogCommunicationDialog } from './LogCommunicationDialog';
import { CommunicationLogTable } from './CommunicationLogTable';

interface Communication {
  id: string;
  date: string;
  communication_type: string;
  direction: string | null;
  parties_involved: string | null;
  notes: string;
  created_by: string | null;
  creator?: {
    full_name: string;
  } | null;
}

interface CommunicationsTabProps {
  propertyId: string;
}

export function CommunicationsTab({ propertyId }: CommunicationsTabProps) {
  const { toast } = useToast();
  const [communications, setCommunications] = useState<Communication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [preselectedType, setPreselectedType] = useState<string | undefined>();
  const [editingCommunication, setEditingCommunication] = useState<Communication | null>(null);

  const fetchCommunications = async () => {
    const { data, error } = await supabase
      .from('communications')
      .select('*, creator:profiles!communications_created_by_fkey(full_name)')
      .eq('property_id', propertyId)
      .order('date', { ascending: false });

    if (error) {
      toast({ title: 'Error', description: 'Could not load communications', variant: 'destructive' });
    } else {
      setCommunications(data || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchCommunications();

    // Realtime subscription
    const channel = supabase
      .channel(`communications-${propertyId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'communications',
        filter: `property_id=eq.${propertyId}`,
      }, () => {
        fetchCommunications();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [propertyId]);

  const openDialogWithType = (type?: string) => {
    setEditingCommunication(null);
    setPreselectedType(type);
    setDialogOpen(true);
  };

  const handleEdit = (communication: Communication) => {
    setPreselectedType(undefined);
    setEditingCommunication(communication);
    setDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold">Communication Log</h2>
          <p className="text-sm text-muted-foreground">
            Record all calls, texts, meetings, and updates related to this property.
          </p>
        </div>
        <Button onClick={() => openDialogWithType()} className="gap-2">
          <Plus className="h-4 w-4" /> Log Communication
        </Button>
      </div>

      {/* Quick Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => openDialogWithType('phone_call')}
          className="gap-2"
        >
          <Phone className="h-4 w-4" /> Log Call
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => openDialogWithType('text_message')}
          className="gap-2"
        >
          <MessageSquare className="h-4 w-4" /> Log Text
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => openDialogWithType('in_person')}
          className="gap-2"
        >
          <Users className="h-4 w-4" /> Log Meeting
        </Button>
      </div>

      {/* Communications Table */}
      <CommunicationLogTable
        communications={communications}
        onEdit={handleEdit}
        onRefresh={fetchCommunications}
      />

      {/* Log Communication Dialog */}
      <LogCommunicationDialog
        propertyId={propertyId}
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingCommunication(null);
        }}
        onCommunicationLogged={fetchCommunications}
        preselectedType={preselectedType}
        editingCommunication={editingCommunication}
      />
    </div>
  );
}
