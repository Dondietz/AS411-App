import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon, Loader2, Phone, MessageSquare, Users, Video, Mail, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { cn } from '@/lib/utils';

const communicationSchema = z.object({
  date: z.date(),
  time: z.string(),
  communication_type: z.enum(['phone_call', 'in_person', 'text_message', 'email', 'video_call', 'other']),
  direction: z.enum(['inbound', 'outbound']).optional(),
  parties_involved: z.string().max(500).optional(),
  notes: z.string().min(1, 'Notes are required').max(5000),
});

type CommunicationFormData = z.infer<typeof communicationSchema>;

const communicationTypes = [
  { value: 'phone_call', label: 'Phone Call', icon: Phone },
  { value: 'in_person', label: 'In-Person Meeting', icon: Users },
  { value: 'text_message', label: 'Text Message', icon: MessageSquare },
  { value: 'email', label: 'Email', icon: Mail },
  { value: 'video_call', label: 'Video Call', icon: Video },
  { value: 'other', label: 'Other', icon: MoreHorizontal },
];

interface Communication {
  id: string;
  date: string;
  communication_type: string;
  direction: string | null;
  parties_involved: string | null;
  notes: string;
}

interface LogCommunicationDialogProps {
  propertyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCommunicationLogged?: () => void;
  preselectedType?: string;
  editingCommunication?: Communication | null;
}

export function LogCommunicationDialog({
  propertyId,
  open,
  onOpenChange,
  onCommunicationLogged,
  preselectedType,
  editingCommunication,
}: LogCommunicationDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isEditing = !!editingCommunication;

  const now = new Date();
  const form = useForm<CommunicationFormData>({
    resolver: zodResolver(communicationSchema),
    defaultValues: {
      date: now,
      time: format(now, 'HH:mm'),
      communication_type: 'phone_call',
      direction: 'outbound',
      parties_involved: '',
      notes: '',
    },
  });

  // Reset form when dialog opens
  const handleOpenChange = (isOpen: boolean) => {
    if (isOpen) {
      if (editingCommunication) {
        const editDate = new Date(editingCommunication.date);
        form.reset({
          date: editDate,
          time: format(editDate, 'HH:mm'),
          communication_type: editingCommunication.communication_type as CommunicationFormData['communication_type'],
          direction: (editingCommunication.direction as CommunicationFormData['direction']) || 'outbound',
          parties_involved: editingCommunication.parties_involved || '',
          notes: editingCommunication.notes,
        });
      } else {
        const now = new Date();
        form.reset({
          date: now,
          time: format(now, 'HH:mm'),
          communication_type: (preselectedType as CommunicationFormData['communication_type']) || 'phone_call',
          direction: 'outbound',
          parties_involved: '',
          notes: '',
        });
      }
    }
    onOpenChange(isOpen);
  };

  const onSubmit = async (data: CommunicationFormData) => {
    if (!user) return;
    setIsSubmitting(true);

    // Combine date and time
    const [hours, minutes] = data.time.split(':').map(Number);
    const dateTime = new Date(data.date);
    dateTime.setHours(hours, minutes, 0, 0);

    const payload = {
      date: dateTime.toISOString(),
      communication_type: data.communication_type,
      direction: data.direction || null,
      parties_involved: data.parties_involved || null,
      notes: data.notes,
    };

    let error;
    if (isEditing && editingCommunication) {
      const result = await supabase
        .from('communications')
        .update(payload)
        .eq('id', editingCommunication.id);
      error = result.error;
    } else {
      const result = await supabase.from('communications').insert({
        ...payload,
        property_id: propertyId,
        created_by: user.id,
      });
      error = result.error;
    }

    if (error) {
      toast({ title: 'Error', description: `Could not ${isEditing ? 'update' : 'log'} communication`, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: `Communication ${isEditing ? 'updated' : 'logged'}` });
      handleOpenChange(false);
      onCommunicationLogged?.();
    }
    setIsSubmitting(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Communication' : 'Log Communication'}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              'w-full pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? format(field.value, 'MMM d, yyyy') : <span>Pick date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Communication Type */}
            <FormField
              control={form.control}
              name="communication_type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Communication Type *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {communicationTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center gap-2">
                            <type.icon className="h-4 w-4" />
                            {type.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Direction */}
            <FormField
              control={form.control}
              name="direction"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Direction</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select direction" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="outbound">Outbound</SelectItem>
                      <SelectItem value="inbound">Inbound</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Parties Involved */}
            <FormField
              control={form.control}
              name="parties_involved"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Parties Involved</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="e.g., Jane Doe (Trustee), Don Dietz (Coordinator), ABC Cleanouts"
                      rows={2}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Summary of discussion, decisions made, follow-ups…"
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => handleOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                {isEditing ? 'Save Changes' : 'Save Log Entry'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
