import { useState, useRef } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, FileText, Upload, X, Building, File } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

interface Property {
  id: string;
  address: string;
  city: string;
}

interface SendDocumentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contractor: Contractor;
  properties: Property[];
}

const ALLOWED_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'image/jpeg',
  'image/png',
  'image/gif',
];

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export function SendDocumentDialog({
  open,
  onOpenChange,
  contractor,
  properties,
}: SendDocumentDialogProps) {
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [propertyId, setPropertyId] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!ALLOWED_TYPES.includes(selectedFile.type)) {
      toast.error('Invalid file type. Please upload PDF, DOC, DOCX, or images.');
      return;
    }

    if (selectedFile.size > MAX_FILE_SIZE) {
      toast.error('File too large. Maximum size is 10MB.');
      return;
    }

    setFile(selectedFile);
  };

  const removeFile = () => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const sendDocumentMutation = useMutation({
    mutationFn: async () => {
      if (!user || !profile) throw new Error('Not authenticated');
      if (!file) throw new Error('Please select a document to send');
      if (!message.trim()) throw new Error('Message is required');

      setUploading(true);

      // Upload file to storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${contractor.id}/${Date.now()}-${file.name}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('contractor-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('contractor-documents')
        .getPublicUrl(fileName);

      // Call the edge function to send document notification
      const { data, error } = await supabase.functions.invoke('notify-contractor', {
        body: {
          contractorId: contractor.id,
          contractorName: contractor.contact_name || contractor.company_name,
          contractorPhone: contractor.phone,
          contractorEmail: contractor.email,
          propertyId: propertyId || null,
          message: message.trim(),
          subject: subject.trim() || `Document: ${file.name}`,
          senderName: profile.full_name,
          senderEmail: profile.email,
          communicationType: 'document',
          documentUrl: urlData.publicUrl,
          documentName: file.name,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      return data;
    },
    onSuccess: () => {
      toast.success('Document sent successfully');
      queryClient.invalidateQueries({ queryKey: ['contractor-communications', contractor.id] });
      resetForm();
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error(`Failed to send document: ${error.message}`);
    },
    onSettled: () => {
      setUploading(false);
    },
  });

  const resetForm = () => {
    setSubject('');
    setMessage('');
    setPropertyId('');
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSend = () => {
    sendDocumentMutation.mutate();
  };

  const selectedProperty = properties.find(p => p.id === propertyId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Send Document to {contractor.contact_name || contractor.company_name}
          </DialogTitle>
          <DialogDescription>
            Upload and send a document (RFP, contract, etc.) to this contractor.
            {contractor.email && ` An email will be sent to ${contractor.email}.`}
            {contractor.phone && ` An SMS notification will be sent to ${contractor.phone}.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="property">Property (optional)</Label>
            <Select value={propertyId || "none"} onValueChange={(value) => setPropertyId(value === "none" ? "" : value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a property..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No property</SelectItem>
                {properties.map((property) => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.address}, {property.city}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedProperty && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Building className="h-3 w-3" />
                {selectedProperty.address}, {selectedProperty.city}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Request for Proposal - Plumbing Work"
            />
          </div>

          <div className="space-y-2">
            <Label>Document *</Label>
            {file ? (
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <File className="h-8 w-8 text-primary" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={removeFile}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
              >
                <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">
                  Click to upload a document
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  PDF, DOC, DOCX, or images (max 10MB)
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept={ALLOWED_TYPES.join(',')}
              onChange={handleFileChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message *</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Please review the attached document and provide your quote..."
              rows={4}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSend} 
            disabled={!file || !message.trim() || sendDocumentMutation.isPending}
          >
            {sendDocumentMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Send Document
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
