import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Loader2, UserCheck, Unlink } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

interface LinkUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contractor: Contractor;
  onSuccess: () => void;
}

export function LinkUserDialog({
  open,
  onOpenChange,
  contractor,
  onSuccess,
}: LinkUserDialogProps) {
  const [selectedUserId, setSelectedUserId] = useState<string | null>(contractor.user_id || null);
  const queryClient = useQueryClient();

  // Reset selection when dialog opens with new contractor
  useEffect(() => {
    setSelectedUserId(contractor.user_id || null);
  }, [contractor.user_id, open]);

  // Fetch users with contractor role
  const { data: contractorUsers = [], isLoading: loadingUsers } = useQuery({
    queryKey: ['contractor-users'],
    queryFn: async () => {
      // Get users with contractor role
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'contractor');
      
      if (rolesError) throw rolesError;
      
      if (!roles || roles.length === 0) return [];

      const userIds = roles.map(r => r.user_id);

      // Get profiles for those users
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', userIds);
      
      if (profilesError) throw profilesError;
      
      return profiles || [];
    },
    enabled: open,
  });

  // Find which users are already linked to other contractors
  const { data: linkedUserIds = [] } = useQuery({
    queryKey: ['linked-contractor-users'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('contractors')
        .select('user_id')
        .not('user_id', 'is', null)
        .neq('id', contractor.id);
      
      if (error) throw error;
      
      return data?.map(c => c.user_id).filter(Boolean) as string[];
    },
    enabled: open,
  });

  const linkMutation = useMutation({
    mutationFn: async (userId: string | null) => {
      const { error } = await supabase
        .from('contractors')
        .update({ user_id: userId })
        .eq('id', contractor.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contractors'] });
      queryClient.invalidateQueries({ queryKey: ['linked-contractor-users'] });
      toast.success(selectedUserId ? 'User account linked successfully' : 'User account unlinked');
      onSuccess();
    },
    onError: (error) => {
      toast.error('Failed to update user link: ' + error.message);
    },
  });

  const handleSubmit = () => {
    linkMutation.mutate(selectedUserId);
  };

  const handleUnlink = () => {
    setSelectedUserId(null);
    linkMutation.mutate(null);
  };

  // Available users (not linked to other contractors)
  const availableUsers = contractorUsers.filter(
    user => !linkedUserIds.includes(user.id) || user.id === contractor.user_id
  );

  const currentLinkedUser = contractorUsers.find(u => u.id === contractor.user_id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Link User Account</DialogTitle>
          <DialogDescription>
            Link a user account to {contractor.company_name} to enable portal access.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {contractor.user_id && currentLinkedUser && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
              <div className="flex items-center gap-2">
                <UserCheck className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm font-medium">{currentLinkedUser.full_name}</p>
                  <p className="text-xs text-muted-foreground">{currentLinkedUser.email}</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleUnlink}
                disabled={linkMutation.isPending}
                className="text-destructive hover:text-destructive"
              >
                <Unlink className="h-4 w-4 mr-1" />
                Unlink
              </Button>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="user-select">Select User Account</Label>
            {loadingUsers ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading users...
              </div>
            ) : availableUsers.length === 0 ? (
              <p className="text-sm text-muted-foreground py-2">
                No contractor users available. Create a user with the "contractor" role first.
              </p>
            ) : (
              <Select
                value={selectedUserId || ''}
                onValueChange={(value) => setSelectedUserId(value || null)}
              >
                <SelectTrigger id="user-select">
                  <SelectValue placeholder="Select a user..." />
                </SelectTrigger>
                <SelectContent>
                  {availableUsers.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      <div className="flex flex-col">
                        <span>{user.full_name}</span>
                        <span className="text-xs text-muted-foreground">{user.email}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={linkMutation.isPending || (!selectedUserId && !contractor.user_id)}
          >
            {linkMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {selectedUserId ? 'Link User' : 'Update'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
