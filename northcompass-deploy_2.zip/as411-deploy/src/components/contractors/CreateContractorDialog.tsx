import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

const SPECIALTIES = [
  'General Contractor',
  'Electrician',
  'Plumber',
  'HVAC',
  'Roofing',
  'Landscaping',
  'Painting',
  'Flooring',
  'Carpentry',
  'Cleanout',
  'Junk Removal',
  'Appliance Repair',
  'Pest Control',
  'Stagers',
  'Other',
];

interface CreateContractorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contractor?: Contractor | null;
  onSuccess: () => void;
}

export function CreateContractorDialog({
  open,
  onOpenChange,
  contractor,
  onSuccess,
}: CreateContractorDialogProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    company_name: '',
    contact_name: '',
    specialty: '',
    phone: '',
    email: '',
    hourly_rate: '',
    notes: '',
  });

  useEffect(() => {
    if (contractor) {
      setFormData({
        company_name: contractor.company_name || '',
        contact_name: contractor.contact_name || '',
        specialty: contractor.specialty || '',
        phone: contractor.phone || '',
        email: contractor.email || '',
        hourly_rate: contractor.hourly_rate?.toString() || '',
        notes: contractor.notes || '',
      });
    } else {
      setFormData({
        company_name: '',
        contact_name: '',
        specialty: '',
        phone: '',
        email: '',
        hourly_rate: '',
        notes: '',
      });
    }
  }, [contractor, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.company_name.trim()) {
      toast.error('Company name is required');
      return;
    }

    setLoading(true);

    const payload = {
      company_name: formData.company_name.trim(),
      contact_name: formData.contact_name.trim() || null,
      specialty: formData.specialty || null,
      phone: formData.phone.trim() || null,
      email: formData.email.trim() || null,
      hourly_rate: formData.hourly_rate ? parseFloat(formData.hourly_rate) : null,
      notes: formData.notes.trim() || null,
    };

    try {
      if (contractor) {
        const { error } = await supabase
          .from('contractors')
          .update(payload)
          .eq('id', contractor.id);
        if (error) throw error;
        toast.success('Contractor updated');
      } else {
        const { error } = await supabase.from('contractors').insert(payload);
        if (error) throw error;
        toast.success('Contractor created');
      }
      onSuccess();
    } catch (error: any) {
      toast.error('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{contractor ? 'Edit Contractor' : 'Add Contractor'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="company_name">Company Name *</Label>
            <Input
              id="company_name"
              value={formData.company_name}
              onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
              placeholder="ABC Plumbing"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact_name">Contact Name</Label>
            <Input
              id="contact_name"
              value={formData.contact_name}
              onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
              placeholder="John Smith"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="specialty">Specialty</Label>
            <Select
              value={formData.specialty}
              onValueChange={(value) => setFormData({ ...formData, specialty: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select specialty" />
              </SelectTrigger>
              <SelectContent>
                {SPECIALTIES.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(808) 555-1234"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hourly_rate">Hourly Rate ($)</Label>
              <Input
                id="hourly_rate"
                type="number"
                min="0"
                step="0.01"
                value={formData.hourly_rate}
                onChange={(e) => setFormData({ ...formData, hourly_rate: e.target.value })}
                placeholder="75"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="john@abcplumbing.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Any additional notes..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {contractor ? 'Update' : 'Add'} Contractor
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
