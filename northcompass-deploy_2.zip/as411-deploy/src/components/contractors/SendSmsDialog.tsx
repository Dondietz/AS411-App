import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, MessageSquare, Building } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

interface Property {
  id: string;
  address: string;
  city: string;
}

interface SendSmsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contractor: Contractor;
  properties: Property[];
}

export function SendSmsDialog({
  open,
  onOpenChange,
  contractor,
  properties,
}: SendSmsDialogProps) {
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState('');
  const [propertyId, setPropertyId] = useState<string>('');

  const sendSmsMutation = useMutation({
    mutationFn: async () => {
      if (!user || !profile) throw new Error('Not authenticated');
      if (!contractor.phone) throw new Error('Contractor has no phone number');
      if (!message.trim()) throw new Error('Message is required');

      // Call the edge function to send SMS
      const { data, error } = await supabase.functions.invoke('notify-contractor', {
        body: {
          contractorId: contractor.id,
          contractorName: contractor.contact_name || contractor.company_name,
          contractorPhone: contractor.phone,
          contractorEmail: contractor.email,
          propertyId: propertyId || null,
          message: message.trim(),
          senderName: profile.full_name,
          senderEmail: profile.email,
          communicationType: 'sms',
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      return data;
    },
    onSuccess: (data) => {
      toast.success('SMS sent successfully');
      queryClient.invalidateQueries({ queryKey: ['contractor-communications', contractor.id] });
      setMessage('');
      setPropertyId('');
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error(`Failed to send SMS: ${error.message}`);
    },
  });

  const handleSend = () => {
    sendSmsMutation.mutate();
  };

  const selectedProperty = properties.find(p => p.id === propertyId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Send SMS to {contractor.contact_name || contractor.company_name}
          </DialogTitle>
          <DialogDescription>
            Send a text message to {contractor.phone}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="property">Property (optional)</Label>
            <Select value={propertyId || "none"} onValueChange={(value) => setPropertyId(value === "none" ? "" : value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a property..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No property</SelectItem>
                {properties.map((property) => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.address}, {property.city}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedProperty && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Building className="h-3 w-3" />
                {selectedProperty.address}, {selectedProperty.city}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message *</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your message..."
              rows={4}
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right">
              {message.length}/500 characters
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSend} 
            disabled={!message.trim() || sendSmsMutation.isPending}
          >
            {sendSmsMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Send SMS
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
