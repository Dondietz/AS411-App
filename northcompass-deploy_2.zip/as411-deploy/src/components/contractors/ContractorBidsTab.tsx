import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { format } from 'date-fns';
import { toast } from 'sonner';
import {
  Plus,
  DollarSign,
  Calendar,
  Clock,
  Building,
  FileText,
  ExternalLink,
  MoreVertical,
  Check,
  X,
  Edit,
  Trash2,
} from 'lucide-react';
import { CreateBidDialog } from './CreateBidDialog';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

interface Property {
  id: string;
  address: string;
  city: string;
}

interface Bid {
  id: string;
  contractor_id: string;
  property_id: string;
  amount: number;
  description: string;
  scope_of_work: string | null;
  estimated_start_date: string | null;
  estimated_duration_days: number | null;
  attachment_url: string | null;
  attachment_name: string | null;
  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  property?: {
    address: string;
    city: string;
  } | null;
  created_by_profile?: {
    full_name: string;
  } | null;
}

interface ContractorBidsTabProps {
  contractor: Contractor;
  properties: Property[];
}

const statusConfig = {
  pending: { label: 'Pending', variant: 'secondary' as const, color: 'text-yellow-600' },
  accepted: { label: 'Accepted', variant: 'default' as const, color: 'text-green-600' },
  rejected: { label: 'Rejected', variant: 'destructive' as const, color: 'text-red-600' },
  expired: { label: 'Expired', variant: 'outline' as const, color: 'text-muted-foreground' },
};

export function ContractorBidsTab({ contractor, properties }: ContractorBidsTabProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingBid, setEditingBid] = useState<Bid | null>(null);
  const [deletingBid, setDeletingBid] = useState<Bid | null>(null);

  const { data: bids = [], isLoading } = useQuery({
    queryKey: ['contractor-bids', contractor.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('contractor_bids')
        .select(`
          *,
          property:properties(address, city),
          created_by_profile:profiles!contractor_bids_created_by_fkey(full_name)
        `)
        .eq('contractor_id', contractor.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Bid[];
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ bidId, status }: { bidId: string; status: 'pending' | 'accepted' | 'rejected' | 'expired' }) => {
      const { error } = await supabase
        .from('contractor_bids')
        .update({
          status,
          status_changed_at: new Date().toISOString(),
          status_changed_by: user?.id,
        })
        .eq('id', bidId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Bid status updated');
      queryClient.invalidateQueries({ queryKey: ['contractor-bids', contractor.id] });
    },
    onError: (error) => {
      toast.error(`Failed to update status: ${error.message}`);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (bidId: string) => {
      const { error } = await supabase
        .from('contractor_bids')
        .delete()
        .eq('id', bidId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Bid deleted');
      queryClient.invalidateQueries({ queryKey: ['contractor-bids', contractor.id] });
      setDeletingBid(null);
    },
    onError: (error) => {
      toast.error(`Failed to delete bid: ${error.message}`);
    },
  });

  const pendingBids = bids.filter(b => b.status === 'pending');
  const acceptedBids = bids.filter(b => b.status === 'accepted');
  const otherBids = bids.filter(b => b.status === 'rejected' || b.status === 'expired');

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Loading bids...
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h3 className="text-lg font-semibold">Bids & Quotes</h3>
          <div className="flex gap-2">
            <Badge variant="secondary">{pendingBids.length} pending</Badge>
            <Badge variant="default">{acceptedBids.length} accepted</Badge>
          </div>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Bid
        </Button>
      </div>

      {bids.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <DollarSign className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-1">No bids yet</h3>
            <p className="text-muted-foreground mb-4">
              Add bids received from this contractor to track and compare quotes.
            </p>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add First Bid
            </Button>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-[500px]">
          <div className="space-y-3">
            {bids.map((bid) => {
              const statusInfo = statusConfig[bid.status as keyof typeof statusConfig] || statusConfig.pending;

              return (
                <Card key={bid.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-2">
                          <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
                          {bid.property && (
                            <span className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Building className="h-3 w-3" />
                              {bid.property.address}, {bid.property.city}
                            </span>
                          )}
                        </div>

                        <div className="flex items-baseline gap-3 mb-2">
                          <span className="text-2xl font-bold text-foreground">
                            ${bid.amount.toLocaleString()}
                          </span>
                          {bid.estimated_duration_days && (
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {bid.estimated_duration_days} days
                            </span>
                          )}
                          {bid.estimated_start_date && (
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              Start: {format(new Date(bid.estimated_start_date), 'MMM d, yyyy')}
                            </span>
                          )}
                        </div>

                        <p className="text-sm text-foreground mb-1">{bid.description}</p>
                        
                        {bid.scope_of_work && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{bid.scope_of_work}</p>
                        )}

                        {bid.attachment_url && bid.attachment_name && (
                          <a
                            href={bid.attachment_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-2"
                          >
                            <FileText className="h-3 w-3" />
                            {bid.attachment_name}
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        )}

                        {bid.notes && (
                          <p className="text-xs text-muted-foreground mt-2 italic">Note: {bid.notes}</p>
                        )}

                        <p className="text-xs text-muted-foreground mt-2">
                          Added {format(new Date(bid.created_at), 'MMM d, yyyy h:mm a')}
                          {bid.created_by_profile?.full_name && ` by ${bid.created_by_profile.full_name}`}
                        </p>
                      </div>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {bid.status === 'pending' && (
                            <>
                              <DropdownMenuItem
                                onClick={() => updateStatusMutation.mutate({ bidId: bid.id, status: 'accepted' })}
                              >
                                <Check className="h-4 w-4 mr-2 text-green-600" />
                                Accept Bid
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => updateStatusMutation.mutate({ bidId: bid.id, status: 'rejected' })}
                              >
                                <X className="h-4 w-4 mr-2 text-red-600" />
                                Reject Bid
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                            </>
                          )}
                          <DropdownMenuItem onClick={() => setEditingBid(bid)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => setDeletingBid(bid)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </ScrollArea>
      )}

      {/* Create/Edit Dialog */}
      <CreateBidDialog
        open={createDialogOpen || !!editingBid}
        onOpenChange={(open) => {
          if (!open) {
            setCreateDialogOpen(false);
            setEditingBid(null);
          }
        }}
        contractor={contractor}
        properties={properties}
        existingBid={editingBid}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingBid} onOpenChange={(open) => !open && setDeletingBid(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Bid</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this ${deletingBid?.amount.toLocaleString()} bid? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingBid && deleteMutation.mutate(deletingBid.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
