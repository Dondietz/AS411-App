import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { 
  MessageSquare, 
  FileText, 
  Mail, 
  CheckCircle, 
  XCircle, 
  Clock,
  Building,
  ExternalLink
} from 'lucide-react';

interface ContractorCommunicationHistoryProps {
  contractorId: string;
}

interface Communication {
  id: string;
  contractor_id: string;
  property_id: string | null;
  sent_by: string | null;
  communication_type: string;
  subject: string | null;
  message: string;
  document_url: string | null;
  document_name: string | null;
  recipient_phone: string | null;
  recipient_email: string | null;
  status: string;
  error_message: string | null;
  twilio_sid: string | null;
  created_at: string;
  property?: {
    address: string;
    city: string;
  } | null;
  sender?: {
    full_name: string;
  } | null;
}

const statusConfig = {
  sent: { icon: CheckCircle, color: 'text-green-500', label: 'Sent' },
  delivered: { icon: CheckCircle, color: 'text-green-500', label: 'Delivered' },
  pending: { icon: Clock, color: 'text-yellow-500', label: 'Pending' },
  failed: { icon: XCircle, color: 'text-destructive', label: 'Failed' },
};

const typeConfig = {
  sms: { icon: MessageSquare, label: 'SMS', variant: 'default' as const },
  email: { icon: Mail, label: 'Email', variant: 'secondary' as const },
  document: { icon: FileText, label: 'Document', variant: 'outline' as const },
};

export function ContractorCommunicationHistory({ contractorId }: ContractorCommunicationHistoryProps) {
  const { data: communications = [], isLoading } = useQuery({
    queryKey: ['contractor-communications', contractorId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('contractor_communications')
        .select(`
          *,
          property:properties(address, city),
          sender:profiles!contractor_communications_sent_by_fkey(full_name)
        `)
        .eq('contractor_id', contractorId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as Communication[];
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Loading communication history...
        </CardContent>
      </Card>
    );
  }

  if (communications.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-1">No communications yet</h3>
          <p className="text-muted-foreground">
            Send an SMS or document to start the communication history.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <ScrollArea className="h-[500px]">
        <div className="divide-y">
          {communications.map((comm) => {
            const typeInfo = typeConfig[comm.communication_type as keyof typeof typeConfig] || typeConfig.sms;
            const statusInfo = statusConfig[comm.status as keyof typeof statusConfig] || statusConfig.pending;
            const TypeIcon = typeInfo.icon;
            const StatusIcon = statusInfo.icon;

            return (
              <div key={comm.id} className="p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="rounded-lg bg-muted p-2">
                      <TypeIcon className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={typeInfo.variant}>{typeInfo.label}</Badge>
                        <span className={`flex items-center gap-1 text-xs ${statusInfo.color}`}>
                          <StatusIcon className="h-3 w-3" />
                          {statusInfo.label}
                        </span>
                        {comm.property && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Building className="h-3 w-3" />
                            {comm.property.address}
                          </span>
                        )}
                      </div>
                      
                      {comm.subject && (
                        <p className="font-medium mt-1">{comm.subject}</p>
                      )}
                      
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {comm.message}
                      </p>

                      {comm.document_name && comm.document_url && (
                        <a 
                          href={comm.document_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-2"
                        >
                          <FileText className="h-3 w-3" />
                          {comm.document_name}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}

                      {comm.error_message && (
                        <p className="text-xs text-destructive mt-1">{comm.error_message}</p>
                      )}

                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span>{format(new Date(comm.created_at), 'MMM d, yyyy h:mm a')}</span>
                        {comm.sender?.full_name && (
                          <>
                            <span>•</span>
                            <span>by {comm.sender.full_name}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </Card>
  );
}
