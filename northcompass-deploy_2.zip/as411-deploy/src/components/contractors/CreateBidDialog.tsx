import { useState, useRef, useEffect } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, Upload, X, File, DollarSign, Calendar, Building } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';

type Contractor = Tables<'contractors'>;

interface Property {
  id: string;
  address: string;
  city: string;
}

interface Bid {
  id: string;
  contractor_id: string;
  property_id: string;
  amount: number;
  description: string;
  scope_of_work: string | null;
  estimated_start_date: string | null;
  estimated_duration_days: number | null;
  attachment_url: string | null;
  attachment_name: string | null;
  status: string;
  notes: string | null;
}

interface CreateBidDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contractor: Contractor;
  properties: Property[];
  existingBid?: Bid | null;
}

const ALLOWED_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'image/jpeg',
  'image/png',
];

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export function CreateBidDialog({
  open,
  onOpenChange,
  contractor,
  properties,
  existingBid,
}: CreateBidDialogProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [propertyId, setPropertyId] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [scopeOfWork, setScopeOfWork] = useState('');
  const [estimatedStartDate, setEstimatedStartDate] = useState('');
  const [estimatedDurationDays, setEstimatedDurationDays] = useState('');
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [existingAttachment, setExistingAttachment] = useState<{ url: string; name: string } | null>(null);

  useEffect(() => {
    if (existingBid) {
      setPropertyId(existingBid.property_id);
      setAmount(existingBid.amount.toString());
      setDescription(existingBid.description);
      setScopeOfWork(existingBid.scope_of_work || '');
      setEstimatedStartDate(existingBid.estimated_start_date || '');
      setEstimatedDurationDays(existingBid.estimated_duration_days?.toString() || '');
      setNotes(existingBid.notes || '');
      if (existingBid.attachment_url && existingBid.attachment_name) {
        setExistingAttachment({ url: existingBid.attachment_url, name: existingBid.attachment_name });
      }
    } else {
      resetForm();
    }
  }, [existingBid, open]);

  const resetForm = () => {
    setPropertyId('');
    setAmount('');
    setDescription('');
    setScopeOfWork('');
    setEstimatedStartDate('');
    setEstimatedDurationDays('');
    setNotes('');
    setFile(null);
    setExistingAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!ALLOWED_TYPES.includes(selectedFile.type)) {
      toast.error('Invalid file type. Please upload PDF, DOC, DOCX, XLSX, or images.');
      return;
    }

    if (selectedFile.size > MAX_FILE_SIZE) {
      toast.error('File too large. Maximum size is 10MB.');
      return;
    }

    setFile(selectedFile);
    setExistingAttachment(null);
  };

  const removeFile = () => {
    setFile(null);
    setExistingAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const saveBidMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error('Not authenticated');
      if (!propertyId) throw new Error('Please select a property');
      if (!amount || parseFloat(amount) <= 0) throw new Error('Please enter a valid amount');
      if (!description.trim()) throw new Error('Description is required');

      let attachmentUrl = existingAttachment?.url || null;
      let attachmentName = existingAttachment?.name || null;

      // Upload new file if selected
      if (file) {
        const fileName = `${contractor.id}/${propertyId}/${Date.now()}-${file.name}`;
        const { error: uploadError } = await supabase.storage
          .from('contractor-documents')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('contractor-documents')
          .getPublicUrl(fileName);

        attachmentUrl = urlData.publicUrl;
        attachmentName = file.name;
      }

      const bidData = {
        contractor_id: contractor.id,
        property_id: propertyId,
        amount: parseFloat(amount),
        description: description.trim(),
        scope_of_work: scopeOfWork.trim() || null,
        estimated_start_date: estimatedStartDate || null,
        estimated_duration_days: estimatedDurationDays ? parseInt(estimatedDurationDays) : null,
        attachment_url: attachmentUrl,
        attachment_name: attachmentName,
        notes: notes.trim() || null,
        created_by: user.id,
      };

      if (existingBid) {
        const { error } = await supabase
          .from('contractor_bids')
          .update(bidData)
          .eq('id', existingBid.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('contractor_bids')
          .insert(bidData);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(existingBid ? 'Bid updated successfully' : 'Bid added successfully');
      queryClient.invalidateQueries({ queryKey: ['contractor-bids', contractor.id] });
      queryClient.invalidateQueries({ queryKey: ['property-bids'] });
      resetForm();
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error(`Failed to save bid: ${error.message}`);
    },
  });

  const selectedProperty = properties.find(p => p.id === propertyId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            {existingBid ? 'Edit Bid' : 'Add Bid'} from {contractor.contact_name || contractor.company_name}
          </DialogTitle>
          <DialogDescription>
            Enter the bid details received from this contractor.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="property">Property *</Label>
            <Select value={propertyId} onValueChange={setPropertyId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a property..." />
              </SelectTrigger>
              <SelectContent>
                {properties.map((property) => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.address}, {property.city}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedProperty && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Building className="h-3 w-3" />
                {selectedProperty.address}, {selectedProperty.city}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Bid Amount *</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="amount"
                  type="number"
                  min="0"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="5000.00"
                  className="pl-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (days)</Label>
              <Input
                id="duration"
                type="number"
                min="1"
                value={estimatedDurationDays}
                onChange={(e) => setEstimatedDurationDays(e.target.value)}
                placeholder="14"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="startDate">Estimated Start Date</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="startDate"
                type="date"
                value={estimatedStartDate}
                onChange={(e) => setEstimatedStartDate(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of the bid..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="scopeOfWork">Scope of Work</Label>
            <Textarea
              id="scopeOfWork"
              value={scopeOfWork}
              onChange={(e) => setScopeOfWork(e.target.value)}
              placeholder="Detailed scope of work included in this bid..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Attachment (Quote/Proposal)</Label>
            {file || existingAttachment ? (
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <File className="h-8 w-8 text-primary" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {file?.name || existingAttachment?.name}
                  </p>
                  {file && (
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  )}
                </div>
                <Button variant="ghost" size="icon" onClick={removeFile}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:border-primary transition-colors"
              >
                <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-1" />
                <p className="text-sm text-muted-foreground">
                  Click to upload quote/proposal
                </p>
                <p className="text-xs text-muted-foreground">
                  PDF, DOC, XLSX, or images (max 10MB)
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept={ALLOWED_TYPES.join(',')}
              onChange={handleFileChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Internal Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any internal notes about this bid..."
              rows={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => saveBidMutation.mutate()}
            disabled={saveBidMutation.isPending}
          >
            {saveBidMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {existingBid ? 'Update Bid' : 'Add Bid'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
