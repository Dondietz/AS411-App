import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Contractor {
  id: string;
  company_name: string;
  contact_name?: string;
}

interface Client {
  id: string;
  full_name: string;
  user_id?: string;
}

interface CreateThreadDialogProps {
  propertyId: string;
  onThreadCreated: (
    threadType: 'client_coord' | 'contractor_coord' | 'internal',
    title: string,
    participantUserIds: string[]
  ) => Promise<{ error?: string }>;
}

export function CreateThreadDialog({ propertyId, onThreadCreated }: CreateThreadDialogProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [client, setClient] = useState<Client | null>(null);
  const [selectedParticipant, setSelectedParticipant] = useState('');
  const [title, setTitle] = useState('');

  useEffect(() => {
    async function fetchData() {
      // Fetch contractors
      const { data: contractorsData } = await supabase
        .from('contractors')
        .select('id, company_name, contact_name')
        .eq('is_active', true)
        .order('company_name');
      
      if (contractorsData) setContractors(contractorsData);

      // Fetch property's client
      const { data: propertyData } = await supabase
        .from('properties')
        .select('client_id, clients(id, full_name, user_id)')
        .eq('id', propertyId)
        .maybeSingle();
      
      if (propertyData?.clients) {
        setClient(propertyData.clients as Client);
      }
    }

    if (open) {
      fetchData();
    }
  }, [open, propertyId]);

  const handleCreate = async () => {
    if (!selectedParticipant) {
      toast({ title: 'Error', description: 'Please select a participant', variant: 'destructive' });
      return;
    }

    setLoading(true);

    const isClient = selectedParticipant.startsWith('client_');
    const participantId = selectedParticipant.replace('client_', '').replace('contractor_', '');

    let threadTitle: string;
    let threadType: 'client_coord' | 'contractor_coord';
    let participantUserIds: string[] = [];

    if (isClient && client) {
      threadType = 'client_coord';
      threadTitle = title.trim() || `${client.full_name} ↔ Coordinator`;
      if (client.user_id) {
        participantUserIds = [client.user_id];
      }
    } else {
      const contractor = contractors.find(c => c.id === participantId);
      threadType = 'contractor_coord';
      threadTitle = title.trim() || `${contractor?.company_name || 'Contractor'} ↔ Coordinator`;
    }

    const result = await onThreadCreated(threadType, threadTitle, participantUserIds);

    if (result.error) {
      toast({ title: 'Error', description: result.error, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Thread created successfully' });
      setOpen(false);
      setTitle('');
      setSelectedParticipant('');
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="h-4 w-4 mr-1" />
          New Thread
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Thread</DialogTitle>
          <DialogDescription>
            Start a conversation with the property owner or a contractor.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label>Participant</Label>
            <Select value={selectedParticipant} onValueChange={setSelectedParticipant}>
              <SelectTrigger>
                <SelectValue placeholder="Select owner or contractor" />
              </SelectTrigger>
              <SelectContent>
                {client && (
                  <SelectItem key={`client_${client.id}`} value={`client_${client.id}`}>
                    👤 {client.full_name} (Owner)
                  </SelectItem>
                )}
                {contractors.map(contractor => (
                  <SelectItem key={`contractor_${contractor.id}`} value={`contractor_${contractor.id}`}>
                    🔧 {contractor.company_name}
                    {contractor.contact_name && ` (${contractor.contact_name})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Thread Title (optional)</Label>
            <Input
              placeholder="e.g., Project Discussion"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreate} disabled={loading || !selectedParticipant}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Thread'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
