import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ThreadList } from './ThreadList';
import { MessageThread } from './MessageThread';
import { CreateThreadDialog } from './CreateThreadDialog';
import { useThreads } from '@/hooks/useThreads';
import { useThreadMessages } from '@/hooks/useThreadMessages';
import { useToast } from '@/hooks/use-toast';
import { MessageSquare } from 'lucide-react';
import type { Thread } from '@/types/messaging';

interface MessagingTabProps {
  propertyId: string;
  propertyAddress?: string;
  onCreateTask?: (messageId: string, body: string) => void;
}

export function MessagingTab({ propertyId, propertyAddress, onCreateTask }: MessagingTabProps) {
  const { toast } = useToast();
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  
  const { threads, loading: threadsLoading, createThread, archiveThread } = useThreads(propertyId);
  const { messages, loading: messagesLoading, sendMessage } = useThreadMessages(selectedThreadId);

  const selectedThread = threads.find(t => t.id === selectedThreadId) || null;

  const handleSendMessage = async (body: string) => {
    const result = await sendMessage(
      body, 
      propertyId, 
      undefined, 
      selectedThread?.title,
      propertyAddress
    );
    if (result.error) {
      toast({ title: 'Error', description: result.error, variant: 'destructive' });
    }
  };

  const handleArchiveThread = async (threadId: string) => {
    const { error } = await archiveThread(threadId);
    if (error) {
      toast({ title: 'Error', description: 'Could not archive thread', variant: 'destructive' });
    } else {
      if (selectedThreadId === threadId) {
        setSelectedThreadId(null);
      }
      toast({ title: 'Thread archived' });
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-3 h-[600px]">
      {/* Thread List */}
      <Card className="lg:col-span-1">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Conversations
            </CardTitle>
            <CreateThreadDialog
              propertyId={propertyId}
              onThreadCreated={createThread}
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ThreadList
            threads={threads}
            selectedThreadId={selectedThreadId}
            onSelectThread={setSelectedThreadId}
            onArchiveThread={handleArchiveThread}
            loading={threadsLoading}
          />
        </CardContent>
      </Card>

      {/* Message Thread */}
      <Card className="lg:col-span-2 flex flex-col">
        <MessageThread
          thread={selectedThread}
          messages={messages}
          loading={messagesLoading}
          onSendMessage={handleSendMessage}
          onCreateTask={onCreateTask}
        />
      </Card>
    </div>
  );
}
