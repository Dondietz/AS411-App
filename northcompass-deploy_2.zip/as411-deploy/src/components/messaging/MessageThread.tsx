import { useRef, useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Send, Loader2, Image, Paperclip, CheckSquare } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';
import type { ThreadMessage, Thread } from '@/types/messaging';
import { useAuth } from '@/hooks/useAuth';

interface MessageThreadProps {
  thread: Thread | null;
  messages: ThreadMessage[];
  loading: boolean;
  onSendMessage: (body: string) => Promise<void>;
  onCreateTask?: (messageId: string, body: string) => void;
}

function getDateLabel(date: Date): string {
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  return format(date, 'MMMM d, yyyy');
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export function MessageThread({
  thread,
  messages,
  loading,
  onSendMessage,
  onCreateTask,
}: MessageThreadProps) {
  const { user } = useAuth();
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Scroll to bottom when messages change
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!newMessage.trim() || sending) return;
    setSending(true);
    await onSendMessage(newMessage);
    setNewMessage('');
    setSending(false);
  };

  if (!thread) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Send className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Select a conversation to start messaging</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  // Group messages by date
  const groupedMessages: { date: string; messages: ThreadMessage[] }[] = [];
  messages.forEach(msg => {
    const dateLabel = getDateLabel(new Date(msg.created_at));
    const existing = groupedMessages.find(g => g.date === dateLabel);
    if (existing) {
      existing.messages.push(msg);
    } else {
      groupedMessages.push({ date: dateLabel, messages: [msg] });
    }
  });

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b bg-muted/30">
        <h3 className="font-medium">{thread.title}</h3>
        <p className="text-xs text-muted-foreground mt-0.5">
          {thread.participants?.length || 0} participants
        </p>
      </div>

      {/* Messages */}
      <ScrollArea ref={scrollRef} className="flex-1 p-4">
        {messages.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <p className="text-sm">No messages yet. Start the conversation!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {groupedMessages.map(group => (
              <div key={group.date}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-xs text-muted-foreground font-medium">
                    {group.date}
                  </span>
                  <div className="flex-1 h-px bg-border" />
                </div>

                <div className="space-y-4">
                  {group.messages.map(msg => {
                    const isOwn = msg.sender_user_id === user?.id;
                    const isSystem = msg.message_type === 'system';

                    if (isSystem) {
                      return (
                        <div key={msg.id} className="flex justify-center">
                          <Badge variant="outline" className="text-xs py-1 px-3">
                            {msg.body}
                          </Badge>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={msg.id}
                        className={cn(
                          'flex gap-3 group',
                          isOwn && 'flex-row-reverse'
                        )}
                      >
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarFallback className="text-xs bg-primary/10 text-primary">
                            {msg.sender?.full_name ? getInitials(msg.sender.full_name) : 'U'}
                          </AvatarFallback>
                        </Avatar>

                        <div className={cn('flex flex-col max-w-[70%]', isOwn && 'items-end')}>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-foreground">
                              {msg.sender?.full_name || 'Unknown'}
                            </span>
                            <Badge variant="outline" className="text-[10px] py-0 capitalize">
                              {msg.sender_role}
                            </Badge>
                          </div>

                          <div
                            className={cn(
                              'rounded-lg px-4 py-2 text-sm',
                              isOwn
                                ? 'bg-primary text-primary-foreground rounded-br-none'
                                : 'bg-muted text-foreground rounded-bl-none'
                            )}
                          >
                            {msg.attachment_url && (
                              <div className="flex items-center gap-2 mb-2 text-xs opacity-80">
                                {msg.message_type === 'image' ? (
                                  <Image className="h-3 w-3" />
                                ) : (
                                  <Paperclip className="h-3 w-3" />
                                )}
                                <a
                                  href={msg.attachment_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="underline"
                                >
                                  View attachment
                                </a>
                              </div>
                            )}
                            {msg.body}
                          </div>

                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[10px] text-muted-foreground">
                              {format(new Date(msg.created_at), 'h:mm a')}
                            </span>
                            {onCreateTask && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-5 w-5 opacity-0 group-hover:opacity-100"
                                onClick={() => onCreateTask(msg.id, msg.body)}
                                title="Create task from message"
                              >
                                <CheckSquare className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t bg-background">
        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
            disabled={sending}
          />
          <Button onClick={handleSend} disabled={sending || !newMessage.trim()}>
            {sending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
