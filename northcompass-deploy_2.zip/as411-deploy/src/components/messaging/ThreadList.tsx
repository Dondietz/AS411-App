import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users, Building2, MessageCircle, Archive, MoreVertical } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { Thread } from '@/types/messaging';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ThreadListProps {
  threads: Thread[];
  selectedThreadId: string | null;
  onSelectThread: (threadId: string) => void;
  onArchiveThread: (threadId: string) => void;
  loading?: boolean;
}

const threadTypeIcons = {
  client_coord: Users,
  contractor_coord: Building2,
  internal: MessageCircle,
};

const threadTypeLabels = {
  client_coord: 'Family',
  contractor_coord: 'Contractor',
  internal: 'Internal',
};

export function ThreadList({
  threads,
  selectedThreadId,
  onSelectThread,
  onArchiveThread,
  loading,
}: ThreadListProps) {
  if (loading) {
    return (
      <div className="p-4 space-y-3">
        {[1, 2, 3].map(i => (
          <div key={i} className="animate-pulse">
            <div className="h-16 bg-muted rounded-lg" />
          </div>
        ))}
      </div>
    );
  }

  if (threads.length === 0) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No conversations yet</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-1 p-2">
        {threads.map(thread => {
          const Icon = threadTypeIcons[thread.thread_type];
          const isSelected = thread.id === selectedThreadId;
          const hasUnread = (thread.unread_count || 0) > 0;

          return (
            <div
              key={thread.id}
              className={cn(
                'group flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors',
                isSelected
                  ? 'bg-primary/10 border border-primary/20'
                  : 'hover:bg-muted/50'
              )}
              onClick={() => onSelectThread(thread.id)}
            >
              <Avatar className="h-10 w-10 shrink-0">
                <AvatarFallback className={cn(
                  'text-xs',
                  thread.thread_type === 'client_coord' && 'bg-blue-100 text-blue-700',
                  thread.thread_type === 'contractor_coord' && 'bg-amber-100 text-amber-700',
                  thread.thread_type === 'internal' && 'bg-purple-100 text-purple-700'
                )}>
                  <Icon className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className={cn(
                    'text-sm truncate',
                    hasUnread ? 'font-semibold' : 'font-medium'
                  )}>
                    {thread.title}
                  </span>
                  {hasUnread && (
                    <Badge variant="default" className="h-5 min-w-[20px] px-1.5 text-[10px]">
                      {thread.unread_count}
                    </Badge>
                  )}
                </div>
                
                <p className="text-xs text-muted-foreground truncate mt-0.5">
                  {thread.last_message?.body || 'No messages yet'}
                </p>
                
                <div className="flex items-center justify-between mt-1">
                  <Badge 
                    variant="outline" 
                    className={cn(
                      "text-[10px] py-0 border",
                      thread.thread_type === 'client_coord' && 'bg-blue-50 text-blue-700 border-blue-200',
                      thread.thread_type === 'contractor_coord' && 'bg-amber-50 text-amber-700 border-amber-200',
                      thread.thread_type === 'internal' && 'bg-purple-50 text-purple-700 border-purple-200'
                    )}
                  >
                    {threadTypeLabels[thread.thread_type]}
                  </Badge>
                  <span className="text-[10px] text-muted-foreground">
                    {formatDistanceToNow(new Date(thread.last_message_at), { addSuffix: true })}
                  </span>
                </div>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 opacity-0 group-hover:opacity-100 shrink-0"
                    onClick={e => e.stopPropagation()}
                  >
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onArchiveThread(thread.id)}>
                    <Archive className="h-4 w-4 mr-2" />
                    Archive
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          );
        })}
      </div>
    </ScrollArea>
  );
}
