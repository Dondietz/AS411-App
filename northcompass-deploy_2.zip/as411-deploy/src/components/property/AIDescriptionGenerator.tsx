import { useState } from 'react';
import { Sparkles, Loader2, Copy, Check, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import type { Property } from '@/types/database';

interface AIDescriptionGeneratorProps {
  property: Property;
  onDescriptionGenerated?: (description: string) => void;
}

const styles = [
  { value: 'professional', label: 'Professional', description: 'Polished MLS-style listing' },
  { value: 'warm', label: 'Warm & Welcoming', description: 'Emphasizes comfort and livability' },
  { value: 'luxury', label: 'Luxury', description: 'Elegant and sophisticated tone' },
  { value: 'concise', label: 'Concise', description: 'Brief and punchy highlights' },
];

export function AIDescriptionGenerator({ property, onDescriptionGenerated }: AIDescriptionGeneratorProps) {
  const [open, setOpen] = useState(false);
  const [style, setStyle] = useState('professional');
  const [description, setDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const generateDescription = async () => {
    setIsGenerating(true);
    setDescription('');

    try {
      const { data, error } = await supabase.functions.invoke('generate-description', {
        body: { property, style }
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      setDescription(data.description);
      toast({ title: 'Description generated!', description: 'Review and copy to your listing.' });
    } catch (error: any) {
      console.error('Error generating description:', error);
      toast({
        title: 'Generation failed',
        description: error.message || 'Could not generate description. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(description);
    setCopied(true);
    onDescriptionGenerated?.(description);
    toast({ title: 'Copied to clipboard!' });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Sparkles className="h-4 w-4 text-accent" />
          Generate AI Description
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-accent" />
            AI Property Description
          </DialogTitle>
          <DialogDescription>
            Generate a professional listing description for {property.address}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Writing Style</Label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {styles.map((s) => (
                  <SelectItem key={s.value} value={s.value}>
                    <div className="flex flex-col">
                      <span>{s.label}</span>
                      <span className="text-xs text-muted-foreground">{s.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={generateDescription} 
              disabled={isGenerating}
              className="flex-1"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : description ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Regenerate
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate Description
                </>
              )}
            </Button>
          </div>

          {description && (
            <div className="space-y-2 animate-slide-up">
              <Label>Generated Description</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={8}
                className="resize-none"
              />
              <div className="flex justify-end">
                <Button variant="secondary" onClick={copyToClipboard} className="gap-2">
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copy to Clipboard
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
