import { Check, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { PropertyStatus } from '@/types/database';

interface PropertyTimelineProps {
  currentStatus: PropertyStatus;
}

const statuses: { status: PropertyStatus; label: string }[] = [
  { status: 'intake', label: 'Intake' },
  { status: 'cleanout', label: 'Cleanout' },
  { status: 'repair', label: 'Repair' },
  { status: 'listing', label: 'Listing' },
  { status: 'escrow', label: 'Escrow' },
  { status: 'closed', label: 'Closed' },
];

export function PropertyTimeline({ currentStatus }: PropertyTimelineProps) {
  const currentIndex = statuses.findIndex(s => s.status === currentStatus);

  return (
    <div className="relative">
      <div className="flex items-center justify-between">
        {statuses.map((item, index) => {
          const isCompleted = index < currentIndex;
          const isCurrent = index === currentIndex;

          return (
            <div key={item.status} className="flex flex-col items-center relative z-10">
              <div
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-300',
                  isCompleted && 'bg-success border-success text-success-foreground',
                  isCurrent && 'bg-primary border-primary text-primary-foreground animate-pulse-soft',
                  !isCompleted && !isCurrent && 'bg-muted border-muted-foreground/30 text-muted-foreground'
                )}
              >
                {isCompleted ? (
                  <Check className="h-5 w-5" />
                ) : (
                  <Circle className="h-4 w-4" />
                )}
              </div>
              <span className={cn(
                'mt-2 text-xs font-medium text-center',
                isCurrent ? 'text-primary' : 'text-muted-foreground'
              )}>
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
      {/* Progress line */}
      <div className="absolute top-5 left-0 right-0 h-0.5 bg-muted -z-0">
        <div 
          className="h-full bg-success transition-all duration-500"
          style={{ width: `${(currentIndex / (statuses.length - 1)) * 100}%` }}
        />
      </div>
    </div>
  );
}
