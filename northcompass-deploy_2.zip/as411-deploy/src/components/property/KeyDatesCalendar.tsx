import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useCalendarSettings } from '@/hooks/useCalendarSettings';
import { Calendar as CalendarIcon, Plus, Trash2, Loader2, ListTodo } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Property, Task } from '@/types/database';

interface Appointment {
  id: string;
  title: string;
  description: string | null;
  start_time: string;
  end_time: string;
  location: string | null;
}

interface KeyDatesCalendarProps {
  property: Property;
  tasks?: Task[];
}

export function KeyDatesCalendar({ property, tasks = [] }: KeyDatesCalendarProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { settings } = useCalendarSettings();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    startTime: '09:00',
    endTime: '10:00',
  });

  useEffect(() => {
    fetchAppointments();
  }, [property.id]);

  const fetchAppointments = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('property_id', property.id)
      .order('start_time', { ascending: true });

    if (error) {
      toast({ title: 'Error', description: 'Could not load appointments', variant: 'destructive' });
    } else {
      setAppointments(data || []);
    }
    setIsLoading(false);
  };

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    if (date) {
      setNewEvent({ title: '', description: '', startTime: '09:00', endTime: '10:00' });
      setIsDialogOpen(true);
    }
  };

  const handleSaveEvent = async () => {
    if (!selectedDate || !newEvent.title.trim() || !user) return;
    
    setIsSaving(true);
    const startDateTime = new Date(selectedDate);
    const [startHour, startMin] = newEvent.startTime.split(':').map(Number);
    startDateTime.setHours(startHour, startMin, 0, 0);

    const endDateTime = new Date(selectedDate);
    const [endHour, endMin] = newEvent.endTime.split(':').map(Number);
    endDateTime.setHours(endHour, endMin, 0, 0);

    const { error } = await supabase.from('appointments').insert({
      property_id: property.id,
      title: newEvent.title.trim(),
      description: newEvent.description.trim() || null,
      start_time: startDateTime.toISOString(),
      end_time: endDateTime.toISOString(),
      created_by: user.id,
    });

    if (error) {
      toast({ title: 'Error', description: 'Could not save event', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Event added' });
      setIsDialogOpen(false);
      fetchAppointments();
    }
    setIsSaving(false);
  };

  const handleDeleteEvent = async (appointmentId: string) => {
    const { error } = await supabase.from('appointments').delete().eq('id', appointmentId);
    if (error) {
      toast({ title: 'Error', description: 'Could not delete event', variant: 'destructive' });
    } else {
      toast({ title: 'Deleted', description: 'Event removed' });
      fetchAppointments();
    }
  };

  // Get dates that have appointments or tasks for highlighting
  const appointmentDates = appointments.map(a => new Date(a.start_time).toDateString());
  const taskDates = tasks.filter(t => t.due_date).map(t => new Date(t.due_date!).toDateString());
  const allEventDates = [...new Set([...appointmentDates, ...taskDates])];

  // Tasks with due dates for display
  const tasksWithDates = tasks.filter(t => t.due_date).sort((a, b) => 
    new Date(a.due_date!).getTime() - new Date(b.due_date!).getTime()
  );

  // Key property dates
  const keyDates = [
    { label: 'Intake', date: property.intake_date },
    { label: 'Target Close', date: property.target_close_date },
    { label: 'Actual Close', date: property.actual_close_date },
  ].filter(d => d.date);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <CalendarIcon className="h-4 w-4" /> Key Dates & Schedule
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Property key dates */}
        <div className="space-y-2 text-sm">
          {keyDates.map(({ label, date }) => (
            <div key={label} className="flex justify-between">
              <span className="text-muted-foreground">{label}</span>
              <span className={label === 'Actual Close' ? 'text-green-600' : ''}>
                {format(new Date(date!), 'MMM d, yyyy')}
              </span>
            </div>
          ))}
        </div>

        {/* Interactive Calendar */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start gap-2">
              <Plus className="h-4 w-4" />
              Add Event to Calendar
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={handleDateSelect}
              weekStartsOn={settings.weekStartsOn}
              className="p-3 pointer-events-auto"
              modifiers={{
                hasEvent: (date) => allEventDates.includes(date.toDateString()),
              }}
              modifiersClassNames={{
                hasEvent: 'bg-primary/20 font-semibold ring-2 ring-primary/30',
              }}
            />
          </PopoverContent>
        </Popover>

        {/* Combined events list */}
        {isLoading ? (
          <div className="flex justify-center py-4">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (appointments.length > 0 || tasksWithDates.length > 0) ? (
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {/* Tasks with due dates */}
            {tasksWithDates.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                  <ListTodo className="h-3 w-3" /> Task Due Dates
                </p>
                {tasksWithDates.map(task => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between gap-2 p-2 rounded-md bg-blue-500/10 border border-blue-500/20 text-sm"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{task.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Due: {format(new Date(task.due_date!), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <Badge variant={task.status === 'completed' ? 'default' : 'secondary'} className="text-xs">
                      {task.status}
                    </Badge>
                  </div>
                ))}
              </div>
            )}

            {/* Appointments */}
            {appointments.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                  <CalendarIcon className="h-3 w-3" /> Scheduled Events
                </p>
                {appointments.map(apt => (
                  <div
                    key={apt.id}
                    className="flex items-start justify-between gap-2 p-2 rounded-md bg-muted/50 text-sm"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{apt.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(apt.start_time), 'MMM d, h:mm a')}
                      </p>
                      {apt.description && (
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {apt.description}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-destructive hover:text-destructive"
                  onClick={() => handleDeleteEvent(apt.id)}
                >
                  <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))}
              </div>
            )}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-2">
            No scheduled events or task due dates
          </p>
        )}
      </CardContent>

      {/* New Event Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Add Event for {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : ''}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Title *</label>
              <Input
                placeholder="e.g., Contractor walkthrough"
                value={newEvent.title}
                onChange={e => setNewEvent(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Start Time</label>
                <Input
                  type="time"
                  value={newEvent.startTime}
                  onChange={e => setNewEvent(prev => ({ ...prev, startTime: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">End Time</label>
                <Input
                  type="time"
                  value={newEvent.endTime}
                  onChange={e => setNewEvent(prev => ({ ...prev, endTime: e.target.value }))}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                placeholder="Job details, notes, etc."
                value={newEvent.description}
                onChange={e => setNewEvent(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEvent} disabled={isSaving || !newEvent.title.trim()}>
              {isSaving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Save Event
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
