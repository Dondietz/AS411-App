import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, Plus, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Client } from '@/types/database';

const islands = ['Oʻahu', 'Maui', 'Hawaiʻi', 'Kauaʻi'] as const;
const propertyTypes = ['Single-Family', 'Condo'] as const;

const propertySchema = z.object({
  address: z.string().min(1, 'Property address is required').max(200),
  island: z.enum(islands, { required_error: 'Island is required' }),
  property_type: z.enum(propertyTypes, { required_error: 'Property type is required' }),
  client_id: z.string().optional(),
  coordinator_id: z.string().optional(),
  estimated_value: z.string().optional(),
  target_close_date: z.date().optional(),
  notes: z.string().max(2000).optional(),
});

type PropertyFormData = z.infer<typeof propertySchema>;

interface CreatePropertyDialogProps {
  onSuccess?: () => void;
}

export function CreatePropertyDialog({ onSuccess }: CreatePropertyDialogProps) {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [clients, setClients] = useState<Client[]>([]);
  const [coordinators, setCoordinators] = useState<{ id: string; full_name: string; email: string }[]>([]);
  const { toast } = useToast();

  const form = useForm<PropertyFormData>({
    resolver: zodResolver(propertySchema),
    defaultValues: {
      address: '',
      client_id: '',
      coordinator_id: '',
      estimated_value: '',
      notes: '',
    },
  });

  useEffect(() => {
    if (open) {
      supabase.from('clients').select('*').order('full_name').then(({ data }) => {
        setClients((data as Client[]) || []);
      });
      supabase.from('profiles').select('id, full_name, email').order('full_name').then(({ data }) => {
        setCoordinators(data || []);
      });
    }
  }, [open]);

  const onSubmit = async (data: PropertyFormData) => {
    setIsSubmitting(true);
    
    // Parse city from address for the required city field
    const addressParts = data.address.split(',');
    const city = addressParts.length > 1 ? addressParts[1].trim().split(' ')[0] : 'Honolulu';
    
    const { error } = await supabase.from('properties').insert({
      address: data.address.trim(),
      city: city,
      state: 'HI',
      island: data.island,
      property_type: data.property_type,
      client_id: data.client_id || null,
      coordinator_id: data.coordinator_id || null,
      estimated_value: data.estimated_value ? parseFloat(data.estimated_value.replace(/[^0-9.]/g, '')) : null,
      target_close_date: data.target_close_date ? format(data.target_close_date, 'yyyy-MM-dd') : null,
      notes: data.notes?.trim() || null,
    });

    setIsSubmitting(false);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Property created', description: `${data.address} has been added.` });
      form.reset();
      setOpen(false);
      onSuccess?.();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4 mr-1" /> Add Property</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">Add New Property</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* 1️⃣ Property Address */}
            <FormField control={form.control} name="address" render={({ field }) => (
              <FormItem>
                <FormLabel>Property Address *</FormLabel>
                <FormControl>
                  <Input placeholder="1234 Kalākaua Ave, Honolulu, HI" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* 2️⃣ Island */}
            <FormField control={form.control} name="island" render={({ field }) => (
              <FormItem>
                <FormLabel>Island *</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select island" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-popover">
                    {islands.map(island => (
                      <SelectItem key={island} value={island}>{island}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            {/* 3️⃣ Property Type */}
            <FormField control={form.control} name="property_type" render={({ field }) => (
              <FormItem>
                <FormLabel>Property Type *</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select property type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-popover">
                    {propertyTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            {/* 4️⃣ Client/Owner */}
            <FormField control={form.control} name="client_id" render={({ field }) => (
              <FormItem>
                <FormLabel>Client/Owner</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select client (optional)" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-popover">
                    {clients.map(client => (
                      <SelectItem key={client.id} value={client.id}>{client.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            {/* 4.5️⃣ Coordinator */}
            <FormField control={form.control} name="coordinator_id" render={({ field }) => (
              <FormItem>
                <FormLabel>Coordinator</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select coordinator (optional)" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-popover">
                    {coordinators.map(coordinator => (
                      <SelectItem key={coordinator.id} value={coordinator.id}>
                        {coordinator.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            {/* 5️⃣ Estimated Property Value */}
            <FormField control={form.control} name="estimated_value" render={({ field }) => (
              <FormItem>
                <FormLabel>Estimated Property Value</FormLabel>
                <FormControl>
                  <Input type="text" inputMode="numeric" placeholder="1150000" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* 5️⃣ Target Close Date */}
            <FormField control={form.control} name="target_close_date" render={({ field }) => (
              <FormItem>
                <FormLabel>Target Close Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button 
                        variant="outline" 
                        className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                      >
                        {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-popover" align="start">
                    <Calendar 
                      mode="single" 
                      selected={field.value} 
                      onSelect={field.onChange} 
                      initialFocus 
                      className="pointer-events-auto" 
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )} />

            {/* 6️⃣ Initial Notes */}
            <FormField control={form.control} name="notes" render={({ field }) => (
              <FormItem>
                <FormLabel>Initial Notes</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Background, family situation, urgency, special considerations…" 
                    rows={4} 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Property'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
