import { useState, useEffect, useCallback, useRef, DragEvent } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Camera, Upload, Loader2, ImageIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { SortablePhoto } from './SortablePhoto';

interface PropertyPhotosProps {
  propertyId: string;
}

interface PhotoFile {
  id: string;
  file_name: string;
  file_url: string;
  created_at: string;
  signed_url?: string;
}

export function PropertyPhotos({ propertyId }: PropertyPhotosProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [photos, setPhotos] = useState<PhotoFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const dragCounter = useRef(0);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      setPhotos((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
      toast({ title: 'Photo order updated' });
    }
  };

  const openLightbox = (index: number) => {
    setSelectedPhotoIndex(index);
    setLightboxOpen(true);
  };

  const goToPrevious = () => {
    setSelectedPhotoIndex((prev) => (prev === 0 ? photos.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setSelectedPhotoIndex((prev) => (prev === photos.length - 1 ? 0 : prev + 1));
  };

  const handleDragEnter = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) {
      setIsDragging(false);
    }
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    dragCounter.current = 0;
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(Array.from(files));
    }
  };

  const fetchPhotos = useCallback(async () => {
    const { data, error } = await supabase
      .from('files')
      .select('id, file_name, file_url, created_at')
      .eq('property_id', propertyId)
      .eq('category', 'photo')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching photos:', error);
      setLoading(false);
      return;
    }

    // Generate signed URLs for each photo (valid for 1 hour)
    const photosWithSignedUrls = await Promise.all(
      (data || []).map(async (photo) => {
        // Extract file path from stored URL
        const urlParts = photo.file_url.split('/property-files/');
        const filePath = urlParts[1];
        
        if (filePath) {
          const { data: signedData } = await supabase.storage
            .from('property-files')
            .createSignedUrl(filePath, 3600); // 1 hour expiry
          
          return { ...photo, signed_url: signedData?.signedUrl || photo.file_url };
        }
        return { ...photo, signed_url: photo.file_url };
      })
    );

    setPhotos(photosWithSignedUrls);
    setLoading(false);
  }, [propertyId]);

  useEffect(() => {
    fetchPhotos();
  }, [fetchPhotos]);

  const processFiles = async (files: File[]) => {
    if (!user || files.length === 0) return;

    setUploading(true);

    for (const file of files) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: 'Invalid file type',
          description: `${file.name} is not an image`,
          variant: 'destructive',
        });
        continue;
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: `${file.name} exceeds 10MB limit`,
          variant: 'destructive',
        });
        continue;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${propertyId}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('property-files')
        .upload(fileName, file);

      if (uploadError) {
        toast({
          title: 'Upload failed',
          description: uploadError.message,
          variant: 'destructive',
        });
        continue;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('property-files')
        .getPublicUrl(fileName);

      // Save file record
      const { error: dbError } = await supabase.from('files').insert({
        property_id: propertyId,
        file_name: file.name,
        file_url: urlData.publicUrl,
        file_type: file.type,
        file_size: file.size,
        category: 'photo',
        uploaded_by: user.id,
      });

      if (dbError) {
        toast({
          title: 'Error saving file record',
          description: dbError.message,
          variant: 'destructive',
        });
      }
    }

    await fetchPhotos();
    setUploading(false);
    toast({ title: 'Photos uploaded successfully' });
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    processFiles(Array.from(files));
    e.target.value = '';
  };

  const handleDelete = async (photo: PhotoFile) => {
    // Extract file path from URL
    const urlParts = photo.file_url.split('/property-files/');
    const filePath = urlParts[1];

    if (filePath) {
      await supabase.storage.from('property-files').remove([filePath]);
    }

    const { error } = await supabase.from('files').delete().eq('id', photo.id);

    if (error) {
      toast({
        title: 'Error deleting photo',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      setPhotos(prev => prev.filter(p => p.id !== photo.id));
      toast({ title: 'Photo deleted' });
    }
  };

  return (
    <Card
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={cn(
        "relative transition-all duration-200",
        isDragging && "ring-2 ring-primary ring-offset-2"
      )}
    >
      {isDragging && (
        <div className="absolute inset-0 z-10 bg-primary/10 backdrop-blur-sm flex items-center justify-center rounded-lg border-2 border-dashed border-primary">
          <div className="text-center">
            <Upload className="h-12 w-12 mx-auto text-primary mb-2" />
            <p className="text-lg font-medium text-primary">Drop photos here</p>
            <p className="text-sm text-muted-foreground">Release to upload</p>
          </div>
        </div>
      )}
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Photos
            <span className="text-sm font-normal text-muted-foreground">
              ({photos.length})
            </span>
          </div>
          <div className="relative">
            <Input
              type="file"
              accept="image/*"
              multiple
              onChange={handleUpload}
              disabled={uploading}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <Button size="sm" disabled={uploading}>
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              Upload
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : photos.length > 0 ? (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext items={photos.map(p => p.id)} strategy={rectSortingStrategy}>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {photos.map((photo, index) => (
                  <SortablePhoto
                    key={photo.id}
                    photo={photo}
                    index={index}
                    onOpenLightbox={openLightbox}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            </SortableContext>
          </DndContext>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <ImageIcon className="h-12 w-12 mb-3 opacity-50" />
            <p className="text-sm">No photos uploaded yet</p>
            <p className="text-xs mt-1">Upload photos to document this property</p>
          </div>
        )}

        {/* Lightbox Dialog */}
        <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
          <DialogContent className="max-w-[95vw] max-h-[95vh] p-0 bg-black/95 border-none">
            <div className="relative flex items-center justify-center w-full h-[90vh]">
              {photos.length > 0 && (
                <>
                  <img
                    src={photos[selectedPhotoIndex]?.signed_url || photos[selectedPhotoIndex]?.file_url}
                    alt={photos[selectedPhotoIndex]?.file_name}
                    className="max-w-full max-h-full object-contain"
                  />
                  
                  {photos.length > 1 && (
                    <>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute left-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/50 hover:bg-black/70 text-white"
                        onClick={goToPrevious}
                      >
                        <ChevronLeft className="h-8 w-8" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute right-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/50 hover:bg-black/70 text-white"
                        onClick={goToNext}
                      >
                        <ChevronRight className="h-8 w-8" />
                      </Button>
                    </>
                  )}
                  
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/80 text-sm">
                    {selectedPhotoIndex + 1} / {photos.length}
                  </div>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
