import { forwardRef } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { ImageIcon, X, GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PhotoFile {
  id: string;
  file_name: string;
  file_url: string;
  created_at: string;
  signed_url?: string;
}

interface SortablePhotoProps {
  photo: PhotoFile;
  index: number;
  onOpenLightbox: (index: number) => void;
  onDelete: (photo: PhotoFile) => void;
}

export const SortablePhoto = forwardRef<HTMLDivElement, SortablePhotoProps>(
  function SortablePhoto({ photo, index, onOpenLightbox, onDelete }, _ref) {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
      isDragging,
    } = useSortable({ id: photo.id });

    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
    };

    return (
      <div
        ref={setNodeRef}
        style={style}
        className={cn(
          "relative group aspect-square rounded-lg overflow-hidden bg-muted",
          isDragging && "opacity-50 ring-2 ring-primary z-50"
        )}
      >
        <img
          src={photo.signed_url || photo.file_url}
          alt={photo.file_name}
          className="w-full h-full object-cover transition-transform group-hover:scale-105 cursor-pointer"
          onClick={() => onOpenLightbox(index)}
        />
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 cursor-grab active:cursor-grabbing"
            {...attributes}
            {...listeners}
          >
            <GripVertical className="h-4 w-4" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8"
            onClick={() => onOpenLightbox(index)}
          >
            <ImageIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="destructive"
            size="icon"
            className="h-8 w-8"
            onClick={() => onDelete(photo)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        {/* Drag handle indicator */}
        <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <div
            className="p-1 rounded bg-black/50 text-white cursor-grab active:cursor-grabbing"
            {...attributes}
            {...listeners}
          >
            <GripVertical className="h-4 w-4" />
          </div>
        </div>
      </div>
    );
  }
);
