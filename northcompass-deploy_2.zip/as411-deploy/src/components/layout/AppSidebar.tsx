import { 
  LayoutDashboard, 
  Building2, 
  ListTodo, 
  MessageSquare, 
  Calendar,
  FileText,
  DollarSign,
  LogOut,
  User,
  Users,
  HardHat,
  UserCog,
  Home
} from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { useUnreadMessages } from '@/hooks/useUnreadMessages';
import { cn } from '@/lib/utils';

const mainNavItems = [
  { title: 'Dashboard', url: '/dashboard', icon: LayoutDashboard },
  { title: 'Properties', url: '/properties', icon: Building2 },
  { title: 'Clients', url: '/clients', icon: Users },
  { title: 'Contractors', url: '/contractors', icon: HardHat },
  { title: 'Tasks', url: '/tasks', icon: ListTodo },
  { title: 'Messages', url: '/messages', icon: MessageSquare },
  { title: 'Schedule', url: '/schedule', icon: Calendar },
  { title: 'Files', url: '/files', icon: FileText },
  { title: 'Financials', url: '/financials', icon: DollarSign },
];

const adminNavItems = [
  { title: 'User Management', url: '/users', icon: UserCog },
];

const clientNavItems = [
  { title: 'My Portal', url: '/portal', icon: Home },
  { title: 'Messages', url: '/messages', icon: MessageSquare },
];

const contractorNavItems = [
  { title: 'My Portal', url: '/contractor-portal', icon: HardHat },
  { title: 'Messages', url: '/messages', icon: MessageSquare },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const { profile, signOut, roles, isCoordinator } = useAuth();
  const { unreadCount } = useUnreadMessages();
  const collapsed = state === 'collapsed';
  const isAdmin = roles.includes('admin');
  const isContractor = roles.includes('contractor') && !isCoordinator;
  const isClient = roles.includes('client') && !isCoordinator;

  const getRoleLabel = () => {
    if (isAdmin) return 'Admin';
    if (isCoordinator) return 'Coordinator';
    if (isClient) return 'Client';
    if (roles.includes('contractor')) return 'Contractor';
    return 'User';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg overflow-hidden bg-white">
            <img src="/logo.png" alt="North Compass" className="h-10 w-10 object-contain" />
          </div>
          {!collapsed && (
            <div className="flex flex-col animate-fade-in">
              <span className="font-display font-semibold text-sidebar-foreground">North Compass</span>
              <span className="text-xs text-sidebar-foreground/60">{getRoleLabel()}</span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="px-2 py-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs uppercase tracking-wider mb-2">
            {!collapsed && 'Navigation'}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {(isClient ? clientNavItems : isContractor ? contractorNavItems : mainNavItems).map((item) => {
                const isActive = location.pathname === item.url || 
                  (item.url !== '/dashboard' && item.url !== '/portal' && location.pathname.startsWith(item.url));
                
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      tooltip={item.title}
                      className={cn(
                        'transition-all duration-200',
                        isActive && 'bg-sidebar-accent text-sidebar-accent-foreground'
                      )}
                    >
                      <NavLink to={item.url} className="flex items-center gap-3 w-full">
                        <item.icon className="h-5 w-5" />
                        {!collapsed && <span>{item.title}</span>}
                        {item.title === 'Messages' && unreadCount > 0 && (
                          <Badge 
                            variant="destructive" 
                            className={cn(
                              "ml-auto h-5 min-w-5 px-1.5 text-xs font-medium",
                              collapsed && "absolute -top-1 -right-1 h-4 min-w-4 px-1"
                            )}
                          >
                            {unreadCount > 99 ? '99+' : unreadCount}
                          </Badge>
                        )}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {isAdmin && !isClient && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs uppercase tracking-wider mb-2">
              {!collapsed && 'Admin'}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminNavItems.map((item) => {
                  const isActive = location.pathname === item.url;
                  
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        tooltip={item.title}
                        className={cn(
                          'transition-all duration-200',
                          isActive && 'bg-sidebar-accent text-sidebar-accent-foreground'
                        )}
                      >
                        <NavLink to={item.url} className="flex items-center gap-3">
                          <item.icon className="h-5 w-5" />
                          {!collapsed && <span>{item.title}</span>}
                        </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 border-2 border-sidebar-primary/30">
            <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground text-sm">
              {profile?.full_name ? getInitials(profile.full_name) : <User className="h-4 w-4" />}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="flex flex-1 flex-col overflow-hidden animate-fade-in">
              <span className="truncate text-sm font-medium text-sidebar-foreground">
                {profile?.full_name || 'Coordinator'}
              </span>
              <span className="truncate text-xs text-sidebar-foreground/60">
                {profile?.email}
              </span>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={signOut}
            className="h-8 w-8 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
