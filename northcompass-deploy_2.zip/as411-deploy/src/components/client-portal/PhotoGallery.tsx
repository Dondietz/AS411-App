import { useState, useRef, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Loader2, Check, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface Photo {
  id: string;
  signed_url?: string;
  file_url: string;
  file_name: string;
  caption?: string | null;
}

interface PhotoGalleryProps {
  photos: Photo[];
  initialIndex?: number;
  onClose: () => void;
  onCaptionUpdated?: () => void;
  onPhotoDeleted?: () => void;
}

export function PhotoGallery({ photos, initialIndex = 0, onClose, onCaptionUpdated, onPhotoDeleted }: PhotoGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [isEditingCaption, setIsEditingCaption] = useState(false);
  const [caption, setCaption] = useState(photos[currentIndex]?.caption || '');
  const [isSaving, setIsSaving] = useState(false);
  const [scale, setScale] = useState(1);
  const [initialPinchDistance, setInitialPinchDistance] = useState<number | null>(null);
  const [initialScale, setInitialScale] = useState(1);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [initialPosition, setInitialPosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const currentPhoto = photos[currentIndex];
  const minSwipeDistance = 50;

  useEffect(() => {
    setCaption(currentPhoto?.caption || '');
    setIsEditingCaption(false);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, [currentIndex, currentPhoto?.caption]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') goToPrevious();
      if (e.key === 'ArrowRight') goToNext();
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const goToNext = () => {
    if (currentIndex < photos.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const getDistance = (touches: React.TouchList) => {
    return Math.hypot(
      touches[0].clientX - touches[1].clientX,
      touches[0].clientY - touches[1].clientY
    );
  };

  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      // Pinch start
      setInitialPinchDistance(getDistance(e.touches));
      setInitialScale(scale);
    } else if (e.touches.length === 1) {
      if (scale > 1) {
        // Pan start when zoomed
        setIsDragging(true);
        setDragStart({
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        });
        setInitialPosition({ ...position });
      } else {
        // Swipe start (only when not zoomed)
        setTouchEnd(null);
        setTouchStart(e.targetTouches[0].clientX);
      }
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialPinchDistance) {
      // Pinch move
      const currentDistance = getDistance(e.touches);
      const newScale = Math.min(Math.max(initialScale * (currentDistance / initialPinchDistance), 1), 4);
      setScale(newScale);
    } else if (e.touches.length === 1) {
      if (scale > 1 && isDragging) {
        // Pan move when zoomed
        const deltaX = e.touches[0].clientX - dragStart.x;
        const deltaY = e.touches[0].clientY - dragStart.y;
        setPosition({
          x: initialPosition.x + deltaX,
          y: initialPosition.y + deltaY,
        });
      } else if (scale === 1) {
        // Swipe move (only when not zoomed)
        setTouchEnd(e.targetTouches[0].clientX);
      }
    }
  };

  const onTouchEnd = () => {
    setInitialPinchDistance(null);
    setIsDragging(false);
    
    // Reset position if zoomed out
    if (scale === 1) {
      setPosition({ x: 0, y: 0 });
    }
    
    if (scale === 1 && touchStart && touchEnd) {
      const distance = touchStart - touchEnd;
      const isLeftSwipe = distance > minSwipeDistance;
      const isRightSwipe = distance < -minSwipeDistance;

      if (isLeftSwipe) {
        goToNext();
      } else if (isRightSwipe) {
        goToPrevious();
      }
    }
  };

  const handleDoubleTap = () => {
    if (scale === 1) {
      setScale(2);
    } else {
      setScale(1);
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleSaveCaption = async () => {
    if (!currentPhoto) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('files')
        .update({ caption })
        .eq('id', currentPhoto.id);

      if (error) throw error;
      
      toast.success('Caption saved');
      setIsEditingCaption(false);
      onCaptionUpdated?.();
    } catch (error: any) {
      toast.error('Failed to save caption');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeletePhoto = async () => {
    if (!currentPhoto) return;
    
    setIsDeleting(true);
    try {
      // Extract path from file_url
      const urlParts = currentPhoto.file_url.split('/');
      const filePath = urlParts.slice(-2).join('/'); // property_id/filename
      
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('property-files')
        .remove([filePath]);

      if (storageError) throw storageError;

      // Delete from database
      const { error: dbError } = await supabase
        .from('files')
        .delete()
        .eq('id', currentPhoto.id);

      if (dbError) throw dbError;
      
      toast.success('Photo deleted');
      setShowDeleteConfirm(false);
      
      // If this was the last photo, close the gallery
      if (photos.length === 1) {
        onClose();
      } else if (currentIndex >= photos.length - 1) {
        setCurrentIndex(currentIndex - 1);
      }
      
      onPhotoDeleted?.();
    } catch (error: any) {
      toast.error('Failed to delete photo');
    } finally {
      setIsDeleting(false);
    }
  };

  if (!currentPhoto) return null;

  return (
    <>
    <div 
      ref={containerRef}
      className="fixed inset-0 z-50 bg-black flex flex-col"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 text-white">
        <span className="text-sm">
          {currentIndex + 1} / {photos.length}
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="p-2 rounded-full hover:bg-white/10 text-red-400 hover:text-red-300"
          >
            <Trash2 className="h-5 w-5" />
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
      </div>

      {/* Image container */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {/* Previous button (desktop) */}
        {currentIndex > 0 && (
          <button
            onClick={goToPrevious}
            className="hidden md:flex absolute left-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 z-10"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
        )}

        {/* Image */}
        <img
          ref={imageRef}
          src={currentPhoto.signed_url || currentPhoto.file_url}
          alt={currentPhoto.file_name}
          className="max-w-full max-h-full object-contain select-none transition-transform duration-200"
          style={{ transform: `scale(${scale}) translate(${position.x / scale}px, ${position.y / scale}px)` }}
          draggable={false}
          onDoubleClick={handleDoubleTap}
        />

        {/* Next button (desktop) */}
        {currentIndex < photos.length - 1 && (
          <button
            onClick={goToNext}
            className="hidden md:flex absolute right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 z-10"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        )}

        {/* Swipe indicators (mobile) */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5 md:hidden">
          {photos.map((_, idx) => (
            <div
              key={idx}
              className={`w-1.5 h-1.5 rounded-full transition-colors ${
                idx === currentIndex ? 'bg-white' : 'bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Caption area */}
      <div className="p-4 bg-black/50 backdrop-blur-sm">
        {isEditingCaption ? (
          <div className="flex gap-2">
            <Input
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Add a caption..."
              className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/50"
              autoFocus
            />
            <Button
              size="icon"
              onClick={handleSaveCaption}
              disabled={isSaving}
              className="bg-primary hover:bg-primary/90"
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Check className="h-4 w-4" />
              )}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => {
                setCaption(currentPhoto.caption || '');
                setIsEditingCaption(false);
              }}
              className="text-white hover:bg-white/10"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <button
            onClick={() => setIsEditingCaption(true)}
            className="w-full text-left text-white/80 hover:text-white text-sm min-h-[40px] flex items-center"
          >
            {currentPhoto.caption || 'Tap to add caption...'}
          </button>
        )}
      </div>
    </div>

    <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
      <AlertDialogContent className="bg-background">
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Photo</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete this photo? This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDeletePhoto}
            disabled={isDeleting}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isDeleting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}