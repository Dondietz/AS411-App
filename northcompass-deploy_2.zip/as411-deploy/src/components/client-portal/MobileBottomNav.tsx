import { Link, useLocation } from 'react-router-dom';
import { Home, ListChecks, MessagesSquare, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { label: 'Dashboard', icon: Home, href: '/portal', activeMatch: '/portal' },
  { label: 'Checklist', icon: ListChecks, href: '/portal?tab=checklist', activeMatch: 'checklist' },
  { label: 'Messages', icon: MessagesSquare, href: '/messages', activeMatch: '/messages' },
  { label: 'More', icon: MoreHorizontal, href: '/portal?tab=settings', activeMatch: 'settings' },
];

interface MobileBottomNavProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function MobileBottomNav({ activeTab, onTabChange }: MobileBottomNavProps) {
  const location = useLocation();

  const isActive = (item: typeof navItems[0]) => {
    if (activeTab) {
      if (item.activeMatch === '/portal' && activeTab === 'dashboard') return true;
      if (item.activeMatch === 'checklist' && activeTab === 'checklist') return true;
      if (item.activeMatch === 'settings' && activeTab === 'settings') return true;
    }
    if (item.activeMatch === '/messages') return location.pathname === '/messages';
    return false;
  };

  const handleClick = (item: typeof navItems[0]) => {
    if (onTabChange) {
      if (item.activeMatch === '/portal') onTabChange('dashboard');
      else if (item.activeMatch === 'checklist') onTabChange('checklist');
      else if (item.activeMatch === 'settings') onTabChange('settings');
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border safe-area-bottom">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item) => {
          const active = isActive(item);
          
          if (item.activeMatch === '/messages') {
            return (
              <Link
                key={item.label}
                to={item.href}
                className={cn(
                  'flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors',
                  active ? 'text-primary' : 'text-muted-foreground'
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            );
          }

          return (
            <button
              key={item.label}
              onClick={() => handleClick(item)}
              className={cn(
                'flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors',
                active ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
