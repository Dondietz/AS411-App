import { CheckCircle2, Circle, Sparkles, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import type { Task } from '@/types/database';

interface NextStepsSectionProps {
  tasks: Task[];
}

export function NextStepsSection({ tasks }: NextStepsSectionProps) {
  // Sort tasks: incomplete first, then by due date
  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.status === 'completed' && b.status !== 'completed') return 1;
    if (a.status !== 'completed' && b.status === 'completed') return -1;
    if (a.due_date && b.due_date) {
      return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
    }
    return 0;
  });

  const getTaskIcon = (task: Task) => {
    // Different icons based on task title/type
    const title = task.title.toLowerCase();
    if (title.includes('move') || title.includes('cleanout')) return '🧹';
    if (title.includes('estate') || title.includes('sale')) return '📦';
    if (title.includes('schedule')) return '📅';
    if (title.includes('declutter') || title.includes('clean')) return '✨';
    if (title.includes('repair')) return '🔧';
    if (title.includes('list')) return '📋';
    return '📌';
  };

  return (
    <section className="px-4 py-4">
      <h2 className="text-lg font-semibold text-destructive mb-3">Next Steps</h2>
      <div className="space-y-3">
        {sortedTasks.length === 0 ? (
          <p className="text-sm text-muted-foreground py-2">No tasks yet. Check back soon!</p>
        ) : (
          sortedTasks.map((task) => (
            <div key={task.id} className="flex items-start gap-3">
              {task.status === 'completed' ? (
                <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1 min-w-0 flex items-center gap-2">
                <span className="text-base flex-shrink-0">{getTaskIcon(task)}</span>
                <span className={cn(
                  'flex-1 text-sm',
                  task.status === 'completed' && 'line-through text-muted-foreground'
                )}>
                  {task.title}
                </span>
              </div>
              {task.due_date && (
                <span className="text-sm text-muted-foreground flex-shrink-0">
                  {format(new Date(task.due_date), 'MMM d')}
                </span>
              )}
            </div>
          ))
        )}
      </div>
    </section>
  );
}
