import { useState, useRef } from 'react';
import { Image, Plus, Loader2, ChevronRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { PhotoGallery } from './PhotoGallery';

interface Photo {
  id: string;
  signed_url?: string;
  file_url: string;
  file_name: string;
  caption?: string | null;
}

interface PhotosRowProps {
  photos: Photo[];
  propertyId?: string;
  onPhotoUploaded?: () => void;
}

export function PhotosRow({ photos, propertyId, onPhotoUploaded }: PhotosRowProps) {
  const displayPhotos = photos.slice(0, 3);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryStartIndex, setGalleryStartIndex] = useState(0);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const openGallery = (index: number) => {
    setGalleryStartIndex(index);
    setGalleryOpen(true);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !propertyId) return;

    const file = files[0];
    
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error('Image must be less than 10MB');
      return;
    }

    setIsUploading(true);

    try {
      const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `${propertyId}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('property-files')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('property-files')
        .getPublicUrl(fileName);

      const { error: dbError } = await supabase
        .from('files')
        .insert({
          property_id: propertyId,
          file_name: file.name,
          file_url: publicUrl,
          file_type: file.type,
          file_size: file.size,
          category: 'Photos',
        });

      if (dbError) throw dbError;

      toast.success('Photo uploaded successfully');
      onPhotoUploaded?.();
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Failed to upload photo');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <>
      <section className="px-4 py-3">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
            <Image className="h-5 w-5 text-accent" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-sm">Photos</h3>
                <p className="text-xs text-muted-foreground">
                  {photos.length > 0 ? `${photos.length} photos` : 'Tap + to upload'}
                </p>
              </div>
              {photos.length > 3 && (
                <button
                  onClick={() => openGallery(0)}
                  className="flex items-center gap-1 text-xs text-primary font-medium"
                >
                  View all
                  <ChevronRight className="h-3 w-3" />
                </button>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex gap-1.5 mt-3 ml-[52px]">
          {/* Upload button */}
          <button
            onClick={handleUploadClick}
            disabled={isUploading || !propertyId}
            className="w-14 h-14 rounded-lg bg-primary/10 border-2 border-dashed border-primary/30 flex items-center justify-center hover:bg-primary/20 transition-colors disabled:opacity-50 flex-shrink-0"
          >
            {isUploading ? (
              <Loader2 className="h-5 w-5 text-primary animate-spin" />
            ) : (
              <Plus className="h-5 w-5 text-primary" />
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileChange}
            className="hidden"
          />
          
          {displayPhotos.length > 0 ? (
            displayPhotos.map((photo, index) => (
              <button
                key={photo.id}
                onClick={() => openGallery(index)}
                className="w-14 h-14 rounded-lg overflow-hidden bg-muted relative flex-shrink-0"
              >
                <img
                  src={photo.signed_url || photo.file_url}
                  alt={photo.file_name}
                  className="w-full h-full object-cover"
                />
                {index === 2 && photos.length > 3 && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="text-white text-sm font-medium">+{photos.length - 3}</span>
                  </div>
                )}
              </button>
            ))
          ) : (
            <div className="flex gap-1.5">
              {[1, 2].map((i) => (
                <div key={i} className="w-14 h-14 rounded-lg bg-muted flex-shrink-0" />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Full gallery with swipe */}
      {galleryOpen && photos.length > 0 && (
        <PhotoGallery
          photos={photos}
          initialIndex={galleryStartIndex}
          onClose={() => setGalleryOpen(false)}
          onCaptionUpdated={onPhotoUploaded}
          onPhotoDeleted={onPhotoUploaded}
        />
      )}
    </>
  );
}
