import { Calendar, TrendingUp, DollarSign } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface QuickLinksProps {
  estimatedValue?: number | null;
  deferredCosts?: number;
}

const formatCurrency = (amount: number) => {
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`;
  }
  if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(0)}K`;
  }
  return `$${amount.toLocaleString()}`;
};

export function QuickLinks({ estimatedValue, deferredCosts = 0 }: QuickLinksProps) {
  const netProceeds = estimatedValue ? estimatedValue - deferredCosts : null;
  const lowEstimate = netProceeds ? netProceeds * 0.95 : null;
  const highEstimate = netProceeds ? netProceeds * 1.05 : null;

  return (
    <section className="px-4 py-2 space-y-1">
      <Separator className="mb-3" />
      
      <div className="flex items-center gap-3 py-2.5">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center">
          <Calendar className="h-5 w-5 text-info" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Schedule</h3>
          <p className="text-xs text-muted-foreground">Schedule cleanouts, repairs, walkthroughs</p>
        </div>
      </div>

      <div className="flex items-center gap-3 py-2.5">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
          <TrendingUp className="h-5 w-5 text-warning" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Progress</h3>
          <p className="text-xs text-muted-foreground">Track progress on sale, bids, escrow</p>
        </div>
      </div>

      <div className="flex items-center gap-3 py-2.5">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
          <DollarSign className="h-5 w-5 text-success" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Estimate</h3>
          {netProceeds && estimatedValue ? (
            <div className="text-xs text-muted-foreground">
              Net proceeds {formatCurrency(netProceeds)} · Deferred costs {formatCurrency(deferredCosts)}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">Financial estimates will appear here</p>
          )}
        </div>
      </div>

      {lowEstimate && highEstimate && (
        <div className="flex items-center justify-between py-3 px-3 mt-2 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
              <DollarSign className="h-3 w-3 text-primary" />
            </div>
            <span className="text-xs text-muted-foreground">Est. range</span>
          </div>
          <span className="text-sm font-semibold">
            {formatCurrency(lowEstimate)} – {formatCurrency(highEstimate)}
          </span>
        </div>
      )}
    </section>
  );
}
