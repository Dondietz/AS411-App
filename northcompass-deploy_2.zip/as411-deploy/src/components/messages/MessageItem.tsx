import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import type { Message } from '@/types/database';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface MessageItemProps {
  message: Message;
  isOwn?: boolean;
}

export function MessageItem({ message, isOwn = false }: MessageItemProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className={cn(
      'flex gap-3 animate-slide-up',
      isOwn && 'flex-row-reverse'
    )}>
      <Avatar className="h-8 w-8 shrink-0">
        <AvatarFallback className="text-xs bg-primary/10 text-primary">
          {message.sender?.full_name ? getInitials(message.sender.full_name) : 'U'}
        </AvatarFallback>
      </Avatar>
      <div className={cn('flex flex-col max-w-[70%]', isOwn && 'items-end')}>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-foreground">
            {message.sender?.full_name || 'Unknown'}
          </span>
          {message.is_internal && (
            <Badge variant="outline" className="text-[10px] py-0">Internal</Badge>
          )}
        </div>
        <div className={cn(
          'rounded-lg px-4 py-2 text-sm',
          isOwn 
            ? 'bg-primary text-primary-foreground rounded-br-none' 
            : 'bg-muted text-foreground rounded-bl-none'
        )}>
          {message.content}
        </div>
        <span className="text-xs text-muted-foreground mt-1">
          {format(new Date(message.created_at), 'MMM d, h:mm a')}
        </span>
      </div>
    </div>
  );
}
