import { cn } from '@/lib/utils';
import type { PropertyStatus, TaskStatus } from '@/types/database';

const propertyStatusConfig: Record<PropertyStatus, { label: string; className: string }> = {
  intake: { label: 'Intake', className: 'status-intake' },
  cleanout: { label: 'Cleanout', className: 'status-cleanout' },
  repair: { label: 'Repair', className: 'status-repair' },
  listing: { label: 'Listing', className: 'status-listing' },
  escrow: { label: 'Escrow', className: 'status-escrow' },
  closed: { label: 'Closed', className: 'status-closed' },
};

const taskStatusConfig: Record<TaskStatus, { label: string; className: string }> = {
  pending: { label: 'Pending', className: 'bg-muted text-muted-foreground' },
  in_progress: { label: 'In Progress', className: 'bg-info/15 text-info' },
  completed: { label: 'Completed', className: 'bg-success/15 text-success' },
  blocked: { label: 'Blocked', className: 'bg-destructive/15 text-destructive' },
};

interface StatusBadgeProps {
  status: PropertyStatus | TaskStatus;
  type: 'property' | 'task';
  className?: string;
}

export function StatusBadge({ status, type, className }: StatusBadgeProps) {
  const config = type === 'property' 
    ? propertyStatusConfig[status as PropertyStatus]
    : taskStatusConfig[status as TaskStatus];

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium border',
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
}
