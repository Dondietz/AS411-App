import { useState, useEffect } from 'react';
import { TableCell, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin, Check, X, Pencil, Home, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { toast } from 'sonner';
import type { Client, Property } from '@/types/database';
import { NotificationHistoryDialog } from './NotificationHistoryDialog';

interface EditableClientRowProps {
  client: Client;
  onUpdate: () => void;
}

export function EditableClientRow({ client, onUpdate }: EditableClientRowProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [properties, setProperties] = useState<Property[]>([]);
  const [linkedProperties, setLinkedProperties] = useState<Property[]>([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('');
  const [editData, setEditData] = useState({
    full_name: client.full_name,
    email: client.email || '',
    phone: client.phone || '',
    address: client.address || '',
  });

  const handleDelete = async () => {
    setDeleting(true);
    const { error } = await supabase
      .from('clients')
      .delete()
      .eq('id', client.id);
    
    setDeleting(false);
    if (error) {
      toast.error('Failed to delete client');
    } else {
      toast.success('Client deleted');
      onUpdate();
    }
  };

  useEffect(() => {
    if (isEditing) {
      // Fetch unassigned properties
      supabase
        .from('properties')
        .select('*')
        .is('client_id', null)
        .order('address')
        .then(({ data }) => setProperties((data as Property[]) || []));
      
      // Fetch properties linked to this client
      supabase
        .from('properties')
        .select('*')
        .eq('client_id', client.id)
        .order('address')
        .then(({ data }) => setLinkedProperties((data as Property[]) || []));
    }
  }, [isEditing, client.id]);

  const handleSave = async () => {
    setSaving(true);
    const { error } = await supabase
      .from('clients')
      .update({
        full_name: editData.full_name,
        email: editData.email || null,
        phone: editData.phone || null,
        address: editData.address || null,
      })
      .eq('id', client.id);

    setSaving(false);
    if (error) {
      toast.error('Failed to update client');
    } else {
      toast.success('Client updated');
      setIsEditing(false);
      onUpdate();
    }
  };

  const handleLinkProperty = async () => {
    if (!selectedPropertyId) return;
    setSaving(true);
    const { error } = await supabase
      .from('properties')
      .update({ client_id: client.id })
      .eq('id', selectedPropertyId);
    
    setSaving(false);
    if (error) {
      toast.error('Failed to link property');
    } else {
      toast.success('Property linked to client');
      setSelectedPropertyId('');
      // Refresh lists
      supabase.from('properties').select('*').is('client_id', null).order('address')
        .then(({ data }) => setProperties((data as Property[]) || []));
      supabase.from('properties').select('*').eq('client_id', client.id).order('address')
        .then(({ data }) => setLinkedProperties((data as Property[]) || []));
    }
  };

  const handleUnlinkProperty = async (propertyId: string) => {
    setSaving(true);
    const { error } = await supabase
      .from('properties')
      .update({ client_id: null })
      .eq('id', propertyId);
    
    setSaving(false);
    if (error) {
      toast.error('Failed to unlink property');
    } else {
      toast.success('Property unlinked');
      supabase.from('properties').select('*').is('client_id', null).order('address')
        .then(({ data }) => setProperties((data as Property[]) || []));
      supabase.from('properties').select('*').eq('client_id', client.id).order('address')
        .then(({ data }) => setLinkedProperties((data as Property[]) || []));
    }
  };

  const handleCancel = () => {
    setEditData({
      full_name: client.full_name,
      email: client.email || '',
      phone: client.phone || '',
      address: client.address || '',
    });
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <TableRow>
        <TableCell>
          <Input
            value={editData.full_name}
            onChange={(e) => setEditData({ ...editData, full_name: e.target.value })}
            className="h-8"
          />
        </TableCell>
        <TableCell>
          <div className="space-y-2">
            <div className="flex items-center gap-1">
              <Mail className="h-3 w-3 text-muted-foreground" />
              <Input
                type="email"
                value={editData.email}
                onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                placeholder="Email"
                className="h-7 text-sm"
              />
            </div>
            <div className="flex items-center gap-1">
              <Phone className="h-3 w-3 text-muted-foreground" />
              <Input
                type="tel"
                value={editData.phone}
                onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                placeholder="Phone"
                className="h-7 text-sm"
              />
            </div>
          </div>
        </TableCell>
        <TableCell>
          <div className="space-y-2">
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3 text-muted-foreground" />
              <Input
                value={editData.address}
                onChange={(e) => setEditData({ ...editData, address: e.target.value })}
                placeholder="Address"
                className="h-7 text-sm"
              />
            </div>
            {/* Linked Properties */}
            {linkedProperties.length > 0 && (
              <div className="space-y-1">
                <span className="text-xs text-muted-foreground">Linked Properties:</span>
                {linkedProperties.map(prop => (
                  <div key={prop.id} className="flex items-center justify-between gap-1 text-xs bg-muted/50 rounded px-2 py-1">
                    <span className="truncate">{prop.address}</span>
                    <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => handleUnlinkProperty(prop.id)} disabled={saving}>
                      <X className="h-3 w-3 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            {/* Link New Property */}
            <div className="flex items-center gap-1">
              <Home className="h-3 w-3 text-muted-foreground" />
              <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
                <SelectTrigger className="h-7 text-sm flex-1">
                  <SelectValue placeholder="Link property..." />
                </SelectTrigger>
                <SelectContent className="bg-popover">
                  {properties.map(prop => (
                    <SelectItem key={prop.id} value={prop.id} className="text-sm">{prop.address}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleLinkProperty} disabled={!selectedPropertyId || saving}>
                <Check className="h-4 w-4 text-green-600" />
              </Button>
            </div>
          </div>
        </TableCell>
        <TableCell>
          {/* Added date - keep visible in edit mode */}
          <span className="text-sm text-muted-foreground">{format(new Date(client.created_at), 'MMM d, yyyy')}</span>
        </TableCell>
        <TableCell className="text-right">
          <div className="flex items-center justify-end gap-1">
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleSave} disabled={saving}>
              <Check className="h-4 w-4 text-green-600" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleCancel} disabled={saving}>
              <X className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        </TableCell>
      </TableRow>
    );
  }

  return (
    <TableRow className="group">
      <TableCell className="font-medium">{client.full_name}</TableCell>
      <TableCell>
        <div className="space-y-1 text-sm text-muted-foreground">
          {client.email && <div className="flex items-center gap-1"><Mail className="h-3 w-3" />{client.email}</div>}
          {client.phone && <div className="flex items-center gap-1"><Phone className="h-3 w-3" />{client.phone}</div>}
        </div>
      </TableCell>
      <TableCell>
        {client.address && <div className="flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="h-3 w-3" />{client.address}</div>}
      </TableCell>
      <TableCell>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">{format(new Date(client.created_at), 'MMM d, yyyy')}</span>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={() => setIsEditing(true)}
          >
            <Pencil className="h-3.5 w-3.5" />
          </Button>
        </div>
      </TableCell>
      <TableCell className="text-right">
        <div className="flex items-center justify-end gap-1">
          <NotificationHistoryDialog clientId={client.id} clientName={client.full_name} />
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Client</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete {client.full_name}? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} disabled={deleting} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  {deleting ? 'Deleting...' : 'Delete'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </TableCell>
    </TableRow>
  );
}
