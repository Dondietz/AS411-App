import { useMemo, useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { History, Mail, MessageSquare, Loader2, CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';

interface NotificationHistoryDialogProps {
  clientId: string;
  clientName: string;
}

interface NotificationRecord {
  id: string;
  notification_type: string;
  channel: string;
  recipient: string;
  subject: string | null;
  message_preview: string | null;
  status: string;
  error_message: string | null;
  created_at: string;
}

type TwilioLookup = {
  sid: string;
  status: string;
  to: string;
  from: string;
  errorCode: number | null;
  errorMessage: string | null;
  dateCreated: string | null;
  dateSent: string | null;
  price: string | null;
  priceUnit: string | null;
};

type DeliveryStatus = 'pending' | 'delivered' | 'undelivered' | 'failed' | 'sent' | 'queued' | 'sending' | 'unknown';

const getDeliveryBadgeVariant = (status: DeliveryStatus): 'default' | 'secondary' | 'destructive' | 'outline' => {
  switch (status) {
    case 'delivered':
      return 'default';
    case 'sent':
    case 'sending':
    case 'queued':
    case 'pending':
      return 'secondary';
    case 'undelivered':
    case 'failed':
      return 'destructive';
    default:
      return 'outline';
  }
};

const getDeliveryIcon = (status: DeliveryStatus) => {
  switch (status) {
    case 'delivered':
      return <CheckCircle className="h-3 w-3" />;
    case 'failed':
    case 'undelivered':
      return <XCircle className="h-3 w-3" />;
    case 'sent':
    case 'sending':
    case 'queued':
    case 'pending':
      return <Clock className="h-3 w-3" />;
    default:
      return null;
  }
};

export function NotificationHistoryDialog({ clientId, clientName }: NotificationHistoryDialogProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [deliveryStatuses, setDeliveryStatuses] = useState<Record<string, DeliveryStatus>>({});
  const [twilioDetails, setTwilioDetails] = useState<Record<string, TwilioLookup | null>>({});
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(false);
  const intervalRef = useRef<number | null>(null);

  const extractTwilioSid = (messagePreview: string | null) => {
    if (!messagePreview) return null;
    const match = messagePreview.match(/SID:([A-Za-z0-9]+)/);
    const sid = match?.[1] ?? null;
    return sid && sid.startsWith('SM') ? sid : sid;
  };

  // Get the most recent SMS notifications (within last hour) that have SIDs
  const recentSmsWithSid = useMemo(() => {
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    return notifications.filter((n) => {
      if (n.channel !== 'sms') return false;
      const sid = extractTwilioSid(n.message_preview);
      if (!sid) return false;
      const createdAt = new Date(n.created_at);
      return createdAt > oneHourAgo;
    });
  }, [notifications]);

  const fetchTwilioStatus = useCallback(async (notification: NotificationRecord): Promise<DeliveryStatus> => {
    const sid = extractTwilioSid(notification.message_preview);
    if (!sid) return 'unknown';

    try {
      const { data, error } = await supabase.functions.invoke<TwilioLookup>('twilio-message-status', {
        body: { messageSid: sid },
      });

      if (error || !data) return 'unknown';

      setTwilioDetails((prev) => ({ ...prev, [notification.id]: data }));
      return (data.status as DeliveryStatus) || 'unknown';
    } catch {
      return 'unknown';
    }
  }, []);

  const refreshDeliveryStatuses = useCallback(async () => {
    if (recentSmsWithSid.length === 0) return;

    setIsAutoRefreshing(true);
    try {
      const statusPromises = recentSmsWithSid.map(async (notification) => {
        const status = await fetchTwilioStatus(notification);
        return { id: notification.id, status };
      });

      const results = await Promise.all(statusPromises);
      setDeliveryStatuses((prev) => {
        const updated = { ...prev };
        results.forEach(({ id, status }) => {
          updated[id] = status;
        });
        return updated;
      });
    } finally {
      setIsAutoRefreshing(false);
    }
  }, [recentSmsWithSid, fetchTwilioStatus]);

  useEffect(() => {
    if (open) {
      fetchNotifications();
    } else {
      // Clear interval when dialog closes
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
  }, [open, clientId]);

  // Start auto-refresh when notifications are loaded
  useEffect(() => {
    if (!open || recentSmsWithSid.length === 0) return;

    // Initial fetch
    refreshDeliveryStatuses();

    // Set up 30-second interval
    intervalRef.current = window.setInterval(() => {
      refreshDeliveryStatuses();
    }, 30000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [open, recentSmsWithSid.length, refreshDeliveryStatuses]);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('notification_history')
        .select('*')
        .eq('client_id', clientId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotifications(data || []);
      setDeliveryStatuses({});
      setTwilioDetails({});
    } catch (error) {
      console.error('Error fetching notification history:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'sms':
        return <MessageSquare className="h-4 w-4" />;
      default:
        return <Mail className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return null;
    }
  };

  const getNotificationTypeLabel = (type: string) => {
    switch (type) {
      case 'invitation':
        return 'Initial Invite';
      case 'resend_invitation':
        return 'Resent Invite';
      default:
        return type;
    }
  };

  const getDeliveryStatusForNotification = (notification: NotificationRecord): DeliveryStatus | null => {
    if (notification.channel !== 'sms') return null;
    const sid = extractTwilioSid(notification.message_preview);
    if (!sid) return null;
    return deliveryStatuses[notification.id] || null;
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <History className="h-4 w-4 mr-1" />
          History
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Notification History for {clientName}</DialogTitle>
            {isAutoRefreshing && (
              <RefreshCw className="h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No notifications have been sent to this client yet.
          </div>
        ) : (
          <ScrollArea className="max-h-[400px]">
            <div className="space-y-3">
              {notifications.map((notification) => {
                const deliveryStatus = getDeliveryStatusForNotification(notification);
                const twilio = twilioDetails[notification.id] ?? null;

                return (
                  <div key={notification.id} className="border rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getChannelIcon(notification.channel)}
                        <Badge variant="outline" className="capitalize">
                          {notification.channel}
                        </Badge>
                        <Badge variant="secondary">{getNotificationTypeLabel(notification.notification_type)}</Badge>
                      </div>
                      <div className="flex items-center gap-3">
                        {/* Delivery Status for SMS */}
                        {notification.channel === 'sms' && deliveryStatus && (
                          <Badge 
                            variant={getDeliveryBadgeVariant(deliveryStatus)} 
                            className="flex items-center gap-1 capitalize"
                          >
                            {getDeliveryIcon(deliveryStatus)}
                            {deliveryStatus}
                          </Badge>
                        )}
                        {/* Backend status */}
                        <div className="flex items-center gap-1">
                          {getStatusIcon(notification.status)}
                          <span className="text-sm text-muted-foreground capitalize">{notification.status}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-sm">
                      <span className="text-muted-foreground">To: </span>
                      <span className="font-medium">{notification.recipient}</span>
                    </div>

                    {notification.subject && (
                      <div className="text-sm">
                        <span className="text-muted-foreground">Subject: </span>
                        <span>{notification.subject}</span>
                      </div>
                    )}

                    {notification.message_preview && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{notification.message_preview}</p>
                    )}

                    {twilio?.errorMessage && (
                      <p className="text-sm text-destructive">
                        Provider error{twilio.errorCode ? ` (${twilio.errorCode})` : ''}: {twilio.errorMessage}
                      </p>
                    )}

                    {notification.error_message && (
                      <p className="text-sm text-destructive">Error: {notification.error_message}</p>
                    )}

                    <div className="text-xs text-muted-foreground">
                      {format(new Date(notification.created_at), 'MMM d, yyyy h:mm a')}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}

