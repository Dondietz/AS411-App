import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useEdgeFunction } from '@/hooks/useEdgeFunction';
import { UserPlus, Loader2, Check, Mail, Link, RefreshCw } from 'lucide-react';

interface InviteClientDialogProps {
  clientId: string;
  clientEmail: string | null;
  clientName: string;
  propertyId: string;
  hasAccount?: boolean;
}

export function InviteClientDialog({ 
  clientId, 
  clientEmail, 
  clientName,
  propertyId,
  hasAccount = false 
}: InviteClientDialogProps) {
  const { toast } = useToast();
  const { invoke } = useEdgeFunction();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState(clientEmail || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState<{ 
    email: string; 
    emailSent: boolean; 
    smsSent?: boolean;
    isExistingUser: boolean 
  } | null>(null);

  const handleInvite = async () => {
    if (!email.trim()) {
      toast({ title: 'Error', description: 'Please enter an email address', variant: 'destructive' });
      return;
    }

    setIsSubmitting(true);

    try {
      const { data, error } = await invoke<{ 
        user: { email: string }; 
        emailSent: boolean; 
        smsSent?: boolean;
        message: string 
      }>('invite-client', {
        body: { clientId, propertyId, email: email.trim() },
      });

      if (error) throw error;
      if (!data) throw new Error('No response from server');

      const isExistingUser = data.message?.includes('Existing user linked');
      setInviteSuccess({ 
        email: data.user.email, 
        emailSent: data.emailSent, 
        smsSent: data.smsSent,
        isExistingUser 
      });
      toast({ 
        title: 'Success', 
        description: isExistingUser ? 'Existing user linked to client' : 'Client account created successfully' 
      });
    } catch (error: any) {
      console.error('Error inviting client:', error);
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to invite client', 
        variant: 'destructive' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendInvite = async () => {
    setIsResending(true);

    try {
      const { data, error } = await invoke<{ 
        emailSent: boolean; 
        smsSent: boolean;
        notificationErrors?: string[];
      }>('resend-invite', {
        body: { clientId, propertyId },
      });

      if (error) throw error;
      if (!data) throw new Error('No response from server');

      const sentMethods: string[] = [];
      if (data.emailSent) sentMethods.push('email');
      if (data.smsSent) sentMethods.push('SMS');

      if (sentMethods.length > 0) {
        toast({ 
          title: 'Invite Resent', 
          description: `Invitation sent via ${sentMethods.join(' and ')}.` 
        });
      } else {
        toast({ 
          title: 'Warning', 
          description: data.notificationErrors?.join(', ') || 'No notifications were sent',
          variant: 'destructive'
        });
      }
      
      setOpen(false);
    } catch (error: any) {
      console.error('Error resending invite:', error);
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to resend invite', 
        variant: 'destructive' 
      });
    } finally {
      setIsResending(false);
    }
  };

  const handleClose = () => {
    setOpen(false);
    setInviteSuccess(null);
  };

  // Client already has account - show resend option
  if (hasAccount) {
    return (
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="text-green-600 border-green-200 bg-green-50 hover:bg-green-100 dark:text-green-400 dark:border-green-800 dark:bg-green-950 dark:hover:bg-green-900">
            <Check className="h-4 w-4 mr-1" />
            Account Linked
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Resend Invitation</DialogTitle>
            <DialogDescription>
              {clientName} already has an account linked. You can resend the invitation email and SMS if they didn't receive it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-muted p-4 rounded-lg space-y-3">
              <div className="flex items-center gap-2 text-primary">
                <Mail className="h-5 w-5" />
                <span className="font-medium">Resend Welcome Email & SMS</span>
              </div>
              <p className="text-sm text-muted-foreground">
                This will send a new password reset email{clientEmail ? ` to ${clientEmail}` : ''} and an SMS notification if a phone number is on file.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleResendInvite} disabled={isResending}>
              {isResending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Resend Invite
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <UserPlus className="h-4 w-4 mr-1" />
          Invite to Portal
        </Button>
      </DialogTrigger>
      <DialogContent>
        {!inviteSuccess ? (
          <>
            <DialogHeader>
              <DialogTitle>Invite Client to Portal</DialogTitle>
              <DialogDescription>
                Create an account for {clientName} so they can access progress reports, photos, and messaging.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="client@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={handleInvite} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Create Account
                  </>
                )}
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>
                {inviteSuccess.isExistingUser ? 'User Linked!' : 'Account Created!'}
              </DialogTitle>
              <DialogDescription>
                {inviteSuccess.isExistingUser 
                  ? `An existing user has been linked to ${clientName}.`
                  : `${clientName}'s account has been created successfully.`
                }
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {inviteSuccess.isExistingUser ? (
                <div className="bg-muted p-4 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 text-primary">
                    <Link className="h-5 w-5" />
                    <span className="font-medium">Existing Account Linked</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The user with email <strong>{inviteSuccess.email}</strong> already had an account. 
                    They have been linked to this client and can now access the portal.
                  </p>
                </div>
              ) : (
                <div className="bg-muted p-4 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 text-primary">
                    <Mail className="h-5 w-5" />
                    <span className="font-medium">Notifications Sent</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {inviteSuccess.emailSent && (
                      <>An invitation email has been sent to <strong>{inviteSuccess.email}</strong>. </>
                    )}
                    {inviteSuccess.smsSent && (
                      <>An SMS notification was also sent. </>
                    )}
                    {!inviteSuccess.emailSent && !inviteSuccess.smsSent && (
                      <>The account was created but notifications could not be sent. </>
                    )}
                  </p>
                </div>
              )}
              {!inviteSuccess.emailSent && !inviteSuccess.isExistingUser && (
                <p className="text-sm text-amber-600 dark:text-amber-500">
                  Note: There was an issue sending the email. You may need to manually send them a password reset link or click "Resend Invite" later.
                </p>
              )}
            </div>
            <DialogFooter>
              <Button onClick={handleClose}>Done</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
