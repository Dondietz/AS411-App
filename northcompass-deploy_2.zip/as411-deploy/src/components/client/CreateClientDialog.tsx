import { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Plus, Loader2, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const clientSchema = z.object({
  full_name: z.string().min(1, 'Name is required').max(100),
  email: z.string().email('Invalid email').max(255).optional().or(z.literal('')),
  phone: z.string().max(20).optional(),
  additional_emails: z.array(z.object({
    value: z.string().email('Invalid email').max(255).optional().or(z.literal('')),
    label: z.string().max(50).optional(),
  })),
  additional_phones: z.array(z.object({
    value: z.string().max(20).optional(),
    label: z.string().max(50).optional(),
  })),
  address: z.string().max(300).optional(),
  notes: z.string().max(2000).optional(),
});

type ClientFormData = z.infer<typeof clientSchema>;

interface CreateClientDialogProps {
  onSuccess?: () => void;
  trigger?: React.ReactNode;
}

export function CreateClientDialog({ onSuccess, trigger }: CreateClientDialogProps) {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: { 
      full_name: '', 
      email: '', 
      phone: '', 
      additional_emails: [],
      additional_phones: [],
      address: '', 
      notes: '' 
    },
  });

  const { fields: emailFields, append: appendEmail, remove: removeEmail } = useFieldArray({
    control: form.control,
    name: 'additional_emails',
  });

  const { fields: phoneFields, append: appendPhone, remove: removePhone } = useFieldArray({
    control: form.control,
    name: 'additional_phones',
  });

  const onSubmit = async (data: ClientFormData) => {
    setIsSubmitting(true);
    
    // Combine additional contacts into notes for now (since DB schema doesn't have separate fields)
    const additionalContacts: string[] = [];
    data.additional_emails.forEach(e => {
      if (e.value) additionalContacts.push(`${e.label || 'Family'}: ${e.value}`);
    });
    data.additional_phones.forEach(p => {
      if (p.value) additionalContacts.push(`${p.label || 'Family'}: ${p.value}`);
    });
    
    const combinedNotes = [
      data.notes?.trim(),
      additionalContacts.length ? `\n\nAdditional Contacts:\n${additionalContacts.join('\n')}` : ''
    ].filter(Boolean).join('');

    const { error } = await supabase.from('clients').insert({
      full_name: data.full_name.trim(),
      email: data.email?.trim() || null,
      phone: data.phone?.trim() || null,
      address: data.address?.trim() || null,
      notes: combinedNotes || null,
    });

    setIsSubmitting(false);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Client created', description: `${data.full_name} has been added.` });
      form.reset();
      setOpen(false);
      onSuccess?.();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button><Plus className="h-4 w-4 mr-1" /> Add Client</Button>}
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">Add New Client</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="full_name" render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name *</FormLabel>
                <FormControl><Input placeholder="John Smith" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Email</FormLabel>
                  <FormControl><Input type="email" placeholder="john@example.com" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="phone" render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Phone</FormLabel>
                  <FormControl><Input placeholder="(808) 555-1234" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            {/* Additional Emails */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <FormLabel className="text-sm">Additional Emails</FormLabel>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm"
                  onClick={() => appendEmail({ value: '', label: '' })}
                >
                  <Plus className="h-3 w-3 mr-1" /> Add
                </Button>
              </div>
              {emailFields.map((field, index) => (
                <div key={field.id} className="flex gap-2 items-start">
                  <Input
                    placeholder="Relationship (e.g., Daughter)"
                    className="w-28 text-sm"
                    {...form.register(`additional_emails.${index}.label`)}
                  />
                  <Input
                    type="email"
                    placeholder="email@example.com"
                    className="flex-1"
                    {...form.register(`additional_emails.${index}.value`)}
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeEmail(index)}>
                    <X className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>

            {/* Additional Phones */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <FormLabel className="text-sm">Additional Phones</FormLabel>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm"
                  onClick={() => appendPhone({ value: '', label: '' })}
                >
                  <Plus className="h-3 w-3 mr-1" /> Add
                </Button>
              </div>
              {phoneFields.map((field, index) => (
                <div key={field.id} className="flex gap-2 items-start">
                  <Input
                    placeholder="Relationship (e.g., Son)"
                    className="w-28 text-sm"
                    {...form.register(`additional_phones.${index}.label`)}
                  />
                  <Input
                    placeholder="(808) 555-1234"
                    className="flex-1"
                    {...form.register(`additional_phones.${index}.value`)}
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => removePhone(index)}>
                    <X className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>

            <FormField control={form.control} name="address" render={({ field }) => (
              <FormItem>
                <FormLabel>Address</FormLabel>
                <FormControl><Input placeholder="123 Main St, Honolulu, HI 96815" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="notes" render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl><Textarea placeholder="Additional details about the client..." rows={3} {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Client'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}