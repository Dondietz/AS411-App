export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      appointments: {
        Row: {
          attendees: string[] | null
          cal_event_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          end_time: string
          id: string
          location: string | null
          property_id: string
          start_time: string
          title: string
          updated_at: string
        }
        Insert: {
          attendees?: string[] | null
          cal_event_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_time: string
          id?: string
          location?: string | null
          property_id: string
          start_time: string
          title: string
          updated_at?: string
        }
        Update: {
          attendees?: string[] | null
          cal_event_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_time?: string
          id?: string
          location?: string | null
          property_id?: string
          start_time?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      client_invitations: {
        Row: {
          accepted_at: string | null
          client_id: string
          created_at: string
          email: string
          expires_at: string
          id: string
          invited_by: string | null
          property_id: string
          token: string
        }
        Insert: {
          accepted_at?: string | null
          client_id: string
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          invited_by?: string | null
          property_id: string
          token?: string
        }
        Update: {
          accepted_at?: string | null
          client_id?: string
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          invited_by?: string | null
          property_id?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_invitations_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_invitations_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          address: string | null
          created_at: string
          email: string | null
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      communications: {
        Row: {
          communication_type: string
          created_at: string
          created_by: string | null
          date: string
          direction: string | null
          id: string
          notes: string
          parties_involved: string | null
          property_id: string
          updated_at: string
        }
        Insert: {
          communication_type: string
          created_at?: string
          created_by?: string | null
          date?: string
          direction?: string | null
          id?: string
          notes: string
          parties_involved?: string | null
          property_id: string
          updated_at?: string
        }
        Update: {
          communication_type?: string
          created_at?: string
          created_by?: string | null
          date?: string
          direction?: string | null
          id?: string
          notes?: string
          parties_involved?: string | null
          property_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "communications_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "communications_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      contractor_bids: {
        Row: {
          amount: number
          attachment_name: string | null
          attachment_url: string | null
          contractor_id: string
          created_at: string
          created_by: string | null
          description: string
          estimated_duration_days: number | null
          estimated_start_date: string | null
          id: string
          notes: string | null
          property_id: string
          scope_of_work: string | null
          status: Database["public"]["Enums"]["bid_status"]
          status_changed_at: string | null
          status_changed_by: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          attachment_name?: string | null
          attachment_url?: string | null
          contractor_id: string
          created_at?: string
          created_by?: string | null
          description: string
          estimated_duration_days?: number | null
          estimated_start_date?: string | null
          id?: string
          notes?: string | null
          property_id: string
          scope_of_work?: string | null
          status?: Database["public"]["Enums"]["bid_status"]
          status_changed_at?: string | null
          status_changed_by?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          attachment_name?: string | null
          attachment_url?: string | null
          contractor_id?: string
          created_at?: string
          created_by?: string | null
          description?: string
          estimated_duration_days?: number | null
          estimated_start_date?: string | null
          id?: string
          notes?: string | null
          property_id?: string
          scope_of_work?: string | null
          status?: Database["public"]["Enums"]["bid_status"]
          status_changed_at?: string | null
          status_changed_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contractor_bids_contractor_id_fkey"
            columns: ["contractor_id"]
            isOneToOne: false
            referencedRelation: "contractors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractor_bids_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractor_bids_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractor_bids_status_changed_by_fkey"
            columns: ["status_changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      contractor_communications: {
        Row: {
          communication_type: string
          contractor_id: string
          created_at: string
          document_name: string | null
          document_url: string | null
          error_message: string | null
          id: string
          message: string
          property_id: string | null
          recipient_email: string | null
          recipient_phone: string | null
          sent_by: string | null
          status: string
          subject: string | null
          twilio_sid: string | null
        }
        Insert: {
          communication_type: string
          contractor_id: string
          created_at?: string
          document_name?: string | null
          document_url?: string | null
          error_message?: string | null
          id?: string
          message: string
          property_id?: string | null
          recipient_email?: string | null
          recipient_phone?: string | null
          sent_by?: string | null
          status?: string
          subject?: string | null
          twilio_sid?: string | null
        }
        Update: {
          communication_type?: string
          contractor_id?: string
          created_at?: string
          document_name?: string | null
          document_url?: string | null
          error_message?: string | null
          id?: string
          message?: string
          property_id?: string | null
          recipient_email?: string | null
          recipient_phone?: string | null
          sent_by?: string | null
          status?: string
          subject?: string | null
          twilio_sid?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contractor_communications_contractor_id_fkey"
            columns: ["contractor_id"]
            isOneToOne: false
            referencedRelation: "contractors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractor_communications_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractor_communications_sent_by_fkey"
            columns: ["sent_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      contractors: {
        Row: {
          company_name: string
          contact_name: string | null
          created_at: string
          email: string | null
          hourly_rate: number | null
          id: string
          is_active: boolean | null
          notes: string | null
          phone: string | null
          specialty: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          company_name: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          hourly_rate?: number | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          phone?: string | null
          specialty?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          company_name?: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          hourly_rate?: number | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          phone?: string | null
          specialty?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      costs: {
        Row: {
          amount: number
          category: string | null
          contractor_id: string | null
          cost_type: Database["public"]["Enums"]["cost_type"]
          created_at: string
          description: string
          id: string
          invoice_number: string | null
          notes: string | null
          paid_date: string | null
          property_id: string
          updated_at: string
        }
        Insert: {
          amount: number
          category?: string | null
          contractor_id?: string | null
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          description: string
          id?: string
          invoice_number?: string | null
          notes?: string | null
          paid_date?: string | null
          property_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string | null
          contractor_id?: string | null
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          description?: string
          id?: string
          invoice_number?: string | null
          notes?: string | null
          paid_date?: string | null
          property_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "costs_contractor_id_fkey"
            columns: ["contractor_id"]
            isOneToOne: false
            referencedRelation: "contractors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "costs_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      files: {
        Row: {
          caption: string | null
          category: string | null
          created_at: string
          file_name: string
          file_size: number | null
          file_type: string | null
          file_url: string
          id: string
          property_id: string
          uploaded_by: string | null
        }
        Insert: {
          caption?: string | null
          category?: string | null
          created_at?: string
          file_name: string
          file_size?: number | null
          file_type?: string | null
          file_url: string
          id?: string
          property_id: string
          uploaded_by?: string | null
        }
        Update: {
          caption?: string | null
          category?: string | null
          created_at?: string
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          file_url?: string
          id?: string
          property_id?: string
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "files_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string
          created_at: string
          id: string
          is_internal: boolean | null
          message_type: string | null
          property_id: string
          sender_id: string | null
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_internal?: boolean | null
          message_type?: string | null
          property_id: string
          sender_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_internal?: boolean | null
          message_type?: string | null
          property_id?: string
          sender_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_history: {
        Row: {
          channel: string
          client_id: string
          created_at: string
          error_message: string | null
          id: string
          message_preview: string | null
          notification_type: string
          property_id: string | null
          recipient: string
          sent_by: string | null
          status: string
          subject: string | null
        }
        Insert: {
          channel: string
          client_id: string
          created_at?: string
          error_message?: string | null
          id?: string
          message_preview?: string | null
          notification_type: string
          property_id?: string | null
          recipient: string
          sent_by?: string | null
          status?: string
          subject?: string | null
        }
        Update: {
          channel?: string
          client_id?: string
          created_at?: string
          error_message?: string | null
          id?: string
          message_preview?: string | null
          notification_type?: string
          property_id?: string | null
          recipient?: string
          sent_by?: string | null
          status?: string
          subject?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_history_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_history_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          created_by: string | null
          description: string
          id: string
          is_read: boolean
          notification_type: string
          property_id: string | null
          title: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description: string
          id?: string
          is_read?: boolean
          notification_type?: string
          property_id?: string | null
          title: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string
          id?: string
          is_read?: boolean
          notification_type?: string
          property_id?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string | null
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name: string
          id: string
          phone?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      project_contractors: {
        Row: {
          contractor_user_id: string
          created_at: string
          id: string
          project_id: string
        }
        Insert: {
          contractor_user_id: string
          created_at?: string
          id?: string
          project_id: string
        }
        Update: {
          contractor_user_id?: string
          created_at?: string
          id?: string
          project_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_contractors_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          actual_close_date: string | null
          address: string
          city: string | null
          client_user_id: string | null
          coordinator_user_id: string | null
          created_at: string
          estimated_value: number | null
          id: string
          intake_date: string | null
          island: string | null
          listing_price: number | null
          notes: string | null
          property_type: string | null
          sale_price: number | null
          state: string | null
          status: string
          target_close_date: string | null
          tenant_id: string
          updated_at: string
          zip_code: string | null
        }
        Insert: {
          actual_close_date?: string | null
          address: string
          city?: string | null
          client_user_id?: string | null
          coordinator_user_id?: string | null
          created_at?: string
          estimated_value?: number | null
          id?: string
          intake_date?: string | null
          island?: string | null
          listing_price?: number | null
          notes?: string | null
          property_type?: string | null
          sale_price?: number | null
          state?: string | null
          status?: string
          target_close_date?: string | null
          tenant_id?: string
          updated_at?: string
          zip_code?: string | null
        }
        Update: {
          actual_close_date?: string | null
          address?: string
          city?: string | null
          client_user_id?: string | null
          coordinator_user_id?: string | null
          created_at?: string
          estimated_value?: number | null
          id?: string
          intake_date?: string | null
          island?: string | null
          listing_price?: number | null
          notes?: string | null
          property_type?: string | null
          sale_price?: number | null
          state?: string | null
          status?: string
          target_close_date?: string | null
          tenant_id?: string
          updated_at?: string
          zip_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "projects_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      properties: {
        Row: {
          actual_close_date: string | null
          address: string
          city: string
          client_id: string | null
          coordinator_id: string | null
          created_at: string
          estimated_value: number | null
          id: string
          intake_date: string | null
          island: string | null
          listing_price: number | null
          notes: string | null
          property_type: string | null
          sale_price: number | null
          state: string
          status: Database["public"]["Enums"]["property_status"]
          target_close_date: string | null
          updated_at: string
          zip_code: string | null
        }
        Insert: {
          actual_close_date?: string | null
          address: string
          city: string
          client_id?: string | null
          coordinator_id?: string | null
          created_at?: string
          estimated_value?: number | null
          id?: string
          intake_date?: string | null
          island?: string | null
          listing_price?: number | null
          notes?: string | null
          property_type?: string | null
          sale_price?: number | null
          state?: string
          status?: Database["public"]["Enums"]["property_status"]
          target_close_date?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Update: {
          actual_close_date?: string | null
          address?: string
          city?: string
          client_id?: string | null
          coordinator_id?: string | null
          created_at?: string
          estimated_value?: number | null
          id?: string
          intake_date?: string | null
          island?: string | null
          listing_price?: number | null
          notes?: string | null
          property_type?: string | null
          sale_price?: number | null
          state?: string
          status?: Database["public"]["Enums"]["property_status"]
          target_close_date?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "properties_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "properties_coordinator_id_fkey"
            columns: ["coordinator_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          assigned_to: string | null
          completed_at: string | null
          contractor_id: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          is_milestone: boolean | null
          phase: Database["public"]["Enums"]["task_phase"]
          priority: number | null
          property_id: string
          status: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          completed_at?: string | null
          contractor_id?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          is_milestone?: boolean | null
          phase: Database["public"]["Enums"]["task_phase"]
          priority?: number | null
          property_id: string
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          completed_at?: string | null
          contractor_id?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          is_milestone?: boolean | null
          phase?: Database["public"]["Enums"]["task_phase"]
          priority?: number | null
          property_id?: string
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_contractor_id_fkey"
            columns: ["contractor_id"]
            isOneToOne: false
            referencedRelation: "contractors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          created_at: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      thread_messages: {
        Row: {
          attachment_url: string | null
          body: string
          created_at: string | null
          edited_at: string | null
          id: string
          message_type: Database["public"]["Enums"]["message_type"]
          property_id: string
          sender_role: Database["public"]["Enums"]["app_role"]
          sender_user_id: string | null
          tenant_id: string | null
          thread_id: string
        }
        Insert: {
          attachment_url?: string | null
          body: string
          created_at?: string | null
          edited_at?: string | null
          id?: string
          message_type?: Database["public"]["Enums"]["message_type"]
          property_id: string
          sender_role: Database["public"]["Enums"]["app_role"]
          sender_user_id?: string | null
          tenant_id?: string | null
          thread_id: string
        }
        Update: {
          attachment_url?: string | null
          body?: string
          created_at?: string | null
          edited_at?: string | null
          id?: string
          message_type?: Database["public"]["Enums"]["message_type"]
          property_id?: string
          sender_role?: Database["public"]["Enums"]["app_role"]
          sender_user_id?: string | null
          tenant_id?: string | null
          thread_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_messages_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_messages_sender_user_id_fkey"
            columns: ["sender_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_messages_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      thread_participants: {
        Row: {
          created_at: string | null
          id: string
          last_read_at: string | null
          muted: boolean | null
          role: Database["public"]["Enums"]["app_role"]
          thread_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          last_read_at?: string | null
          muted?: boolean | null
          role: Database["public"]["Enums"]["app_role"]
          thread_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          last_read_at?: string | null
          muted?: boolean | null
          role?: Database["public"]["Enums"]["app_role"]
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_participants_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      threads: {
        Row: {
          created_at: string | null
          created_by_user_id: string | null
          id: string
          is_archived: boolean | null
          last_message_at: string | null
          property_id: string
          tenant_id: string | null
          thread_type: Database["public"]["Enums"]["thread_type"]
          title: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by_user_id?: string | null
          id?: string
          is_archived?: boolean | null
          last_message_at?: string | null
          property_id: string
          tenant_id?: string | null
          thread_type: Database["public"]["Enums"]["thread_type"]
          title: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by_user_id?: string | null
          id?: string
          is_archived?: boolean | null
          last_message_at?: string | null
          property_id?: string
          tenant_id?: string | null
          thread_type?: Database["public"]["Enums"]["thread_type"]
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "threads_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "threads_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "threads_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_thread: {
        Args: {
          thread_property_id: string
          thread_title: string
          thread_type_in: Database["public"]["Enums"]["thread_type"]
        }
        Returns: string
      }
      get_invitation_by_token: {
        Args: { invitation_token: string }
        Returns: {
          accepted_at: string
          client_id: string
          expires_at: string
          id: string
          property_id: string
        }[]
      }
    }
    Enums: {
      app_role:
        | "coordinator"
        | "contractor"
        | "client"
        | "admin"
        | "investor"
        | "accounting"
      bid_status: "pending" | "accepted" | "rejected" | "expired"
      cost_type: "deferred" | "paid" | "estimated"
      message_type: "text" | "image" | "file" | "system"
      property_status:
        | "intake"
        | "cleanout"
        | "repair"
        | "listing"
        | "escrow"
        | "closed"
      task_phase: "cleanout" | "repair" | "listing" | "escrow" | "closing"
      task_status: "pending" | "in_progress" | "completed" | "blocked"
      thread_type: "client_coord" | "contractor_coord" | "internal"
      user_role:
        | "COORDINATOR"
        | "CLIENT"
        | "CONTRACTOR"
        | "ADMIN"
        | "ACCOUNTING"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "coordinator",
        "contractor",
        "client",
        "admin",
        "investor",
        "accounting",
      ],
      bid_status: ["pending", "accepted", "rejected", "expired"],
      cost_type: ["deferred", "paid", "estimated"],
      message_type: ["text", "image", "file", "system"],
      property_status: [
        "intake",
        "cleanout",
        "repair",
        "listing",
        "escrow",
        "closed",
      ],
      task_phase: ["cleanout", "repair", "listing", "escrow", "closing"],
      task_status: ["pending", "in_progress", "completed", "blocked"],
      thread_type: ["client_coord", "contractor_coord", "internal"],
      user_role: ["COORDINATOR", "CLIENT", "CONTRACTOR", "ADMIN", "ACCOUNTING"],
    },
  },
} as const
